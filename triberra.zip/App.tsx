import React, { useState, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Trip, Expense, Member, ItineraryItem, AppNotification, AuthUser, UserPreferences } from './types';
import DashboardView from './views/DashboardView';
import ExpensesView from './views/ExpensesView';
import AddExpenseView from './views/AddExpenseView';
import EditExpenseView from './views/EditExpenseView';
import ItineraryView from './views/ItineraryView';
import CreateTripView from './views/CreateTripView';
import SettingsView from './views/SettingsView';
import WelcomeView from './views/WelcomeView';
import ProfileView from './views/ProfileView';
import TravelGuideView from './views/TravelGuideView';
import AuthView from './views/AuthView';
import HistoryView from './views/HistoryView';
import InsightsView from './views/InsightsView';
import { DatabaseService, UserVault } from './services/databaseService';

const INITIAL_MEMBERS: Member[] = [
  { id: '1', name: 'You', avatar: 'https://picsum.photos/seed/1/100' },
  { id: '2', name: 'Alex', avatar: 'https://picsum.photos/seed/2/100' },
  { id: '3', name: 'Sam', avatar: 'https://picsum.photos/seed/3/100' },
];

const DEFAULT_PREFERENCES: UserPreferences = {
  budgetAlerts: true,
  expenseUpdates: true,
  itineraryReminders: true,
};

const INITIAL_TRIP: Trip = {
  id: 'trip-1',
  inviteCode: 'TRV-BALI-2024',
  name: 'Bali Retreat',
  destination: 'Bali, Indonesia',
  startDate: '2024-06-10',
  endDate: '2024-06-17',
  currency: 'INR',
  budget: 120000,
  members: INITIAL_MEMBERS,
  expenses: [
    { id: 'e1', amount: 8500, description: 'Seafood Dinner', category: 'food', date: '2024-06-11', paidBy: '1', splitAmong: ['1', '2', '3'] },
    { id: 'e2', amount: 3200, description: 'Scooter Rental', category: 'travel', date: '2024-06-11', paidBy: '2', splitAmong: ['2', '3'] },
  ],
  itinerary: [
    { id: 'i1', title: 'Arrival at Denpasar', time: '14:00', date: '2024-06-10', location: 'Airport', isCompleted: true },
    { id: 'i2', title: 'Dinner at Beach', time: '19:00', date: '2024-06-10', location: 'Jimbaran', isCompleted: false },
  ],
};

const App: React.FC = () => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [trip, setTrip] = useState<Trip | null>(null);
  const [vault, setVault] = useState<UserVault | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('triberra_theme') as 'light' | 'dark') || 'dark';
  });

  const syncChannel = React.useMemo(() => new BroadcastChannel('triberra_sync'), []);

  // Initialize Auth and Data Vault
  useEffect(() => {
    const savedUser = localStorage.getItem('triberra_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      // Ensure preferences exist
      if (!parsedUser.preferences) {
        parsedUser.preferences = DEFAULT_PREFERENCES;
      }
      setUser(parsedUser);
      loadUserData(parsedUser.id);
    } else {
      setIsLoaded(true);
    }

    syncChannel.onmessage = (event) => {
      if (event.data.type === 'SYNC_TRIP' && event.data.trip) {
        setTrip(event.data.trip);
      }
    };

    return () => syncChannel.close();
  }, [syncChannel]);

  const loadUserData = async (userId: string) => {
    setIsSyncing(true);
    const [userVault, activeTrip] = await Promise.all([
      DatabaseService.syncUserVault(userId),
      DatabaseService.getActiveTrip(userId)
    ]);
    setVault(userVault);
    setTrip(activeTrip);
    setIsSyncing(false);
    setIsLoaded(true);
  };

  // Sync state to persistent storage
  useEffect(() => {
    if (user) {
      localStorage.setItem('triberra_user', JSON.stringify(user));
      if (trip) {
        DatabaseService.saveTrip(user.id, trip);
        syncChannel.postMessage({ type: 'SYNC_TRIP', trip });
      }
    } else {
      localStorage.removeItem('triberra_user');
    }
  }, [user, trip, syncChannel]);

  // Proactive Budget Monitoring
  useEffect(() => {
    if (!trip || !user) return;
    
    // Check user preference for budget alerts
    if (user.preferences && !user.preferences.budgetAlerts) return;

    const totalGroupSpending = trip.expenses
      .filter(e => !e.description.startsWith('Settlement:'))
      .reduce((sum, exp) => sum + exp.amount, 0);

    const newAlerts: Omit<AppNotification, 'id' | 'timestamp' | 'isRead'>[] = [];

    if (totalGroupSpending >= trip.budget) {
      newAlerts.push({
        type: 'error',
        title: 'Group Budget Exceeded',
        message: `The trip has exceeded the total budget of ₹${trip.budget.toLocaleString()}.`
      });
    }

    const finalAlerts = newAlerts.filter(alert => 
      !notifications.some(n => n.title === alert.title && (Date.now() - n.timestamp < 3600000))
    );

    if (finalAlerts.length > 0) {
      const addedNotifications: AppNotification[] = finalAlerts.map(a => ({
        ...a,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        isRead: false
      }));
      setNotifications(prev => [...addedNotifications, ...prev].slice(0, 20));
    }
  }, [trip, user, notifications]);

  const markNotificationsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  }, []);

  const clearNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  useEffect(() => {
    document.documentElement.className = theme;
    localStorage.setItem('triberra_theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  const addExpense = useCallback((expense: Omit<Expense, 'id'>) => {
    const newExpense = { ...expense, id: Date.now().toString() };
    setTrip(prev => {
      if (!prev) return null;
      return { ...prev, expenses: [newExpense, ...prev.expenses] };
    });
    
    // Add success notification for manual log if preferred
    if (user?.preferences?.expenseUpdates) {
      const addedNotification: AppNotification = {
        id: Math.random().toString(36).substr(2, 9),
        type: 'success',
        title: 'Expense Logged',
        message: `₹${expense.amount} for ${expense.description} recorded.`,
        timestamp: Date.now(),
        isRead: false
      };
      setNotifications(prev => [addedNotification, ...prev].slice(0, 20));
    }
  }, [user?.preferences?.expenseUpdates]);

  const handleCompleteTrip = useCallback(async () => {
    if (!trip || !user) return;
    setIsSyncing(true);
    await DatabaseService.archiveTrip(user.id, trip);
    setTrip(null);
    // Reload vault to reflect archived trip
    const updatedVault = await DatabaseService.syncUserVault(user.id);
    setVault(updatedVault);
    setIsSyncing(false);
  }, [trip, user]);

  const deleteActiveTrip = useCallback(async () => {
    if (!trip || !user) return;
    setIsSyncing(true);
    await DatabaseService.deleteTrip(trip.id);
    localStorage.removeItem(`triberra_v1_active_id_${user.id}`);
    setTrip(null);
    setIsSyncing(false);
  }, [trip, user]);

  const updateExpense = (updatedExpense: Expense) => {
    setTrip(prev => {
      if (!prev) return null;
      return { ...prev, expenses: prev.expenses.map(exp => exp.id === updatedExpense.id ? updatedExpense : exp) };
    });
  };

  const deleteExpense = (id: string) => {
    setTrip(prev => {
      if (!prev) return null;
      return { ...prev, expenses: prev.expenses.filter(exp => exp.id !== id) };
    });
  };

  const restoreExpense = (expense: Expense) => {
    setTrip(prev => {
      if (!prev) return null;
      return { 
        ...prev, 
        expenses: [expense, ...prev.expenses].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()) 
      };
    });
  };

  const settleBalance = (fromId: string, toId: string, amount: number) => {
    setTrip(prev => {
      if (!prev) return null;
      const settlementExpense: Expense = {
        id: `settle-${Date.now()}`,
        description: `Settlement: ${prev.members.find(m => m.id === fromId)?.name} paid ${prev.members.find(m => m.id === toId)?.name}`,
        amount: amount,
        category: 'others',
        date: new Date().toISOString().split('T')[0],
        paidBy: fromId,
        splitAmong: [toId]
      };
      return { ...prev, expenses: [settlementExpense, ...prev.expenses] };
    });
  };

  const addItineraryItem = (item: Omit<ItineraryItem, 'id'>) => {
    setTrip(prev => {
      if (!prev) return null;
      const newItem = { ...item, id: Date.now().toString() };
      return { ...prev, itinerary: [...prev.itinerary, newItem] };
    });
  };

  const updateItineraryItem = (updatedItem: ItineraryItem) => {
    setTrip(prev => {
      if (!prev) return null;
      return { ...prev, itinerary: prev.itinerary.map(item => item.id === updatedItem.id ? updatedItem : item) };
    });
  };

  const deleteItineraryItem = (id: string) => {
    setTrip(prev => {
      if (!prev) return null;
      return { ...prev, itinerary: prev.itinerary.filter(item => item.id !== id) };
    });
  };

  const toggleItineraryItem = (id: string) => {
    setTrip(prev => {
      if (!prev) return null;
      return { ...prev, itinerary: prev.itinerary.map(item => item.id === id ? { ...item, isCompleted: !item.isCompleted } : item) };
    });
  };

  const addMember = (name: string) => {
    setTrip(prev => {
      if (!prev) return null;
      const newMember: Member = { id: Date.now().toString(), name, avatar: `https://picsum.photos/seed/${Date.now()}/100` };
      return { ...prev, members: [...prev.members, newMember] };
    });
  };

  const updateMember = (memberId: string, updates: Partial<Member>) => {
    setTrip(prev => {
      if (!prev) return null;
      return { ...prev, members: prev.members.map(m => m.id === memberId ? { ...m, ...updates } : m) };
    });
  };

  const updateUser = (updates: Partial<AuthUser>) => {
    setUser(prev => prev ? { ...prev, ...updates } : null);
  };

  const createTrip = (newTrip: Trip) => {
    setTrip(newTrip);
  };

  const joinTripByCode = (code: string) => {
    if (code.toUpperCase().includes('BALI')) {
       setTrip(INITIAL_TRIP);
    } else {
       setTrip({ ...INITIAL_TRIP, id: 'joined-' + Date.now(), name: 'Shared Adventure', destination: 'New Destination', inviteCode: code.toUpperCase() });
    }
  };

  const handleLogin = (newUser: AuthUser) => {
    if (!newUser.preferences) newUser.preferences = DEFAULT_PREFERENCES;
    setUser(newUser);
    loadUserData(newUser.id);
  };

  const handleLogout = () => {
    setUser(null);
    setTrip(null);
    setVault(null);
    localStorage.removeItem('triberra_user');
  };

  const updateTrip = useCallback((updatedFields: Partial<Trip>) => {
    setTrip(prev => {
      if (!prev) return null;
      
      const newFields = { ...updatedFields };
      // CRITICAL: If the destination is changing, clear the coverImage.
      // This forces the DashboardView to regenerate a new image for the new location.
      if (updatedFields.destination && updatedFields.destination !== prev.destination) {
        newFields.coverImage = undefined;
      }
      
      return { ...prev, ...newFields };
    });
  }, []);

  if (!isLoaded) return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-10">
      <div className="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-4"></div>
      <p className="text-indigo-600 font-black uppercase tracking-widest text-xs">Initializing Vault...</p>
    </div>
  );

  return (
    <HashRouter>
      {isSyncing && (
        <div className="fixed top-0 left-0 right-0 h-1 bg-indigo-100 z-[100] overflow-hidden">
           <div className="h-full bg-indigo-600 animate-progress origin-left"></div>
        </div>
      )}
      <Routes>
        <Route path="/auth" element={!user ? <AuthView onLogin={handleLogin} /> : <Navigate to="/" />} />
        
        <Route path="/" element={
          !user ? <Navigate to="/auth" /> : 
          trip ? <DashboardView user={user} trip={trip} onAddExpense={addExpense} onSettle={settleBalance} onUpdateTrip={updateTrip} onAddMember={addMember} onCompleteTrip={handleCompleteTrip} notifications={notifications} clearNotification={clearNotification} onReadNotifications={markNotificationsRead} /> 
          : <WelcomeView user={user} onJoin={joinTripByCode} />
        } />

        <Route path="/history" element={user ? <HistoryView user={user} history={vault?.history || []} /> : <Navigate to="/auth" />} />
        <Route path="/expenses" element={trip && user ? <ExpensesView user={user} trip={trip} onDeleteExpense={deleteExpense} onRestoreExpense={restoreExpense} /> : <Navigate to="/" />} />
        <Route path="/insights" element={trip && user ? <InsightsView user={user} trip={trip} /> : <Navigate to="/" />} />
        <Route path="/add-expense" element={trip && user ? <AddExpenseView user={user} members={trip.members} onAdd={addExpense} /> : <Navigate to="/" />} />
        <Route path="/edit-expense/:id" element={trip && user ? <EditExpenseView user={user} trip={trip} onEdit={updateExpense} /> : <Navigate to="/" />} />
        <Route path="/itinerary" element={trip && user ? <ItineraryView user={user} trip={trip} onUpdateTrip={updateTrip} onAdd={addItineraryItem} onToggle={toggleItineraryItem} onUpdate={updateItineraryItem} onDelete={deleteItineraryItem} /> : <Navigate to="/" />} />
        <Route path="/guide" element={trip && user ? <TravelGuideView user={user} trip={trip} /> : <Navigate to="/" />} />
        <Route path="/create-trip" element={user ? <CreateTripView user={user} onCreate={createTrip} /> : <Navigate to="/auth" />} />
        <Route path="/settings" element={trip && user ? <SettingsView user={user} trip={trip} onUpdate={updateTrip} onAddMember={addMember} onDeleteTrip={deleteActiveTrip} onJoinByCode={joinTripByCode} onUpdateUser={updateUser} theme={theme} onToggleTheme={toggleTheme} onLogout={handleLogout} /> : <Navigate to="/" />} />
        <Route path="/profile/:id" element={trip && user ? <ProfileView user={user} trip={trip} onUpdate={updateMember} onUpdateUser={updateUser} /> : <Navigate to="/" />} />
        
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </HashRouter>
  );
};

export default App;