import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, Map, Bell, X, AlertTriangle, AlertCircle, 
  Info, CheckCircle2, BarChart3, WifiOff, LayoutDashboard, Settings, History
} from 'lucide-react';
import { AppNotification, AuthUser } from '../types';

interface SharedLayoutProps {
  children: React.ReactNode;
  user?: AuthUser;
  title?: string;
  activeTab?: string;
  showTabs?: boolean;
  notifications?: AppNotification[];
  clearNotification?: (id: string) => void;
  onReadNotifications?: () => void;
}

const SharedLayout: React.FC<SharedLayoutProps> = ({ 
  children, 
  user,
  title, 
  activeTab, 
  showTabs = true, 
  notifications = [], 
  clearNotification,
  onReadNotifications 
}) => {
  const navigate = useNavigate();
  const [showNotifications, setShowNotifications] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleBellClick = () => {
    setShowNotifications(!showNotifications);
    if (!showNotifications && onReadNotifications) {
      onReadNotifications();
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertTriangle size={18} className="text-amber-500" />;
      case 'error': return <AlertCircle size={18} className="text-rose-500" />;
      case 'success': return <CheckCircle2 size={18} className="text-emerald-500" />;
      default: return <Info size={18} className="text-indigo-500" />;
    }
  };

  const navItems = [
    { id: 'home', icon: LayoutDashboard, label: 'Feed', path: '/' },
    { id: 'itinerary', icon: Map, label: 'Plan', path: '/itinerary' },
    { id: 'expenses', icon: History, label: 'History', path: '/expenses' },
    { id: 'insights', icon: BarChart3, label: 'Stats', path: '/insights' },
  ];

  return (
    <div className="flex flex-col min-h-screen max-w-md mx-auto bg-slate-50 dark:bg-slate-950 relative overflow-hidden shadow-2xl text-slate-900 dark:text-slate-100 transition-colors duration-500">
      {/* Premium Header */}
      <header className="sticky top-0 z-40 bg-white/60 dark:bg-slate-950/60 backdrop-blur-2xl border-b border-slate-200/50 dark:border-white/5 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
           {user ? (
             <div className="flex items-center gap-2">
                <div className="relative">
                  <img src={user.avatar} className="w-9 h-9 rounded-2xl border-2 border-white dark:border-slate-800 shadow-sm object-cover" alt={user.name} />
                  <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-950"></div>
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-900 dark:text-slate-100 truncate max-w-[100px]">{user.name.split(' ')[0]}</span>
                  <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest leading-none">Traveler</span>
                </div>
             </div>
           ) : (
             <h1 className="text-2xl font-brand pt-1 bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-cyan-500">
               Triberra
             </h1>
           )}
        </div>
        
        {user && (
          <h1 className="text-xl font-brand pt-1 bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-cyan-500 absolute left-1/2 -translate-x-1/2">
            Triberra
          </h1>
        )}

        <div className="flex items-center gap-1">
          <button 
            onClick={() => navigate('/settings')}
            className="w-10 h-10 flex items-center justify-center rounded-2xl text-slate-400 hover:text-indigo-500 transition-all"
          >
            <Settings size={20} />
          </button>
          <button 
            onClick={handleBellClick}
            className="w-10 h-10 flex items-center justify-center rounded-2xl bg-slate-100 dark:bg-white/5 border border-transparent hover:border-slate-200 dark:hover:border-white/10 transition-all relative"
          >
            <Bell size={20} className="text-slate-600 dark:text-slate-300" />
            {unreadCount > 0 && (
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full animate-pulse border-2 border-white dark:border-slate-950"></span>
            )}
          </button>
        </div>
      </header>

      {/* Modern Notification Modal */}
      {showNotifications && (
        <div className="fixed inset-0 z-50 bg-slate-950/20 dark:bg-black/60 backdrop-blur-md animate-in fade-in duration-300" onClick={() => setShowNotifications(false)}>
          <div 
            className="absolute top-[80px] right-4 w-80 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl rounded-[2.5rem] shadow-2xl border border-slate-200/50 dark:border-white/10 overflow-hidden animate-in slide-in-from-top-4 duration-300"
            onClick={e => e.stopPropagation()}
          >
            <div className="p-5 border-b border-slate-100 dark:border-white/5 flex justify-between items-center">
               <h3 className="text-xs font-black uppercase tracking-widest opacity-60">Alert Center</h3>
               <button onClick={() => setShowNotifications(false)} className="p-1.5 hover:bg-slate-100 dark:hover:bg-white/5 rounded-full"><X size={14} /></button>
            </div>
            <div className="max-h-96 overflow-y-auto custom-scrollbar p-2">
              {notifications.length === 0 ? (
                <div className="p-12 text-center">
                   <Bell size={28} className="mx-auto mb-3 text-slate-300 dark:text-slate-700" />
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Quiet for now</p>
                </div>
              ) : (
                notifications.map((n) => (
                  <div key={n.id} className={`p-4 mb-2 rounded-[1.5rem] border transition-all ${!n.isRead ? 'bg-indigo-50/50 dark:bg-indigo-500/5 border-indigo-100 dark:border-indigo-500/20' : 'bg-transparent border-transparent'}`}>
                    <div className="flex gap-3">
                      <div className="mt-0.5 shrink-0">{getNotificationIcon(n.type)}</div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-black leading-tight mb-1">{n.title}</p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">{n.message}</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 pb-32 overflow-y-auto px-5 pt-4 custom-scrollbar">
        {children}
      </main>

      {/* New Modern "Island" Dock Navigation */}
      {showTabs && (
        <div className="fixed bottom-8 left-0 right-0 px-6 z-50 pointer-events-none">
          <div className="max-w-[360px] mx-auto pointer-events-auto">
            <nav className="relative bg-white/70 dark:bg-slate-900/70 backdrop-blur-3xl border border-white/20 dark:border-white/10 p-2 rounded-[2.5rem] flex items-center justify-between shadow-[0_20px_50px_rgba(0,0,0,0.2)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
              
              {/* Left Group */}
              <div className="flex flex-1 justify-around">
                {navItems.slice(0, 2).map((item) => (
                  <button 
                    key={item.id}
                    onClick={() => navigate(item.path)}
                    className={`group relative flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300 ${activeTab === item.id ? 'bg-indigo-500/10 dark:bg-cyan-500/10 text-indigo-600 dark:text-cyan-400' : 'text-slate-400'}`}
                  >
                    <item.icon size={22} strokeWidth={activeTab === item.id ? 2.5 : 2} />
                    <span className="absolute -top-10 scale-0 group-hover:scale-100 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[9px] font-black px-2 py-1 rounded-lg uppercase transition-all duration-200">{item.label}</span>
                  </button>
                ))}
              </div>

              {/* Action Button Hub */}
              <div className="px-2">
                <button 
                  onClick={() => navigate('/add-expense')}
                  className="w-14 h-14 bg-gradient-to-br from-indigo-500 via-indigo-600 to-indigo-700 text-white rounded-[1.8rem] flex items-center justify-center shadow-lg shadow-indigo-500/30 active:scale-90 transition-all border-4 border-white dark:border-slate-800"
                >
                  <Plus size={28} strokeWidth={3} />
                </button>
              </div>

              {/* Right Group */}
              <div className="flex flex-1 justify-around">
                {navItems.slice(2).map((item) => (
                  <button 
                    key={item.id}
                    onClick={() => navigate(item.path)}
                    className={`group relative flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300 ${activeTab === item.id ? 'bg-indigo-500/10 dark:bg-cyan-500/10 text-indigo-600 dark:text-cyan-400' : 'text-slate-400'}`}
                  >
                    <item.icon size={22} strokeWidth={activeTab === item.id ? 2.5 : 2} />
                    <span className="absolute -top-10 scale-0 group-hover:scale-100 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[9px] font-black px-2 py-1 rounded-lg uppercase transition-all duration-200">{item.label}</span>
                  </button>
                ))}
              </div>
            </nav>
          </div>
        </div>
      )}
    </div>
  );
};

export default SharedLayout;