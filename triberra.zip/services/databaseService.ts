import { Trip, AuthUser } from "../types";

/**
 * DatabaseService simulates a robust backend storage system.
 * It handles data scoping per user and ensures persistence.
 */

const STORAGE_PREFIX = 'triberra_v1_';

export interface UserVault {
  activeTripId: string | null;
  history: Trip[];
  lastSynced: number;
}

interface RegisteredUser {
  username: string;
  password?: string;
  user: AuthUser;
}

export const DatabaseService = {
  // Credential Management
  async registerUser(userData: Omit<AuthUser, 'id'>, password?: string): Promise<AuthUser> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const usersRaw = localStorage.getItem(`${STORAGE_PREFIX}users_db`) || '[]';
        const users: RegisteredUser[] = JSON.parse(usersRaw);
        
        const newUser: AuthUser = {
          ...userData,
          id: 'user_' + Date.now(),
        };

        users.push({
          username: userData.username,
          password: password,
          user: newUser
        });

        localStorage.setItem(`${STORAGE_PREFIX}users_db`, JSON.stringify(users));
        resolve(newUser);
      }, 1000);
    });
  },

  async checkUserExists(username: string): Promise<boolean> {
    const usersRaw = localStorage.getItem(`${STORAGE_PREFIX}users_db`) || '[]';
    const users: RegisteredUser[] = JSON.parse(usersRaw);
    return users.some(u => u.username.toLowerCase() === username.toLowerCase());
  },

  async verifyUser(username: string, password?: string): Promise<AuthUser | null> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const usersRaw = localStorage.getItem(`${STORAGE_PREFIX}users_db`) || '[]';
        const users: RegisteredUser[] = JSON.parse(usersRaw);
        const entry = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
        resolve(entry ? entry.user : null);
      }, 800);
    });
  },

  // Simulate a network delay for "Cloud Fetching"
  async syncUserVault(userId: string): Promise<UserVault> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const raw = localStorage.getItem(`${STORAGE_PREFIX}vault_${userId}`);
        if (raw) {
          resolve(JSON.parse(raw));
        } else {
          resolve({ activeTripId: null, history: [], lastSynced: Date.now() });
        }
      }, 1200);
    });
  },

  async saveUserVault(userId: string, vault: UserVault): Promise<void> {
    const updatedVault = { ...vault, lastSynced: Date.now() };
    localStorage.setItem(`${STORAGE_PREFIX}vault_${userId}`, JSON.stringify(updatedVault));
  },

  async getActiveTrip(userId: string): Promise<Trip | null> {
    const activeIdRaw = localStorage.getItem(`${STORAGE_PREFIX}active_id_${userId}`);
    if (!activeIdRaw) return null;
    
    const tripRaw = localStorage.getItem(`${STORAGE_PREFIX}trip_${activeIdRaw}`);
    return tripRaw ? JSON.parse(tripRaw) : null;
  },

  async saveTrip(userId: string, trip: Trip): Promise<void> {
    localStorage.setItem(`${STORAGE_PREFIX}trip_${trip.id}`, JSON.stringify(trip));
    localStorage.setItem(`${STORAGE_PREFIX}active_id_${userId}`, trip.id);
  },

  async archiveTrip(userId: string, trip: Trip): Promise<void> {
    const vault = await this.syncUserVault(userId);
    // Avoid duplicates in history
    if (!vault.history.find(t => t.id === trip.id)) {
      vault.history.unshift(trip);
    }
    vault.activeTripId = null;
    await this.saveUserVault(userId, vault);
    localStorage.removeItem(`${STORAGE_PREFIX}active_id_${userId}`);
  },

  async deleteTrip(tripId: string): Promise<void> {
    localStorage.removeItem(`${STORAGE_PREFIX}trip_${tripId}`);
  }
};