
// DO NOT use or import the types below from @google/genai; these are deprecated APIs and no longer work.
// - Incorrect GoogleGenerativeAI
// - Incorrect google.generativeai
// - Incorrect models.create

import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { ExpenseCategory, AISuggestion, Member, WeatherInfo } from "../types";

// Export WeatherInfo so it can be used by other components importing from this service
export { WeatherInfo };

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface ParsedExpense {
  amount: number;
  description: string;
  category: ExpenseCategory;
  suggestedSplitIds?: string[];
  isExactSplit?: boolean;
  exactAmounts?: Record<string, number>;
}

export interface TravelAdvice {
  text: string;
  sources: { title: string; uri: string }[];
}

/**
 * Custom error class for API Quota issues
 */
export class QuotaExceededError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QuotaExceededError";
  }
}

/**
 * Utility function to handle Gemini API calls with exponential backoff and offline check.
 */
async function withRetry<T>(fn: () => Promise<T>, maxRetries = 2): Promise<T> {
  if (!navigator.onLine) {
    throw new Error("OFFLINE");
  }

  let lastError: any;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error: any) {
      lastError = error;
      
      // Handle the specific 429 Error
      const isQuotaError = error.status === 429 || 
                          (typeof error.message === 'string' && error.message.includes("quota")) ||
                          (error.error && error.error.code === 429);

      if (isQuotaError) {
        // 429 means "stop trying for a while". We throw immediately to let the UI handle it.
        throw new QuotaExceededError("Gemini API Quota Exhausted");
      }

      const isRetryable = error.status >= 500 && error.status <= 599;
      if (isRetryable && attempt < maxRetries - 1) {
        const delay = Math.pow(2, attempt) * 2000 + Math.random() * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      throw error;
    }
  }
  throw lastError;
}

export const parseExpenseFromText = async (text: string, members: Member[] = []): Promise<ParsedExpense | null> => {
  try {
    const memberContext = members.map(m => `"${m.name}" (ID: ${m.id})`).join(', ');
    
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        As a smart travel expense assistant, parse this statement: "${text}"
        
        CONTEXT:
        Available Trip Members: ${memberContext}
        Current Date: ${new Date().toLocaleDateString()}

        TASK:
        1. Extract the 'amount' as a number.
        2. Clean the 'description'.
        3. Select 'category': food, travel, hotel, shopping, or others.
        4. Determine who should split the cost. Return their Member IDs in 'suggestedSplitIds'.
        5. Identify complex splits. Return 'exactAmounts' mapping ID to number if specific shares are mentioned.

        Return ONLY a JSON object.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            amount: { type: Type.NUMBER },
            description: { type: Type.STRING },
            category: { type: Type.STRING, enum: ["food", "travel", "hotel", "shopping", "others"] },
            suggestedSplitIds: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING }
            },
            isExactSplit: { type: Type.BOOLEAN },
            exactAmounts: { 
              type: Type.OBJECT, 
              additionalProperties: { type: Type.NUMBER }
            }
          },
          required: ["amount", "description", "category"]
        }
      }
    })) as GenerateContentResponse;

    return JSON.parse(response.text?.trim() || "null") as ParsedExpense;
  } catch (error: any) {
    if (!(error instanceof QuotaExceededError)) {
      console.error("Gemini Parsing Error:", error);
    }
    return null;
  }
};

export const fetchWeatherForDestination = async (destination: string): Promise<WeatherInfo | null> => {
  try {
    // Single prompt to handle everything to save quota tokens/calls
    // Note: When using googleSearch, response.text might not be strictly JSON.
    // We omit responseMimeType and responseSchema to prioritize search grounding stability.
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Get current and tomorrow's weather for ${destination}. 
                 Provide the following information as a clean JSON object (no markdown, just the JSON):
                 {
                   "today": {"temp": "Current Temp", "cond": "Condition"},
                   "tomorrow": {"temp": "Tomorrow's Temp", "cond": "Condition"},
                   "recommendation": "Short travel tip based on this weather"
                 }`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    })) as GenerateContentResponse;

    const groundedChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as any[] | undefined;
    const sources = groundedChunks?.map((chunk: any) => ({
      title: chunk.web?.title || "Source",
      uri: chunk.web?.uri || ""
    })).filter((s: any) => s.uri) || [];

    // Defensive parsing for JSON in case of extra text from search grounding
    const text = response.text || "{}";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    const data = JSON.parse(jsonMatch ? jsonMatch[0] : "{}");
    
    return { ...data, sources };
  } catch (error: any) {
    if (error instanceof QuotaExceededError) {
      // Pass this up so the UI knows specifically it's a quota issue
      throw error;
    }
    console.warn("Gemini Weather Error (Non-Quota):", error.message);
    return null;
  }
};

export const generateTripImage = async (destination: string): Promise<string | null> => {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ 
          text: `A cinematic wide-angle photography shot of ${destination}. Hyper-realistic, professional color grading.` 
        }],
      },
      config: {
        imageConfig: { aspectRatio: "16:9" }
      }
    })) as GenerateContentResponse;

    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    return null;
  } catch (error: any) {
    if (!(error instanceof QuotaExceededError)) {
      console.error("Gemini Image Gen Error:", error);
    }
    return null;
  }
};

export const suggestItinerary = async (destination: string): Promise<AISuggestion[]> => {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Suggest 4 activities in ${destination}. Return JSON array of objects with title, time (HH:MM), location, notes.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              time: { type: Type.STRING },
              location: { type: Type.STRING },
              notes: { type: Type.STRING }
            },
            required: ["title", "time", "location", "notes"]
          }
        }
      }
    })) as GenerateContentResponse;
    return JSON.parse(response.text?.trim() || "[]");
  } catch (error: any) {
    return [];
  }
};

export const suggestLocationIdeas = async (destination: string, dateContext: string): Promise<string[]> => {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `List 6 landmarks in ${destination} for ${dateContext}. Return ONLY string array.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    })) as GenerateContentResponse;
    return JSON.parse(response.text?.trim() || "[]");
  } catch (error: any) {
    return [];
  }
};

export const askTravelAssistant = async (query: string, context: string): Promise<TravelAdvice> => {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Context: ${context}. User: ${query}`,
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: "Concise, grounded travel advice."
      }
    })) as GenerateContentResponse;

    // FIX: Fixed typo where groundedChunks was expected but groundingChunks was defined.
    const groundedChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as any[] | undefined;
    const sources = groundedChunks?.map((chunk: any) => ({
      title: chunk.web?.title || "Source",
      uri: chunk.web?.uri || ""
    })).filter((s: any) => s.uri) || [];

    return { text: response.text || "", sources };
  } catch (error: any) {
    return { text: "Trouble connecting to travel logs.", sources: [] };
  }
};
