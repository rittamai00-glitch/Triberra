
export type ExpenseCategory = 'food' | 'travel' | 'hotel' | 'shopping' | 'others';

export interface Member {
  id: string;
  name: string;
  avatar: string;
  isOrganizer?: boolean;
}

export interface UserPreferences {
  budgetAlerts: boolean;
  expenseUpdates: boolean;
  itineraryReminders: boolean;
}

export interface AuthUser {
  id: string;
  name: string;
  email?: string;
  username?: string;
  age?: string;
  gender?: string;
  avatar: string;
  provider: 'google' | 'credentials';
  preferences?: UserPreferences;
}

export interface Expense {
  id: string;
  amount: number;
  description: string;
  category: ExpenseCategory;
  date: string;
  paidBy: string; // Member ID
  splitAmong: string[]; // Array of Member IDs
  customSplit?: Record<string, number>; // Mapping member ID to specific amount
}

export interface ItineraryItem {
  id: string;
  title: string;
  time: string;
  date: string;
  location: string;
  notes?: string;
  isCompleted: boolean;
}

export interface Trip {
  id: string;
  inviteCode: string; // Unique code to share with others
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  members: Member[];
  expenses: Expense[];
  itinerary: ItineraryItem[];
  currency: string;
  budget: number;
  personalBudget?: number;
  memberBudgets?: Record<string, number>; // Map of member ID to their specific budget
  coverImage?: string; // AI generated cover
}

export interface Settlement {
  from: string;
  to: string;
  amount: number;
}

export interface AISuggestion {
  title: string;
  time: string;
  location: string;
  notes: string;
}

export interface DayForecast {
  temp: string;
  cond: string;
}

export interface WeatherInfo {
  today: DayForecast;
  tomorrow: DayForecast;
  recommendation: string;
  sources: { title: string; uri: string }[];
}

export interface AppNotification {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: number;
  isRead: boolean;
}
