
import { Expense, Member, Settlement } from "../types";

/**
 * Calculates net balances for all members relative to the group pot.
 * Uses rounding to avoid floating point errors.
 */
export const calculateBalances = (expenses: Expense[], members: Member[]) => {
  const balances: Record<string, number> = {};
  members.forEach(m => balances[m.id] = 0);

  expenses.forEach(exp => {
    const amount = Math.round(exp.amount * 100) / 100;
    // Who paid gets credit for the total amount
    if (balances.hasOwnProperty(exp.paidBy)) {
      balances[exp.paidBy] += amount;
    }
    
    // Split among members (debit)
    if (exp.customSplit) {
      Object.entries(exp.customSplit).forEach(([mId, amt]) => {
        if (balances.hasOwnProperty(mId)) {
          balances[mId] -= Math.round((amt as number) * 100) / 100;
        }
      });
    } else {
      const share = Math.round((amount / exp.splitAmong.length) * 100) / 100;
      exp.splitAmong.forEach(mId => {
        if (balances.hasOwnProperty(mId)) {
          balances[mId] -= share;
        }
      });
    }
  });

  return balances;
};

/**
 * Calculates the net relationship between every pair of users.
 * This ensures that if A owes B 500 and B owes A 200, the net is A owes B 300.
 */
export const calculateNetPairwiseBalances = (expenses: Expense[], members: Member[]) => {
  // matrix[A][B] = how much B owes A (gross)
  const matrix: Record<string, Record<string, number>> = {};
  members.forEach(m1 => {
    matrix[m1.id] = {};
    members.forEach(m2 => {
      matrix[m1.id][m2.id] = 0;
    });
  });

  expenses.forEach(exp => {
    const payerId = exp.paidBy;
    exp.splitAmong.forEach(memberId => {
      if (memberId === payerId) return; // Don't owe self

      const share = exp.customSplit ? (exp.customSplit[memberId] || 0) : (exp.amount / exp.splitAmong.length);
      
      // If it's a settlement, it counts as the payer "repaying" a debt
      // But logically, a settlement from B to A is B paying for A's share of nothing.
      // So B (payer) gets credit, and A (splitAmong) gets debited.
      if (matrix[payerId]) {
        matrix[payerId][memberId] += share;
      }
    });
  });

  // Now net them out: If A owes B 100 and B owes A 250, then B owes A 150.
  const netMatrix: Record<string, Record<string, number>> = {};
  members.forEach(m1 => {
    netMatrix[m1.id] = {};
    members.forEach(m2 => {
      if (m1.id === m2.id) return;
      
      const m1OwedByM2 = matrix[m1.id]?.[m2.id] || 0;
      const m2OwedByM1 = matrix[m2.id]?.[m1.id] || 0;
      
      if (m1OwedByM2 > m2OwedByM1) {
        netMatrix[m1.id][m2.id] = Math.max(0, Math.round((m1OwedByM2 - m2OwedByM1) * 100) / 100);
      } else {
        netMatrix[m1.id][m2.id] = 0;
      }
    });
  });

  return netMatrix;
};

/**
 * Provides a human-readable breakdown for a specific user based on NET values.
 */
export const calculateDetailedUserBalance = (expenses: Expense[], members: Member[], userId: string) => {
  const netMatrix = calculateNetPairwiseBalances(expenses, members);
  
  let lent = 0;     // Total others owe me (after netting)
  let borrowed = 0; // Total I owe others (after netting)

  // Sum up everything OTHERS owe ME
  if (netMatrix[userId]) {
    Object.values(netMatrix[userId]).forEach(amt => {
      lent += amt;
    });
  }

  // Sum up everything I owe OTHERS
  members.forEach(m => {
    if (m.id === userId) return;
    borrowed += (netMatrix[m.id]?.[userId] || 0);
  });

  return {
    lent: Math.round(lent * 100) / 100,
    borrowed: Math.round(borrowed * 100) / 100,
    net: Math.round((lent - borrowed) * 100) / 100
  };
};

/**
 * Optimized settlement algorithm to minimize transaction count.
 */
export const optimizeSettlements = (balances: Record<string, number>): Settlement[] => {
  const settlements: Settlement[] = [];
  const debtors = Object.entries(balances)
    .filter(([_, bal]) => bal < -0.01)
    .map(([id, bal]) => ({ id, amount: Math.abs(bal) }));
  
  const creditors = Object.entries(balances)
    .filter(([_, bal]) => bal > 0.01)
    .map(([id, bal]) => ({ id, amount: bal }));

  let i = 0, j = 0;
  while (i < debtors.length && j < creditors.length) {
    const payAmount = Math.min(debtors[i].amount, creditors[j].amount);
    
    if (payAmount > 0.01) {
      settlements.push({
        from: debtors[i].id,
        to: creditors[j].id,
        amount: Math.round(payAmount * 100) / 100
      });
    }

    debtors[i].amount -= payAmount;
    creditors[j].amount -= payAmount;

    if (debtors[i].amount < 0.01) i++;
    if (creditors[j].amount < 0.01) j++;
  }

  return settlements;
};
