
import React, { useState, useRef, useMemo, useEffect } from 'react';
import SharedLayout from '../components/SharedLayout';
import { Member, ExpenseCategory, Expense, AuthUser } from '../types';
import { 
  X, User, Hash, FileText, Scale, Coins, AlertCircle, 
  Wand2, Sparkles, Loader2, Zap, Utensils, Plane, 
  Hotel, ShoppingBag, Layers, CheckCircle2, IndianRupee,
  MinusCircle, PlusCircle, ArrowDownCircle
} from 'lucide-react';
import { parseExpenseFromText } from '../services/geminiService';
import { useNavigate } from 'react-router-dom';

const CATEGORY_OPTIONS: { id: ExpenseCategory; label: string; icon: React.ReactNode }[] = [
  { id: 'food', label: 'Food', icon: <Utensils size={14} /> },
  { id: 'travel', label: 'Travel', icon: <Plane size={14} /> },
  { id: 'hotel', label: 'Hotel', icon: <Hotel size={14} /> },
  { id: 'shopping', label: 'Shopping', icon: <ShoppingBag size={14} /> },
  { id: 'others', label: 'Others', icon: <Layers size={14} /> },
];

// Define missing AddExpenseViewProps interface
interface AddExpenseViewProps {
  user: AuthUser;
  members: Member[];
  onAdd: (expense: Omit<Expense, 'id'>) => void;
}

const AddExpenseView: React.FC<AddExpenseViewProps> = ({ user, members, onAdd }) => {
  const navigate = useNavigate();
  const [isOnline] = useState(navigator.onLine);
  
  // Primary Form State
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('others');
  const [paidBy, setPaidBy] = useState(members[0]?.id || '');
  const [selectedSplit, setSelectedSplit] = useState<string[]>(members.map(m => m.id));
  const [splitType, setSplitType] = useState<'equal' | 'exact'>('equal');
  const [customAmounts, setCustomAmounts] = useState<Record<string, string>>({});
  
  // Smart Feature State
  const [naturalInput, setNaturalInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSmartInput, setShowSmartInput] = useState(false);
  const [lastParsedByAI, setLastParsedByAI] = useState<Set<string>>(new Set());

  const totalBill = parseFloat(amount) || 0;
  
  const currentSplitTotal = useMemo(() => {
    if (splitType === 'equal') return totalBill;
    return (Object.values(customAmounts) as string[]).reduce((sum, val) => sum + (parseFloat(val) || 0), 0);
  }, [splitType, customAmounts, totalBill]);

  const difference = totalBill - currentSplitTotal;
  const isBalanced = Math.abs(difference) < 0.1;
  const isOver = difference < -0.1;
  const percentFilled = totalBill > 0 ? Math.min(100, (currentSplitTotal / totalBill) * 100) : 0;

  const handleSmartFill = (memberId: string) => {
    const remaining = totalBill - (currentSplitTotal - (parseFloat(customAmounts[memberId]) || 0));
    setCustomAmounts(prev => ({
      ...prev,
      [memberId]: Math.max(0, remaining).toFixed(0)
    }));
  };

  const handleMagicFill = async () => {
    if (!naturalInput.trim()) return;
    setIsProcessing(true);
    setLastParsedByAI(new Set());
    
    try {
      const parsed = await parseExpenseFromText(naturalInput, members);
      if (parsed) {
        const newParsedKeys = new Set<string>();
        if (parsed.amount) { setAmount(parsed.amount.toString()); newParsedKeys.add('amount'); }
        if (parsed.description) { setDescription(parsed.description); newParsedKeys.add('description'); }
        if (parsed.category) { setCategory(parsed.category); newParsedKeys.add('category'); }
        if (parsed.suggestedSplitIds && parsed.suggestedSplitIds.length > 0) { setSelectedSplit(parsed.suggestedSplitIds); newParsedKeys.add('split'); }
        if (parsed.isExactSplit && parsed.exactAmounts) {
          setSplitType('exact');
          const newExacts: Record<string, string> = {};
          Object.entries(parsed.exactAmounts).forEach(([id, val]) => { newExacts[id] = val.toString(); });
          setCustomAmounts(newExacts);
          newParsedKeys.add('exact');
        } else {
          setSplitType('equal');
        }
        setLastParsedByAI(newParsedKeys);
        setShowSmartInput(false);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSubmit = () => {
    if (totalBill <= 0) return alert("Please enter a valid amount.");
    if (!description.trim()) return alert("Please enter a description.");
    if (selectedSplit.length === 0) return alert("Please select who is splitting this bill.");
    
    if (splitType === 'exact' && !isBalanced) {
      return alert(`Split total (₹${currentSplitTotal}) must match total bill (₹${totalBill}). You have ₹${Math.abs(difference)} remaining.`);
    }

    const finalCustomSplit: Record<string, number> | undefined = splitType === 'exact' 
      ? Object.fromEntries(
          (Object.entries(customAmounts) as [string, string][])
            .filter(([mId]) => selectedSplit.includes(mId))
            .map(([mId, amt]) => [mId, parseFloat(amt) || 0])
        )
      : undefined;

    onAdd({
      amount: totalBill,
      description: description.trim(),
      category,
      date: new Date().toISOString().split('T')[0],
      paidBy,
      splitAmong: selectedSplit,
      customSplit: finalCustomSplit
    });
    navigate('/expenses');
  };

  const toggleMemberSelection = (id: string) => {
    if (selectedSplit.includes(id)) {
      if (selectedSplit.length > 1) {
        setSelectedSplit(prev => prev.filter(sid => sid !== id));
      }
    } else {
      setSelectedSplit(prev => [...prev, id]);
    }
  };

  return (
    <SharedLayout showTabs={false} title="Log Expense">
      <div className="space-y-6 pb-24 text-slate-100">
        
        {/* Navigation & Header */}
        <div className="flex justify-between items-center px-2">
           <button onClick={() => navigate(-1)} className="p-3 bg-white dark:bg-slate-900 rounded-2xl text-slate-500 shadow-xl shadow-slate-200/50 dark:shadow-none transition-all active:scale-90 border border-slate-100 dark:border-white/5">
             <X size={20} />
           </button>
           <h2 className="text-sm font-black uppercase tracking-widest text-slate-900 dark:text-slate-100">Add Transaction</h2>
           <button 
             onClick={handleSubmit} 
             className="bg-indigo-600 text-white px-6 py-2.5 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-indigo-900/20 transition-all active:scale-95"
           >
             Save
           </button>
        </div>

        {/* Amount Input */}
        <div className="text-center py-4 relative group">
           <div className={`inline-flex items-center gap-2 transition-transform duration-500 ${lastParsedByAI.has('amount') ? 'scale-110' : ''}`}>
             <span className="text-3xl font-black text-slate-300">₹</span>
             <input 
               type="number" 
               className="bg-transparent text-6xl font-black text-slate-900 dark:text-slate-100 focus:outline-none w-48 text-center placeholder:text-slate-200 drop-shadow-sm"
               value={amount}
               placeholder="0"
               onChange={(e) => setAmount(e.target.value)}
             />
           </div>
           {lastParsedByAI.has('amount') && <Sparkles size={14} className="absolute top-0 right-1/4 text-indigo-400 animate-pulse" />}
        </div>

        {/* Details Card */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] mx-2 p-6 shadow-xl shadow-slate-200/60 dark:shadow-none border border-slate-100 dark:border-slate-800 space-y-6">
           <div className="flex items-center gap-4 group">
             <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-slate-950 flex items-center justify-center text-slate-400 group-focus-within:text-indigo-500 transition-colors shadow-inner">
                <FileText size={18} />
             </div>
             <div className="flex-1 relative">
               <label className="block text-[8px] uppercase font-black text-slate-400 mb-0.5 tracking-widest">Description</label>
               <input 
                 type="text" 
                 placeholder="What was this for?" 
                 className="w-full text-sm font-black bg-transparent focus:outline-none text-slate-900 dark:text-slate-100" 
                 value={description} 
                 onChange={(e) => setDescription(e.target.value)} 
               />
             </div>
           </div>

           <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-slate-950 flex items-center justify-center text-slate-400 shadow-inner"><Hash size={18} /></div>
             <div className="flex-1 overflow-hidden">
               <label className="block text-[8px] uppercase font-black text-slate-400 mb-2 tracking-widest">Category</label>
               <div className="flex gap-2 overflow-x-auto pb-1 custom-scrollbar">
                 {CATEGORY_OPTIONS.map(cat => (
                   <button 
                     key={cat.id} 
                     onClick={() => setCategory(cat.id)} 
                     className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-tight flex items-center gap-1.5 transition-all border ${category === cat.id ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900 dark:border-white shadow-lg' : 'bg-transparent text-slate-400 border-slate-100 dark:border-slate-800 hover:shadow-md'}`}
                   >
                     {cat.icon}
                     {cat.label}
                   </button>
                 ))}
               </div>
             </div>
           </div>

           <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-slate-950 flex items-center justify-center text-slate-400 shadow-inner"><User size={18} /></div>
             <div className="flex-1">
               <label className="block text-[8px] uppercase font-black text-slate-400 mb-0.5 tracking-widest">Paid By</label>
               <select 
                className="w-full text-sm font-black focus:outline-none bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border border-slate-100 dark:border-slate-800 rounded-xl px-2 py-1 appearance-none cursor-pointer shadow-sm focus:ring-4 focus:ring-indigo-500/5 transition-all" 
                value={paidBy} 
                onChange={(e) => setPaidBy(e.target.value)}
               >
                 {members.map(m => ( 
                   <option key={m.id} value={m.id} className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold">
                     {m.name}
                   </option> 
                 ))}
               </select>
             </div>
           </div>
        </div>

        {/* Split Logic Toggle */}
        <div className="bg-slate-200 dark:bg-slate-950 rounded-2xl p-1 flex mx-4 border border-slate-100 dark:border-slate-800 shadow-inner">
          <button onClick={() => setSplitType('equal')} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${splitType === 'equal' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-cyan-400 shadow-md' : 'text-slate-500'}`}><Scale size={14} /> Split Equally</button>
          <button onClick={() => setSplitType('exact')} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${splitType === 'exact' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-cyan-400 shadow-md' : 'text-slate-500'}`}><Coins size={14} /> Add Individually</button>
        </div>

        {/* Buddy List & Exact Split Inputs */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] mx-2 p-6 shadow-xl shadow-slate-200/60 dark:shadow-none border border-slate-100 dark:border-slate-800">
           <div className="mb-6 space-y-4">
             <div className="flex items-center justify-between">
               <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-800 dark:text-slate-200">Split Breakdown</h3>
               {splitType === 'exact' && (
                 <div className={`px-3 py-1 rounded-full text-[9px] font-black flex items-center gap-1.5 transition-all shadow-sm ${isBalanced ? 'bg-emerald-500 text-white shadow-emerald-900/10' : isOver ? 'bg-rose-500 text-white shadow-rose-900/10' : 'bg-amber-500 text-white shadow-amber-900/10'}`}>
                   {isBalanced ? <CheckCircle2 size={10} /> : <AlertCircle size={10} />}
                   {isBalanced ? 'BALANCED' : isOver ? `OVER BY ₹${Math.abs(difference).toLocaleString()}` : `₹${Math.abs(difference).toLocaleString()} REMAINING`}
                 </div>
               )}
             </div>

             {splitType === 'exact' && totalBill > 0 && (
                <div className="space-y-2">
                   <div className="flex justify-between items-center text-[8px] font-black uppercase text-slate-400 tracking-tighter">
                      <span>Allocated: ₹{Math.round(currentSplitTotal).toLocaleString()}</span>
                      <span>Goal: ₹{Math.round(totalBill).toLocaleString()}</span>
                   </div>
                   <div className="h-1.5 bg-slate-100 dark:bg-slate-950 rounded-full overflow-hidden shadow-inner">
                      <div 
                        className={`h-full transition-all duration-500 ${isBalanced ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]' : isOver ? 'bg-rose-500' : 'bg-amber-500'}`}
                        style={{ width: `${percentFilled}%` }}
                      ></div>
                   </div>
                </div>
             )}
           </div>

           <div className="space-y-3">
             {members.map(m => {
               const isSelected = selectedSplit.includes(m.id);
               return (
                 <div key={m.id} className={`flex flex-col p-4 rounded-3xl transition-all border ${isSelected ? 'bg-slate-50/50 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800 shadow-sm' : 'bg-transparent border-transparent opacity-30 grayscale cursor-pointer'}`} onClick={() => !isSelected && toggleMemberSelection(m.id)}>
                   <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3" onClick={(e) => { e.stopPropagation(); toggleMemberSelection(m.id); }}>
                         <div className="relative">
                            <img src={m.avatar} className="w-10 h-10 rounded-2xl border-2 border-white dark:border-slate-800 shadow-md" alt="" />
                            {isSelected && <div className="absolute -bottom-1 -right-1 bg-emerald-500 w-3 h-3 rounded-full border-2 border-white dark:border-slate-950"></div>}
                         </div>
                         <div>
                           <span className="text-[11px] font-black text-slate-800 dark:text-slate-200 block leading-none">{m.name}</span>
                           {isSelected && splitType === 'equal' && <span className="text-[9px] font-bold text-slate-400 uppercase">₹{(totalBill / (selectedSplit.length || 1)).toFixed(0)}</span>}
                         </div>
                      </div>

                      {isSelected && splitType === 'exact' && (
                        <div className="flex items-center gap-2">
                           {!isBalanced && !isOver && (
                             <button 
                               onClick={(e) => { e.stopPropagation(); handleSmartFill(m.id); }}
                               className="p-2 bg-indigo-500/10 text-indigo-500 rounded-xl hover:bg-indigo-500 hover:text-white transition-all shadow-sm"
                               title="Fill Remaining"
                             >
                                <Zap size={14} />
                             </button>
                           )}
                           <div className="flex items-center gap-2 bg-white dark:bg-slate-950 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 focus-within:ring-4 focus-within:ring-indigo-500/5 transition-all shadow-inner">
                              <span className="text-[10px] font-black text-slate-300">₹</span>
                              <input 
                                type="number" 
                                className="bg-transparent text-slate-900 dark:text-slate-100 text-xs font-black focus:outline-none w-16 text-right" 
                                value={customAmounts[m.id] || ''} 
                                onClick={(e) => e.stopPropagation()}
                                onChange={(e) => setCustomAmounts(prev => ({ ...prev, [m.id]: e.target.value }))} 
                              />
                           </div>
                        </div>
                      )}
                   </div>
                 </div>
               );
             })}
           </div>
        </div>
      </div>
    </SharedLayout>
  );
};

export default AddExpenseView;
