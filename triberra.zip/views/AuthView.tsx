import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Mail, Lock, User as UserIcon, ArrowRight, Loader2, 
  Sparkles, Users, Wallet, Zap, ShieldCheck, Share2, 
  ArrowLeft, CheckCircle2, UserCircle, Calendar, Users2, AlertCircle, X as CloseIcon
} from 'lucide-react';
import { AuthUser } from '../types';
import { DatabaseService } from '../services/databaseService';

interface AuthViewProps {
  onLogin: (user: AuthUser) => void;
}

const AuthView: React.FC<AuthViewProps> = ({ onLogin }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState<'login' | 'signup' | 'google_loading' | 'google_accounts' | 'forgot_password'>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [failedAttempts, setFailedAttempts] = useState(0);

  // Form States
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  
  // Signup specific
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other' | ''>('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      alert("First fill the username and password and then click the Log In button.");
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    // Check if user exists first
    const exists = await DatabaseService.checkUserExists(username);
    
    if (!exists) {
      setError("Account not found. Please create one first.");
      setIsLoading(false);
      return;
    }

    const user = await DatabaseService.verifyUser(username, password);
    
    if (user) {
      setFailedAttempts(0);
      onLogin(user);
      navigate('/');
    } else {
      setFailedAttempts(prev => prev + 1);
      setError('Invalid password. Please try again.');
      setIsLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) { alert("First fill the name and then click the Register button."); return; }
    if (!username) { alert("First fill the username and then click the Register button."); return; }
    if (!age) { alert("First fill the age and then click the Register button."); return; }
    if (!gender) { alert("First fill the gender and then click the Register button."); return; }
    if (!password) { alert("First fill the password and then click the Register button."); return; }

    setIsLoading(true);
    setError('');

    // Check if username is taken
    const exists = await DatabaseService.checkUserExists(username);
    if (exists) {
      setError("Username is already taken.");
      setIsLoading(false);
      return;
    }

    try {
      const newUser = await DatabaseService.registerUser({
        name,
        username,
        age,
        gender,
        avatar: `https://picsum.photos/seed/${username}/200`,
        provider: 'credentials'
      }, password);

      onLogin(newUser);
      navigate('/');
    } catch (err) {
      setError('Registration failed. Try again.');
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = () => {
    setStep('google_loading');
    setTimeout(() => {
      setStep('google_accounts');
    }, 1200);
  };

  const selectGoogleAccount = (acc: any) => {
    setIsLoading(true);
    setTimeout(() => {
      const newUser: AuthUser = {
        id: 'google-' + Date.now(),
        name: acc.name,
        email: acc.email,
        avatar: acc.avatar,
        provider: 'google'
      };
      onLogin(newUser);
      navigate('/');
    }, 1500);
  };

  const mockGoogleAccounts = [
    { name: 'John Doe', email: 'john.doe@gmail.com', avatar: 'https://picsum.photos/seed/john/100' },
    { name: 'Alice Smith', email: 'alice.travels@gmail.com', avatar: 'https://picsum.photos/seed/alice/100' }
  ];

  const trustBadges = [
    { text: "Safe Group Sharing", icon: <Share2 size={12} /> },
    { text: "Trusted by Travelers", icon: <Users size={12} /> },
    { text: "Secure & Reliable", icon: <ShieldCheck size={12} /> },
    { text: "AI Trip Planning", icon: <Zap size={12} /> },
    { text: "Easy Expense Split", icon: <Wallet size={12} /> },
  ];

  return (
    <div className="min-h-screen max-w-md mx-auto bg-slate-50 dark:bg-slate-950 flex flex-col p-8 relative overflow-hidden transition-colors">
      
      {/* Background Orbs */}
      <div className="absolute top-[-5%] left-[-10%] w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-[-5%] right-[-10%] w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl"></div>

      <div className="relative z-10 flex flex-col h-full">
        <div className="pt-12 mb-8 text-center">
          <div className="mx-auto inline-block">
            <h1 className="text-6xl font-brand pb-0 leading-none bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-cyan-500 drop-shadow-sm">
              Triberra
            </h1>
          </div>
          <p className="text-slate-500 dark:text-slate-400 text-xs font-black uppercase tracking-[0.3em] mt-0.5">
            Journey, Simplified
          </p>
        </div>

        {/* Login Step */}
        {step === 'login' && (
          <div className="space-y-6 animate-in fade-in duration-500">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Username</label>
                <div className="relative group">
                  <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                  <input 
                    type="text"
                    required
                    placeholder="Enter username"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl py-4 pl-12 pr-5 text-sm font-bold focus:ring-4 focus:ring-indigo-500/5 focus:border-indigo-500/30 focus:outline-none shadow-[0_4px_12px_rgba(0,0,0,0.03)] dark:shadow-none transition-all"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Password</label>
                <div className="relative group">
                  <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                  <input 
                    type="password"
                    required
                    placeholder="Enter password"
                    className="w-full bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl py-4 pl-12 pr-5 text-sm font-bold focus:ring-4 focus:ring-indigo-500/5 focus:border-indigo-500/30 focus:outline-none shadow-[0_4px_12px_rgba(0,0,0,0.03)] dark:shadow-none transition-all"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                  />
                </div>
              </div>

              {error && (
                <div className="px-1 flex items-center gap-1.5 animate-in fade-in slide-in-from-top-1">
                  <AlertCircle size={12} className="text-rose-500" />
                  <p className="text-[10px] font-bold text-rose-500">{error}</p>
                </div>
              )}

              <button 
                type="submit"
                disabled={isLoading}
                className="w-full bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 py-4 rounded-[2rem] font-black shadow-xl shadow-slate-900/20 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                {isLoading ? <Loader2 className="animate-spin" /> : 'Log In'}
              </button>

              {failedAttempts >= 3 && (
                <button 
                  type="button"
                  onClick={() => setStep('forgot_password')}
                  className="w-full text-center text-[10px] font-black text-rose-500 uppercase tracking-widest animate-pulse"
                >
                  Forgot Password?
                </button>
              )}
            </form>

            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100 dark:border-slate-800"></div></div>
              <div className="relative flex justify-center text-[10px] uppercase font-black tracking-widest text-slate-400"><span className="bg-slate-50 dark:bg-slate-950 px-4">OR</span></div>
            </div>

            <button 
              onClick={handleGoogleLogin}
              className="w-full bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 rounded-[2rem] flex items-center gap-4 shadow-[0_8px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_12px_24px_rgba(0,0,0,0.06)] hover:border-indigo-200 transition-all group active:scale-95"
            >
              <div className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-center group-hover:bg-indigo-50 transition-colors">
                <Mail size={20} className="text-slate-600 dark:text-slate-300 group-hover:text-indigo-600" />
              </div>
              <p className="text-sm font-black">Continue with Gmail</p>
              <ArrowRight className="ml-auto text-slate-300 group-hover:text-indigo-500 transition-colors" size={18} />
            </button>

            <button 
              onClick={() => {
                setError('');
                setStep('signup');
              }}
              className="w-full py-4 text-xs font-black text-indigo-600 dark:text-cyan-400 uppercase tracking-widest hover:underline"
            >
              Create New Account
            </button>
          </div>
        )}

        {/* Signup Step */}
        {step === 'signup' && (
          <div className="animate-in fade-in slide-in-from-right-4 duration-500 space-y-6">
            <button onClick={() => {
              setError('');
              setStep('login');
            }} className="flex items-center gap-2 text-slate-400 font-black text-[10px] uppercase tracking-widest">
              <ArrowLeft size={16} /> Back to Login
            </button>
            <h2 className="text-2xl font-black mb-2">Create Account</h2>
            
            <form onSubmit={handleSignup} className="space-y-4">
              <div className="space-y-4 bg-white dark:bg-slate-900 p-6 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-[0_10px_40px_rgba(0,0,0,0.03)] dark:shadow-none">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Full Name</label>
                  <div className="relative group">
                    <UserCircle className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500" size={18} />
                    <input type="text" required placeholder="John Doe" className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-xl py-3 pl-11 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/10" value={name} onChange={e => setName(e.target.value)} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Age</label>
                    <div className="relative group">
                      <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500" size={18} />
                      <input type="number" required placeholder="25" className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-xl py-3 pl-11 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/10" value={age} onChange={e => setAge(e.target.value)} />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Gender</label>
                    <div className="relative group">
                      <Users2 className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500" size={18} />
                      <select required className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-xl py-3 pl-11 pr-2 text-sm font-bold focus:outline-none appearance-none focus:ring-2 focus:ring-indigo-500/10" value={gender} onChange={e => setGender(e.target.value as any)}>
                        <option value="">Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Choose Username</label>
                  <input type="text" required placeholder="@traveler_01" className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-xl py-3 px-4 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/10" value={username} onChange={e => setUsername(e.target.value)} />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-slate-400 ml-1">New Password</label>
                  <input type="password" required placeholder="••••••••" className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-xl py-3 px-4 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/10" value={password} onChange={e => setPassword(e.target.value)} />
                </div>
              </div>

              {error && (
                <div className="px-1 flex items-center gap-1.5 animate-in fade-in slide-in-from-top-1">
                  <AlertCircle size={12} className="text-rose-500" />
                  <p className="text-[10px] font-bold text-rose-500">{error}</p>
                </div>
              )}

              <button 
                type="submit"
                disabled={isLoading}
                className="w-full bg-indigo-600 text-white py-4 rounded-[2rem] font-black shadow-xl shadow-indigo-900/20 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                {isLoading ? <Loader2 className="animate-spin" /> : 'Register Now'}
              </button>
            </form>
          </div>
        )}

        {/* Forgot Password Mock */}
        {step === 'forgot_password' && (
          <div className="animate-in fade-in zoom-in-95 duration-500 bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 shadow-2xl border border-slate-100 dark:border-slate-800 text-center">
            <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-indigo-500/10">
              <ShieldCheck size={32} />
            </div>
            <h2 className="text-xl font-black mb-2">Reset Password</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-8 leading-relaxed">
              We've sent a recovery link to your registered email address associated with <span className="font-bold text-slate-900 dark:text-white">@{username}</span>.
            </p>
            <button 
              onClick={() => {
                setStep('login');
                setFailedAttempts(0);
                setError('');
              }}
              className="w-full bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 py-4 rounded-2xl font-black text-sm active:scale-95 transition-all shadow-lg"
            >
              Back to Login
            </button>
          </div>
        )}

        {/* Google Mock Loading */}
        {step === 'google_loading' && (
          <div className="flex-1 flex flex-col items-center justify-center animate-in fade-in duration-500">
            <Loader2 size={48} className="text-indigo-600 animate-spin mb-6" />
            <p className="font-black text-slate-500 uppercase tracking-[0.2em] text-xs">Connecting to Google...</p>
          </div>
        )}

        {/* Google Mock Accounts */}
        {step === 'google_accounts' && (
          <div className="animate-in fade-in zoom-in-95 duration-500 bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 shadow-2xl border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-8">
               <h2 className="text-xl font-black">Choose account</h2>
               <button onClick={() => setStep('login')} className="p-2 text-slate-400 hover:bg-slate-50 rounded-full transition-colors"><CloseIcon size={20} /></button>
            </div>
            <div className="space-y-4">
              {mockGoogleAccounts.map((acc, i) => (
                <button 
                  key={i} 
                  onClick={() => selectGoogleAccount(acc)}
                  disabled={isLoading}
                  className="w-full flex items-center gap-4 p-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-2xl transition-all border border-transparent hover:border-slate-100 shadow-sm hover:shadow-md"
                >
                  <img src={acc.avatar} className="w-12 h-12 rounded-full border-2 border-white dark:border-slate-700 shadow-sm" alt="" />
                  <div className="text-left">
                    <p className="text-sm font-black">{acc.name}</p>
                    <p className="text-[10px] text-slate-400 font-bold">{acc.email}</p>
                  </div>
                </button>
              ))}
              <button className="w-full text-slate-400 font-bold text-xs py-2 hover:text-slate-600 transition-colors uppercase tracking-widest">Use another account</button>
            </div>
          </div>
        )}

        {/* Footer with Badges */}
        <div className="mt-auto pt-8 pb-4 text-center border-t border-slate-100 dark:border-slate-900 space-y-6">
           <div className="flex flex-wrap justify-center gap-2 px-2">
             {trustBadges.map((badge, idx) => (
               <div 
                 key={idx} 
                 className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-full shadow-sm animate-in fade-in slide-in-from-bottom-2"
                 style={{ animationDelay: `${idx * 100}ms`, animationFillMode: 'both' }}
               >
                 <span className="text-indigo-500 dark:text-cyan-400 flex-shrink-0">
                   {badge.icon}
                 </span>
                 <span className="text-[8px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider text-left leading-tight">
                   {badge.text}
                 </span>
               </div>
             ))}
           </div>

           <p className="text-[9px] text-slate-400 leading-relaxed px-4 opacity-70">
             By continuing, you agree to Triberra's <span className="underline">Terms</span> and <span className="underline">Privacy Policy</span>. We encrypt all your trip data end-to-end.
           </p>
        </div>
      </div>
    </div>
  );
};

export default AuthView;