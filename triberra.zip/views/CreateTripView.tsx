import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trip, Member, AuthUser } from '../types';
import { 
  ChevronLeft, MapPin, IndianRupee, Users, X, 
  UserPlus, Wallet, Sparkles, Info
} from 'lucide-react';

interface CreateTripViewProps {
  user: AuthUser;
  onCreate: (trip: Trip) => void;
}

const CreateTripView: React.FC<CreateTripViewProps> = ({ user, onCreate }) => {
  const navigate = useNavigate();
  const [dest, setDest] = useState('');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [groupBudget, setGroupBudget] = useState('');
  const [myBudget, setMyBudget] = useState('');
  
  const [members, setMembers] = useState<string[]>([]);
  const [newMemberName, setNewMemberName] = useState('');

  // Info visibility states
  const [showGroupInfo, setShowGroupInfo] = useState(false);
  const [showPersonalInfo, setShowPersonalInfo] = useState(false);

  // Indian Numbering System to Words
  const numberToWords = (numStr: string): string => {
    const num = parseInt(numStr);
    if (isNaN(num) || num === 0) return "";
    
    const a = ['', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ', 'Ten ', 'Eleven ', 'Twelve ', 'Thirteen ', 'Fourteen ', 'Fifteen ', 'Sixteen ', 'Seventeen ', 'Eighteen ', 'Nineteen '];
    const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

    const inWords = (n: number): string => {
      if (n < 20) return a[n];
      if (n < 100) return b[Math.floor(n / 10)] + ' ' + a[n % 10];
      if (n < 1000) return inWords(Math.floor(n / 100)) + 'Hundred ' + inWords(n % 100);
      if (n < 100000) return inWords(Math.floor(n / 1000)) + 'Thousand ' + inWords(n % 1000);
      if (n < 10000000) return inWords(Math.floor(n / 100000)) + 'Lakh ' + inWords(n % 100000);
      return inWords(Math.floor(n / 10000000)) + 'Crore ' + inWords(n % 10000000);
    };

    return inWords(num).trim() + " Only";
  };

  const generateInviteCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = 'TRV-';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  const handleAddMember = () => {
    if (newMemberName.trim()) {
      setMembers([...members, newMemberName.trim()]);
      setNewMemberName('');
    } else {
      alert("First fill the member name and then click the ADD button.");
    }
  };

  const removeMember = (index: number) => {
    setMembers(members.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dest) { alert("First fill the destination and then click the Create Trip button."); return; }
    if (!start) { alert("First fill the start date and then click the Create Trip button."); return; }
    if (!end) { alert("First fill the end date and then click the Create Trip button."); return; }
    if (!groupBudget) { alert("First fill the group budget and then click the Create Trip button."); return; }
    if (!myBudget) { alert("First fill your personal limit and then click the Create Trip button."); return; }
    
    const tripMembers: Member[] = [
      { 
        id: user.id, 
        name: user.name, 
        avatar: user.avatar,
        isOrganizer: true 
      },
      ...members.map((m, i) => ({
        id: (Date.now() + i + 1).toString(),
        name: m,
        avatar: `https://picsum.photos/seed/${m}/100`
      }))
    ];

    const newTrip: Trip = {
      id: Date.now().toString(),
      inviteCode: generateInviteCode(),
      name: dest || 'Our Adventure',
      destination: dest || 'Unknown Location',
      startDate: start || new Date().toISOString().split('T')[0],
      endDate: end || new Date().toISOString().split('T')[0],
      currency: 'INR',
      budget: parseFloat(groupBudget) || 100000,
      personalBudget: parseFloat(myBudget) || 25000,
      members: tripMembers,
      expenses: [],
      itinerary: []
    };
    
    onCreate(newTrip);
    navigate('/');
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-slate-50 dark:bg-slate-950 px-6 py-10 text-slate-900 dark:text-slate-100 transition-colors relative">
      <button onClick={() => navigate('/')} className="mb-6 p-3 bg-white dark:bg-slate-900 rounded-2xl shadow-sm text-slate-500 hover:text-indigo-600 transition-all active:scale-90 border border-slate-200/50 dark:border-white/5">
        <ChevronLeft size={20} />
      </button>

      <div className="mb-10 text-center">
         <div className="mb-1 mx-auto inline-block">
            <h1 className="text-5xl font-brand bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-cyan-500 drop-shadow-sm pb-0 leading-none">
              Triberra
            </h1>
         </div>
         <h1 className="text-2xl font-black tracking-tight">Plan New Trip</h1>
         <p className="text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-[0.3em] mt-1">Digital Travel Vault</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 pb-24">
        <div className="bg-white dark:bg-slate-900 p-7 rounded-[2.5rem] shadow-sm border border-slate-200/60 dark:border-white/5 space-y-6">
          <div className="relative">
             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Destination</label>
             <div className="relative">
               <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
               <input 
                type="text" 
                placeholder="Where are you going?" 
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-[1.5rem] py-4 pl-12 pr-4 border border-slate-200/60 dark:border-white/5 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-sm" 
                value={dest} 
                onChange={e => setDest(e.target.value)} 
               />
             </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
               <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Arrival</label>
               <input type="date" className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-[1.2rem] py-3 px-4 border border-slate-200/60 dark:border-white/5 focus:outline-none text-xs font-bold" value={start} onChange={e => setStart(e.target.value)} />
            </div>
            <div>
               <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Departure</label>
               <input type="date" className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-[1.2rem] py-3 px-4 border border-slate-200/60 dark:border-white/5 focus:outline-none text-xs font-bold" value={end} onChange={e => setEnd(e.target.value)} />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-7 rounded-[2.5rem] shadow-sm border border-slate-200/60 dark:border-white/5 space-y-7">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-indigo-500/10 text-indigo-500 rounded-2xl flex items-center justify-center">
               <Wallet size={20} />
            </div>
            <h3 className="font-black text-sm uppercase tracking-widest">Budget Allocation</h3>
          </div>
          
          <div className="space-y-8">
            <div className="relative">
              <div className="flex justify-between items-center mb-2.5 ml-1">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Group Total</label>
                <button 
                  type="button" 
                  onClick={() => setShowGroupInfo(!showGroupInfo)}
                  className="text-slate-300 hover:text-indigo-500 transition-colors"
                >
                  <Info size={16} />
                </button>
              </div>
              {showGroupInfo && (
                <div className="absolute z-20 bottom-full left-0 mb-3 w-64 p-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-[1.5rem] text-[10px] font-bold leading-relaxed shadow-2xl animate-in fade-in slide-in-from-bottom-2">
                  Estimated total cost for everyone. We'll monitor all group spending against this.
                </div>
              )}
              <div className="relative">
                <IndianRupee size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="number" 
                  placeholder="Total trip budget" 
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-[1.5rem] py-4 pl-12 pr-4 border border-slate-200/60 dark:border-white/5 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-black text-lg" 
                  value={groupBudget} 
                  onChange={e => setGroupBudget(e.target.value)} 
                />
              </div>
              {groupBudget && (
                <div className="mt-2.5 ml-1 animate-in fade-in slide-in-from-left-2 duration-300">
                  <div className="inline-block bg-indigo-50/50 dark:bg-indigo-900/10 px-3 py-1.5 rounded-xl border border-indigo-100/50 dark:border-indigo-500/10">
                    <p className="text-[9px] font-black text-indigo-600 dark:text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
                       <Sparkles size={10} className="shrink-0" />
                       {numberToWords(groupBudget)}
                    </p>
                  </div>
                </div>
              )}
            </div>
            
            <div className="relative">
              <div className="flex justify-between items-center mb-2.5 ml-1">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">My Personal Limit</label>
                <button 
                  type="button" 
                  onClick={() => setShowPersonalInfo(!showPersonalInfo)}
                  className="text-slate-300 hover:text-cyan-500 transition-colors"
                >
                  <Info size={16} />
                </button>
              </div>
              {showPersonalInfo && (
                <div className="absolute z-20 bottom-full right-0 mb-3 w-64 p-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-[1.5rem] text-[10px] font-bold leading-relaxed shadow-2xl animate-in fade-in slide-in-from-bottom-2">
                  Your individual spending ceiling. You'll get alerts if your share hits this.
                </div>
              )}
              <div className="relative">
                <IndianRupee size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="number" 
                  placeholder="Your personal cap" 
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-[1.5rem] py-4 pl-12 pr-4 border border-slate-200/60 dark:border-white/5 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-black text-lg" 
                  value={myBudget} 
                  onChange={e => setMyBudget(e.target.value)} 
                />
              </div>
              {myBudget && (
                <div className="mt-2.5 ml-1 animate-in fade-in slide-in-from-left-2 duration-300">
                  <div className="inline-block bg-cyan-50/50 dark:bg-cyan-900/10 px-3 py-1.5 rounded-xl border border-cyan-100/50 dark:border-cyan-500/10">
                    <p className="text-[9px] font-black text-cyan-600 dark:text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
                       <Sparkles size={10} className="shrink-0" />
                       {numberToWords(myBudget)}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-7 rounded-[2.5rem] shadow-sm border border-slate-200/60 dark:border-white/5">
          <div className="flex items-center justify-between mb-6">
             <h3 className="font-black text-xs uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
               <Users size={16} className="text-indigo-500" /> Travel Buddies
             </h3>
             <span className="text-[9px] font-black bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-cyan-400 px-3 py-1 rounded-full uppercase tracking-widest">{members.length + 1} PER</span>
          </div>
          <div className="flex gap-2 mb-6">
            <input 
              type="text" 
              placeholder="Friend's Name" 
              className="flex-1 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-[1.2rem] px-5 py-3 text-xs font-bold border border-slate-200/60 dark:border-white/5 focus:outline-none" 
              value={newMemberName} 
              onChange={e => setNewMemberName(e.target.value)} 
              onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleAddMember())} 
            />
            <button 
              type="button" 
              onClick={handleAddMember} 
              className="px-6 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-[1.2rem] shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest"
            >
              Add
            </button>
          </div>
          <div className="space-y-3 max-h-56 overflow-y-auto custom-scrollbar pr-1">
            <div className="flex items-center gap-4 p-3.5 bg-indigo-50/50 dark:bg-indigo-500/5 rounded-2xl border border-indigo-100 dark:border-indigo-500/10">
               <img src={user.avatar} className="w-10 h-10 rounded-2xl border-2 border-white dark:border-slate-800 object-cover shadow-sm" alt="" />
               <div className="flex-1">
                 <span className="text-xs font-black text-slate-900 dark:text-white">{user.name}</span>
                 <p className="text-[8px] font-black text-indigo-500 uppercase tracking-widest">Organizer</p>
               </div>
            </div>
            {members.map((m, idx) => (
              <div key={idx} className="flex items-center gap-4 p-3.5 bg-slate-50 dark:bg-white/5 rounded-2xl border border-transparent hover:border-slate-200 dark:hover:border-white/10 transition-all animate-in slide-in-from-right-2 duration-300">
                 <img src={`https://picsum.photos/seed/${m}/100`} className="w-10 h-10 rounded-2xl border-2 border-white dark:border-slate-800 object-cover shadow-sm" alt={m} />
                 <span className="text-xs font-black flex-1 text-slate-800 dark:text-white">{m}</span>
                 <button type="button" onClick={() => removeMember(idx)} className="p-2 text-slate-300 hover:text-rose-500 transition-colors"><X size={16} /></button>
              </div>
            ))}
          </div>
        </div>

        <button 
          type="submit" 
          className="w-full bg-gradient-to-br from-indigo-500 via-indigo-600 to-indigo-700 text-white py-5 rounded-[2rem] font-black text-sm uppercase tracking-[0.2em] shadow-xl shadow-indigo-500/20 active:scale-95 transition-all flex items-center justify-center gap-3 border-none"
        >
          CREATE TRIP <Sparkles size={20} />
        </button>
      </form>
    </div>
  );
};

export default CreateTripView;