import React, { useMemo, useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import SharedLayout from '../components/SharedLayout';
import { Trip, Settlement, Expense, AppNotification, AuthUser, Member } from '../types';
import { calculateBalances, optimizeSettlements, calculateDetailedUserBalance, calculateNetPairwiseBalances } from '../utils/finance';
import { fetchWeatherForDestination, WeatherInfo, generateTripImage, QuotaExceededError } from '../services/geminiService';
import { 
  X, Info, Share2, Check, UserPlus, 
  CheckCircle2, CloudLightning, CloudSnow, CloudRain, 
  Sun, Cloud, Thermometer, Archive, Sparkles,
  AlertTriangle, Wallet, Edit3, IndianRupee, MapPin,
  ArrowDownLeft, ArrowUpRight, History, Clock, CheckCircle, Receipt, ChevronRight, Calculator, AlertCircle, TrendingDown, RotateCw
} from 'lucide-react';

interface DashboardViewProps {
  user: AuthUser;
  trip: Trip;
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  onSettle: (from: string, to: string, amount: number) => void;
  onUpdateTrip: (updates: Partial<Trip>) => void;
  onAddMember: (name: string) => void;
  onCompleteTrip: () => void;
  notifications: AppNotification[];
  clearNotification: (id: string) => void;
  onReadNotifications: () => void;
}

const DashboardView: React.FC<DashboardViewProps> = ({ 
  user, 
  trip, 
  onAddExpense, 
  onSettle, 
  onUpdateTrip, 
  onAddMember, 
  onCompleteTrip, 
  notifications, 
  clearNotification, 
  onReadNotifications 
}) => {
  const navigate = useNavigate();
  const [isCopied, setIsCopied] = useState(false);
  const [clearingIds, setClearingIds] = useState<Set<string>>(new Set());
  const [markedAsPaidIds, setMarkedAsPaidIds] = useState<Set<string>>(new Set());
  const [isExiting, setIsExiting] = useState(false);
  const [showFinishConfirm, setShowFinishConfirm] = useState(false);
  const [settlementTab, setSettlementTab] = useState<'pending' | 'history'>('pending');
  
  const [showPaymentBreakdown, setShowPaymentBreakdown] = useState(false);
  const [showReceivableBreakdown, setShowReceivableBreakdown] = useState(false);

  const [fetchError, setFetchError] = useState<string | null>(null);
  const lastFetchedDest = useRef<string | null>(null);
  const prevDestRef = useRef(trip.destination);

  const [explainedBuddy, setExplainedBuddy] = useState<Member | null>(null);
  const [showBudgetEditor, setShowBudgetEditor] = useState(false);
  const [tempGroupBudget, setTempGroupBudget] = useState(trip.budget.toString());
  const [tempMemberBudgets, setTempMemberBudgets] = useState<Record<string, string>>(
    Object.fromEntries(trip.members.map(m => [
      m.id, 
      (trip.memberBudgets?.[m.id] || trip.personalBudget || trip.budget / trip.members.length).toString()
    ]))
  );

  const [showAddMember, setShowAddMember] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');

  const [weather, setWeather] = useState<WeatherInfo | null>(null);
  const [weatherLoading, setWeatherLoading] = useState(false);

  const userId = user.id;

  const myFinanceSummary = useMemo(() => calculateDetailedUserBalance(trip.expenses, trip.members, userId), [trip.expenses, trip.members, userId]);

  const getMemberConsumption = (memberId: string) => {
    return trip.expenses.reduce((sum, exp) => {
      if (exp.description.startsWith('Settlement:')) return sum;
      if (exp.splitAmong.includes(memberId)) {
        if (exp.customSplit && exp.customSplit[memberId] !== undefined) {
          return sum + (exp.customSplit[memberId] as number);
        }
        return sum + (exp.amount / exp.splitAmong.length);
      }
      return sum;
    }, 0);
  };

  const myConsumption = useMemo(() => getMemberConsumption(userId), [trip.expenses, userId]);
  const individualBudget = useMemo(() => 
    trip.memberBudgets?.[userId] ?? trip.personalBudget ?? (trip.budget / trip.members.length), 
    [trip.budget, trip.personalBudget, trip.memberBudgets, trip.members.length, userId]
  );

  const myBudgetProgress = Math.min(100, (myConsumption / individualBudget) * 100);
  const balances = useMemo(() => calculateBalances(trip.expenses, trip.members), [trip.expenses, trip.members]);
  const currentSettlements = useMemo(() => optimizeSettlements(balances), [balances]);

  const myNettedOwedDetails = useMemo(() => {
    const netMatrix = calculateNetPairwiseBalances(trip.expenses, trip.members);
    const result: { 
      member: Member; 
      total: number; 
      grossOwed: number; 
      grossLentBack: number; 
      items: { desc: string; amount: number; date: string; type: 'owe' | 'lent' }[] 
    }[] = [];

    trip.members.forEach(creditor => {
      if (creditor.id === userId) return;
      const netAmount = netMatrix[creditor.id]?.[userId] || 0;
      if (netAmount > 0) {
        let grossOwed = 0;
        let grossLentBack = 0;
        const items: { desc: string; amount: number; date: string; type: 'owe' | 'lent' }[] = [];
        
        trip.expenses.forEach(exp => {
          if (exp.paidBy === creditor.id && exp.splitAmong.includes(userId)) {
            const share = exp.customSplit ? (exp.customSplit[userId] || 0) : (exp.amount / exp.splitAmong.length);
            grossOwed += share;
            items.push({ desc: exp.description, amount: share, date: exp.date, type: 'owe' });
          }
          if (exp.paidBy === userId && exp.splitAmong.includes(creditor.id)) {
            const share = exp.customSplit ? (exp.customSplit[creditor.id] || 0) : (exp.amount / exp.splitAmong.length);
            grossLentBack += share;
            items.push({ desc: exp.description, amount: share, date: exp.date, type: 'lent' });
          }
        });

        result.push({ member: creditor, total: netAmount, grossOwed, grossLentBack, items: items.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()) });
      }
    });
    return result.sort((a, b) => b.total - a.total);
  }, [trip.expenses, trip.members, userId]);

  const myNettedReceivableDetails = useMemo(() => {
    const netMatrix = calculateNetPairwiseBalances(trip.expenses, trip.members);
    const result: { 
      member: Member; 
      total: number; 
      grossLent: number; 
      grossOwedBack: number; 
      items: { desc: string; amount: number; date: string; type: 'lent' | 'owe' }[] 
    }[] = [];

    const myOwedToMe = netMatrix[userId] || {};
    Object.entries(myOwedToMe).forEach(([debtorId, amount]) => {
      if (amount <= 0) return;
      const debtor = trip.members.find(m => m.id === debtorId);
      if (!debtor) return;

      let grossLent = 0;
      let grossOwedBack = 0;
      const items: { desc: string; amount: number; date: string; type: 'lent' | 'owe' }[] = [];

      trip.expenses.forEach(exp => {
        if (exp.paidBy === userId && exp.splitAmong.includes(debtorId)) {
          const share = exp.customSplit ? (exp.customSplit[debtorId] || 0) : (exp.amount / exp.splitAmong.length);
          grossLent += share;
          items.push({ desc: exp.description, amount: share, date: exp.date, type: 'lent' });
        }
        if (exp.paidBy === debtorId && exp.splitAmong.includes(userId)) {
          const share = exp.customSplit ? (exp.customSplit[userId] || 0) : (exp.amount / exp.splitAmong.length);
          grossOwedBack += share;
          items.push({ desc: exp.description, amount: share, date: exp.date, type: 'owe' });
        }
      });

      result.push({ member: debtor, total: amount, grossLent, grossOwedBack, items: items.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()) });
    });
    return result.sort((a, b) => b.total - a.total);
  }, [trip.expenses, trip.members, userId]);

  const settlementHistory = useMemo(() => {
    return trip.expenses.filter(exp => exp.description.startsWith('Settlement:')).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [trip.expenses]);

  const buddyHistory = useMemo(() => {
    if (!explainedBuddy) return [];
    return trip.expenses.filter(exp => 
      (exp.paidBy === userId && exp.splitAmong.includes(explainedBuddy.id)) ||
      (exp.paidBy === explainedBuddy.id && exp.splitAmong.includes(userId))
    ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [explainedBuddy, trip.expenses, userId]);

  useEffect(() => {
    const destinationChanged = prevDestRef.current !== trip.destination;
    if (destinationChanged || (lastFetchedDest.current !== trip.destination && !weather && !fetchError)) {
      handleInitialFetches();
      lastFetchedDest.current = trip.destination;
    }
    prevDestRef.current = trip.destination;
  }, [trip.destination, trip.coverImage, weather, fetchError]);

  const handleInitialFetches = async () => {
    handleFetchWeather();
    handleGenerateCover();
  };

  const handleFetchWeather = async () => {
    if (!trip.destination || weatherLoading) return;
    setWeatherLoading(true);
    try {
      const data = await fetchWeatherForDestination(trip.destination);
      if (data) {
        setWeather(data);
        setFetchError(null);
      }
    } catch (err: any) {
      if (err instanceof QuotaExceededError) setFetchError("QUOTA_LIMIT");
      else setFetchError("GENERIC_ERROR");
    } finally {
      setWeatherLoading(false);
    }
  };

  const handleGenerateCover = async () => {
    if (!trip.destination || trip.coverImage) return;
    try {
      const url = await generateTripImage(trip.destination);
      if (url) onUpdateTrip({ coverImage: url });
    } catch (err: any) {}
  };

  const handleManualRetryAI = () => {
    setFetchError(null);
    setWeather(null);
    handleInitialFetches();
  };

  const handleShare = async () => {
    const shareData = { title: `Join ${trip.name}!`, text: `Code: ${trip.inviteCode}`, url: window.location.origin };
    if (navigator.share) { try { await navigator.share(shareData); } catch (err: any) { fallbackCopy(); } } else { fallbackCopy(); }
  };

  const fallbackCopy = () => {
    navigator.clipboard.writeText(trip.inviteCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const toggleMarkAsPaid = (s: Settlement, index: number) => {
    const id = `${s.from}-${s.to}-${index}`;
    setMarkedAsPaidIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleMarkPaid = (s: Settlement, index: number) => {
    const settlementId = `${s.from}-${s.to}-${index}`;
    setClearingIds(prev => new Set(prev).add(settlementId));
    setTimeout(() => {
      onSettle(s.from, s.to, s.amount);
      setClearingIds(prev => { const next = new Set(prev); next.delete(settlementId); return next; });
      setMarkedAsPaidIds(prev => { const next = new Set(prev); next.delete(settlementId); return next; });
    }, 500);
  };

  const handleAddMemberSubmit = () => {
    if (newMemberName.trim()) { 
      onAddMember(newMemberName.trim());
      setNewMemberName(''); 
      setShowAddMember(false); 
    }
  };

  const handleFinishTrip = () => {
    setIsExiting(true);
    setTimeout(() => { onCompleteTrip(); navigate('/history'); }, 1500);
  };

  const handleSaveBudgets = () => {
    const updatedMemberBudgets = Object.fromEntries(Object.entries(tempMemberBudgets).map(([id, val]) => [id, parseFloat(val as string) || 0]));
    onUpdateTrip({ budget: parseFloat(tempGroupBudget as string) || 0, memberBudgets: updatedMemberBudgets, personalBudget: updatedMemberBudgets[userId] });
    setShowBudgetEditor(false);
  };

  const getWeatherIcon = (condition: string, size = 14) => {
    const cond = condition.toLowerCase();
    if (cond.includes('storm') || cond.includes('thunder')) return <CloudLightning className="text-yellow-400" size={size} />;
    if (cond.includes('snow')) return <CloudSnow className="text-blue-200" size={size} />;
    if (cond.includes('rain')) return <CloudRain className="text-blue-400" size={size} />;
    if (cond.includes('sun') || cond.includes('clear')) return <Sun className="text-amber-300" size={size} />;
    if (cond.includes('cloud')) return <Cloud className="text-slate-300" size={size} />;
    return <Thermometer className="text-indigo-400" size={size} />;
  };

  return (
    <SharedLayout activeTab="home" user={user} title="Dashboard" notifications={notifications} clearNotification={clearNotification} onReadNotifications={onReadNotifications}>
      {/* Receivable Breakdown Modal */}
      {showReceivableBreakdown && (
        <div className="fixed inset-0 z-[110] flex items-end justify-center bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
           <div className="bg-white dark:bg-slate-900 w-full max-md rounded-t-[3rem] p-8 shadow-2xl border-t border-white/10 animate-in slide-in-from-bottom-12 duration-500 max-h-[85vh] flex flex-col">
              <div className="flex justify-between items-start mb-8">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-emerald-500/10 text-emerald-500 rounded-2xl flex items-center justify-center"><ArrowUpRight size={28} /></div>
                    <div>
                       <h3 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white">Net Receivables</h3>
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Mutual debt netting applied</p>
                    </div>
                 </div>
                 <button onClick={() => setShowReceivableBreakdown(false)} className="p-3 bg-slate-100 dark:bg-white/5 rounded-2xl text-slate-500 hover:text-rose-500 transition-colors"><X size={24} /></button>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar space-y-8 pb-6">
                 {myNettedReceivableDetails.length === 0 ? (
                   <div className="text-center py-16 opacity-30"><Receipt size={48} className="mx-auto mb-4" /><p className="text-xs font-black uppercase tracking-widest">Nothing owed to you</p></div>
                 ) : myNettedReceivableDetails.map((debtor, dIdx) => (
                   <div key={dIdx} className="space-y-4">
                      <div className="flex items-center justify-between px-2">
                         <div className="flex items-center gap-3">
                            <img src={debtor.member.avatar} className="w-10 h-10 rounded-xl border-2 border-slate-100 dark:border-slate-800 shadow-sm" alt="" />
                            <p className="text-sm font-black text-slate-900 dark:text-slate-100">From {debtor.member.name.split(' ')[0]}</p>
                         </div>
                         <p className="text-sm font-black text-emerald-500">₹{Math.round(debtor.total).toLocaleString()}</p>
                      </div>
                      <div className="bg-slate-50 dark:bg-white/5 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 space-y-3">
                         {debtor.items.map((item, iIdx) => (
                           <div key={iIdx} className="flex justify-between items-center group">
                              <div className="min-w-0 flex-1 pr-4">
                                 <p className="text-[11px] font-bold truncate text-slate-800 dark:text-slate-200 group-hover:text-indigo-500 transition-colors">{item.desc}</p>
                                 <p className="text-[8px] font-black text-slate-400 uppercase">{new Date(item.date).toLocaleDateString('en-IN', {day:'numeric', month:'short'})}</p>
                              </div>
                              <p className={`text-[11px] font-black tracking-tight ${item.type === 'owe' ? 'text-rose-400' : 'text-slate-900 dark:text-slate-100'}`}>
                                {item.type === 'owe' ? '-' : ''}₹{Math.round(item.amount).toLocaleString()}
                              </p>
                           </div>
                         ))}
                      </div>
                   </div>
                 ))}
              </div>
              <div className="pt-6 border-t border-slate-100 dark:border-white/10">
                 <div className="flex justify-between items-center mb-6">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total to receive</p>
                    <p className="text-2xl font-black text-emerald-500">₹{Math.round(myFinanceSummary.lent).toLocaleString()}</p>
                 </div>
                 <button onClick={() => setShowReceivableBreakdown(false)} className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-xs uppercase tracking-widest active:scale-95 shadow-xl transition-all">Got It</button>
              </div>
           </div>
        </div>
      )}

      {/* Payment Breakdown Modal */}
      {showPaymentBreakdown && (
        <div className="fixed inset-0 z-[110] flex items-end justify-center bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
           <div className="bg-white dark:bg-slate-900 w-full max-md rounded-t-[3rem] p-8 shadow-2xl border-t border-white/10 animate-in slide-in-from-bottom-12 duration-500 max-h-[85vh] flex flex-col">
              <div className="flex justify-between items-start mb-8">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-rose-500/10 text-rose-500 rounded-2xl flex items-center justify-center"><ArrowDownLeft size={28} /></div>
                    <div>
                       <h3 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white">Net Payables</h3>
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Balance after mutual netting</p>
                    </div>
                 </div>
                 <button onClick={() => setShowPaymentBreakdown(false)} className="p-3 bg-slate-100 dark:bg-white/5 rounded-2xl text-slate-500 hover:text-rose-500 transition-colors"><X size={24} /></button>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar space-y-8 pb-6">
                 {myNettedOwedDetails.length === 0 ? (
                   <div className="text-center py-16 opacity-30"><Receipt size={48} className="mx-auto mb-4" /><p className="text-xs font-black uppercase tracking-widest">No net debts</p></div>
                 ) : myNettedOwedDetails.map((creditor, cIdx) => (
                   <div key={cIdx} className="space-y-4">
                      <div className="flex items-center justify-between px-2">
                         <div className="flex items-center gap-3">
                            <img src={creditor.member.avatar} className="w-10 h-10 rounded-xl border-2 border-slate-100 dark:border-slate-800 shadow-sm" alt="" />
                            <p className="text-sm font-black text-slate-900 dark:text-slate-100">To {creditor.member.name.split(' ')[0]}</p>
                         </div>
                         <p className="text-sm font-black text-rose-500">₹{Math.round(creditor.total).toLocaleString()}</p>
                      </div>
                      <div className="bg-slate-50 dark:bg-white/5 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 space-y-3">
                         {creditor.items.map((item, iIdx) => (
                           <div key={iIdx} className="flex justify-between items-center group">
                              <div className="min-w-0 flex-1 pr-4">
                                 <p className="text-[11px] font-bold truncate text-slate-800 dark:text-slate-200 group-hover:text-indigo-500 transition-colors">{item.desc}</p>
                                 <p className="text-[8px] font-black text-slate-400 uppercase">{new Date(item.date).toLocaleDateString('en-IN', {day:'numeric', month:'short'})}</p>
                              </div>
                              <p className={`text-[11px] font-black tracking-tight ${item.type === 'lent' ? 'text-emerald-400' : 'text-slate-900 dark:text-slate-100'}`}>
                                {item.type === 'lent' ? '-' : ''}₹{Math.round(item.amount).toLocaleString()}
                              </p>
                           </div>
                         ))}
                      </div>
                   </div>
                 ))}
              </div>
              <div className="pt-6 border-t border-slate-100 dark:border-white/10">
                 <div className="flex justify-between items-center mb-6">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total to pay</p>
                    <p className="text-2xl font-black text-rose-500">₹{Math.round(myFinanceSummary.borrowed).toLocaleString()}</p>
                 </div>
                 <button onClick={() => setShowPaymentBreakdown(false)} className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-xs uppercase tracking-widest active:scale-95 shadow-xl transition-all">Got It</button>
              </div>
           </div>
        </div>
      )}

      {/* Buddy Detail Modal */}
      {explainedBuddy && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
           <div className="bg-white dark:bg-slate-900 w-full max-sm rounded-[3rem] overflow-hidden shadow-2xl border border-slate-200 dark:border-white/10 animate-in zoom-in-95 duration-300">
              <div className="p-6 border-b border-slate-100 dark:border-white/5 flex justify-between items-center bg-slate-50 dark:bg-white/5">
                 <div className="flex items-center gap-3">
                    <img src={explainedBuddy.avatar} className="w-8 h-8 rounded-xl" alt="" />
                    <h3 className="font-black text-xs uppercase tracking-widest text-slate-900 dark:text-white">Logs with {explainedBuddy.name.split(' ')[0]}</h3>
                 </div>
                 <button onClick={() => setExplainedBuddy(null)} className="p-2 hover:bg-slate-100 dark:hover:bg-white/5 rounded-full text-slate-500"><X size={18} /></button>
              </div>
              <div className="max-h-[50vh] overflow-y-auto p-6 custom-scrollbar space-y-4">
                 {buddyHistory.length === 0 ? (
                   <div className="text-center py-12 text-slate-400"><p className="text-[10px] font-black uppercase tracking-widest">No common logs</p></div>
                 ) : buddyHistory.map((exp, idx) => {
                   const isPayer = exp.paidBy === userId;
                   const share = exp.customSplit ? (exp.customSplit[isPayer ? explainedBuddy.id : userId] || 0) : (exp.amount / exp.splitAmong.length);
                   return (
                     <div key={idx} className="flex justify-between items-center p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <div className="min-w-0 flex-1 pr-4">
                           <p className="text-[11px] font-black truncate text-slate-900 dark:text-white">{exp.description}</p>
                           <p className="text-[9px] font-bold text-slate-400 uppercase">{isPayer ? 'You paid' : 'They paid'}</p>
                        </div>
                        <div className="text-right">
                           <p className={`text-xs font-black ${isPayer ? 'text-emerald-500' : 'text-rose-500'}`}>{isPayer ? '+' : '-'}₹{Math.round(share).toLocaleString()}</p>
                           <p className="text-[8px] font-black text-slate-300 uppercase">{new Date(exp.date).toLocaleDateString('en-IN', {day:'numeric', month:'short'})}</p>
                        </div>
                     </div>
                   );
                 })}
              </div>
              <div className="p-6 bg-slate-50 dark:bg-white/5 border-t border-slate-100 dark:border-white/5 text-center">
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Net Relationship</p>
                 <p className={`text-xl font-black ${(balances[explainedBuddy.id] || 0) <= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>₹{Math.abs(Math.round(balances[explainedBuddy.id] || 0)).toLocaleString()}</p>
              </div>
           </div>
        </div>
      )}

      {/* Budget Editor Modal */}
      {showBudgetEditor && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
           <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[3rem] p-8 shadow-2xl border border-slate-200 dark:border-white/10 animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
              <div className="flex justify-between items-center mb-6 shrink-0">
                 <div className="flex items-center gap-3"><div className="w-10 h-10 bg-indigo-500/10 text-indigo-500 rounded-2xl flex items-center justify-center"><Wallet size={20} /></div><h3 className="text-xl font-black tracking-tight text-slate-900 dark:text-white">Trip Budgets</h3></div>
                 <button onClick={() => setShowBudgetEditor(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-white/5 rounded-full transition-colors text-slate-500"><X size={20} /></button>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar space-y-8 pr-1">
                 <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Total Trip Budget</label>
                    <div className="relative group">
                       <IndianRupee size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                       <input 
                         type="number" 
                         className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-2xl py-4 pl-12 pr-4 border border-slate-200/60 dark:border-white/5 focus:outline-none focus:ring-4 focus:ring-indigo-500/5 font-black text-lg transition-all shadow-inner" 
                         value={tempGroupBudget} 
                         onChange={(e) => setTempGroupBudget(e.target.value)} 
                       />
                    </div>
                 </div>
                 <div className="space-y-4">
                    <div className="flex items-center gap-2 mb-1 px-1"><TrendingDown size={14} className="text-cyan-500" /><h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Individual Member Limits</h4></div>
                    {trip.members.map(member => (
                       <div key={member.id} className="bg-slate-50 dark:bg-white/5 p-4 rounded-3xl border border-slate-100 dark:border-white/5 shadow-sm">
                          <div className="flex items-center gap-3 mb-3"><img src={member.avatar} className="w-7 h-7 rounded-xl border border-white dark:border-slate-800" alt="" /><span className="text-xs font-black text-slate-900 dark:text-slate-100">{member.name}{member.id === userId ? ' (You)' : ''}</span></div>
                          <div className="relative group">
                             <IndianRupee size={12} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                             <input 
                               type="number" 
                               className="w-full bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-xl py-2.5 pl-9 pr-3 border border-slate-200/60 dark:border-white/5 focus:outline-none focus:ring-4 focus:ring-indigo-500/5 font-black text-sm transition-all shadow-inner" 
                               value={tempMemberBudgets[member.id] || ''} 
                               onChange={(e) => setTempMemberBudgets(prev => ({ ...prev, [member.id]: e.target.value }))} 
                             />
                          </div>
                       </div>
                    ))}
                 </div>
              </div>
              <div className="pt-6 shrink-0"><button onClick={handleSaveBudgets} className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl active:scale-95 transition-all">Update Journey</button></div>
           </div>
        </div>
      )}

      {/* Main Dashboard UI */}
      <div className={`space-y-6 transition-all duration-700 ${isExiting ? 'opacity-0 scale-95 blur-md' : 'opacity-100 scale-100'}`}>
        {/* Trip Hero */}
        <div className="bg-slate-900 rounded-[3rem] text-white shadow-2xl relative overflow-hidden min-h-[440px] flex flex-col transition-colors duration-1000">
          {trip.coverImage ? (
            <div className="absolute inset-0"><img src={trip.coverImage} className="w-full h-full object-cover opacity-60" alt="" /><div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/20 to-transparent"></div></div>
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 to-indigo-900 flex items-center justify-center"><div className="flex flex-col items-center animate-pulse"><Sparkles className="text-white/20 mb-2" size={32} /><p className="text-[8px] font-black uppercase tracking-[0.3em] text-white/30">Visualizing {trip.destination}...</p></div></div>
          )}
          <div className="relative z-10 flex flex-col h-full space-y-4 p-7 flex-1">
            <div className="flex justify-between items-start">
              <div className="flex-1 min-w-0 pr-4">
                {weatherLoading ? (
                  <div className="h-5 w-16 bg-white/10 rounded-full animate-pulse"></div>
                ) : weather ? (
                  <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-xl px-2 py-1 rounded-xl border border-white/10">
                    {getWeatherIcon(weather.today.cond, 12)}
                    <div className="flex flex-col leading-none"><span className="text-[6px] font-black uppercase text-white/50">Today</span><span className="text-[10px] font-black">{weather.today.temp}</span></div>
                  </div>
                ) : fetchError === 'QUOTA_LIMIT' ? (
                  <button onClick={handleManualRetryAI} className="inline-flex items-center gap-2 bg-rose-500/10 backdrop-blur-xl px-3 py-1.5 rounded-xl border border-rose-500/20 text-rose-400 active:scale-95 transition-transform"><AlertCircle size={12} /><span className="text-[8px] font-black uppercase">Quota Hit</span><RotateCw size={10} className="ml-1 opacity-60" /></button>
                ) : (
                  <button onClick={handleInitialFetches} className="inline-flex items-center gap-2 bg-white/5 backdrop-blur-xl px-2 py-1 rounded-xl border border-white/10 text-white/40 hover:text-white/70"><RotateCw size={10} /><span className="text-[8px] font-black uppercase">Retry AI</span></button>
                )}
              </div>
              <div className="flex flex-col gap-4">
                <button onClick={() => setShowBudgetEditor(true)} className="w-11 h-11 flex items-center justify-center rounded-2xl border border-white/30 bg-white/10 backdrop-blur-2xl shadow-lg active:scale-90 transition-all"><Edit3 size={18} /></button>
                <button onClick={handleShare} className={`w-11 h-11 flex items-center justify-center rounded-2xl border border-white/30 ${isCopied ? 'bg-emerald-500' : 'bg-white/10 backdrop-blur-2xl'} shadow-lg transition-all`}>{isCopied ? <Check size={18} /> : <Share2 size={18} />}</button>
                <button onClick={() => setShowFinishConfirm(true)} className="w-11 h-11 flex items-center justify-center rounded-2xl border border-rose-500/30 bg-rose-500/20 backdrop-blur-2xl text-rose-400 shadow-lg active:scale-90 transition-all"><Archive size={18} /></button>
              </div>
            </div>
            
            {/* HERO TEXT SECTION - DYNAMIC FIT & DESCENDER FIX */}
            <div className="flex-1 flex flex-col justify-end pb-4">
              <p className="text-white/40 text-[9px] font-black uppercase tracking-[0.4em] mb-1">Journey</p>
              <h2 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tighter leading-[1.2] mb-4 drop-shadow-xl break-words line-clamp-3 pb-2">
                {trip.name}
              </h2>
              <p className="text-white/60 text-[10px] font-black uppercase tracking-[0.2em] mb-3">{trip.startDate} — {trip.endDate}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setShowReceivableBreakdown(true)} className="bg-white/5 backdrop-blur-2xl rounded-[2rem] p-4 border border-white/10 min-w-0 text-left active:bg-white/10 transition-all group">
                <div className="flex items-center justify-between mb-1"><div className="flex items-center gap-1.5"><ArrowUpRight size={10} className="text-emerald-400" /><p className="text-[9px] font-black text-white/40 uppercase tracking-widest">I'm Getting</p></div><ChevronRight size={10} className="text-white/20 group-hover:text-white/60" /></div>
                <p className="text-lg font-black tracking-tighter truncate text-emerald-400">₹{Math.round(myFinanceSummary.lent).toLocaleString()}</p>
              </button>
              <button onClick={() => setShowPaymentBreakdown(true)} className="bg-white/5 backdrop-blur-2xl rounded-[2rem] p-4 border border-white/10 min-w-0 text-left active:bg-white/10 transition-all group">
                <div className="flex items-center justify-between mb-1"><div className="flex items-center gap-1.5"><ArrowDownLeft size={10} className="text-rose-400" /><p className="text-[9px] font-black text-white/40 uppercase tracking-widest">I'm Paying</p></div><ChevronRight size={10} className="text-white/20 group-hover:text-white/60" /></div>
                <p className="text-lg font-black tracking-tighter truncate text-rose-400">₹{Math.round(myFinanceSummary.borrowed).toLocaleString()}</p>
              </button>
            </div>
            <div className="space-y-2.5 cursor-pointer group/progress mt-2" onClick={() => setShowBudgetEditor(true)}>
              <div className="flex justify-between items-center text-[11px] font-black uppercase tracking-widest"><span>My Spending</span><span className="tracking-tighter font-black text-[13px]">₹{Math.round(myConsumption).toLocaleString()} / ₹{Math.round(individualBudget).toLocaleString()}</span></div>
              <div className="h-6 bg-black/40 rounded-full overflow-hidden p-[4px] relative border border-white/5 shadow-inner"><div className="h-full rounded-full transition-all duration-1000 bg-white shadow-[0_0_20px_rgba(255,255,255,0.6)]" style={{ width: `${myBudgetProgress}%` }}></div></div>
            </div>
          </div>
        </div>

        {/* Travel Buddies Section */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-7 shadow-xl shadow-slate-200/60 dark:shadow-none border border-slate-100 dark:border-white/5">
          <div className="flex items-center justify-between mb-6"><div><h3 className="font-black text-xs uppercase tracking-[0.2em] text-slate-400">Travel Buddies</h3><p className="text-[9px] font-bold text-slate-400 mt-0.5 tracking-tight lowercase first-letter:uppercase">Buddy-wise spending & debt status.</p></div><button onClick={() => setShowAddMember(!showAddMember)} className="w-8 h-8 flex items-center justify-center bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-cyan-400 rounded-xl transition-all active:scale-90">{showAddMember ? <X size={16} /> : <UserPlus size={16} />}</button></div>
          {showAddMember && (
            <div className="mb-6 flex gap-2 animate-in slide-in-from-top-2 duration-300">
               <input type="text" placeholder="Buddy's name" className="flex-1 bg-slate-50 dark:bg-slate-950 px-5 py-3 rounded-2xl text-xs font-black focus:outline-none border border-slate-200 dark:border-white/5 shadow-inner" value={newMemberName} onChange={(e) => setNewMemberName(e.target.value)} />
               <button onClick={handleAddMemberSubmit} className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-6 rounded-2xl text-[10px] font-black uppercase shadow-lg">Add</button>
            </div>
          )}
          <div className="space-y-4">
            {trip.members.map((member) => {
              if (member.id === userId) return null;
              const balance = balances[member.id] || 0;
              const needsToPay = balance < -0.01;
              const needsToGet = balance > 0.01;
              const consumed = getMemberConsumption(member.id);
              const limit = trip.memberBudgets?.[member.id] || trip.personalBudget || (trip.budget / trip.members.length);
              const progress = Math.min(100, (consumed / limit) * 100);
              const isOver = consumed > limit;
              return (
                <div key={member.id} className="space-y-3 p-4 bg-slate-50/50 dark:bg-white/5 rounded-[2.2rem] border border-transparent hover:border-slate-200 dark:hover:border-white/10 transition-all shadow-sm hover:shadow-md">
                  <div onClick={() => setExplainedBuddy(member)} className="flex items-center justify-between cursor-pointer group">
                    <div className="flex items-center gap-4"><img src={member.avatar} className="w-11 h-11 rounded-2xl border-2 border-white dark:border-slate-800 shadow-sm object-cover" alt="" /><div><p className="text-xs font-black text-slate-900 dark:text-white">{member.name}</p><p className={`text-[8px] font-black uppercase tracking-widest ${needsToPay ? 'text-rose-400' : needsToGet ? 'text-emerald-400' : 'text-slate-400'}`}>{needsToPay ? 'Pays Money' : needsToGet ? 'Gets Back' : 'Settled'}</p></div></div>
                    <div className="text-right"><div className="flex items-center justify-end gap-1 mb-0.5"><span className={`text-xs font-black ${needsToGet ? 'text-emerald-500' : needsToPay ? 'text-rose-500' : 'text-slate-400'}`}>₹{Math.abs(Math.round(balance)).toLocaleString()}</span><Info size={10} className="text-slate-300 group-hover:text-indigo-500" /></div></div>
                  </div>
                  <div className="px-1 space-y-1.5" onClick={() => setShowBudgetEditor(true)}>
                    <div className="flex justify-between items-center text-[8px] font-black uppercase tracking-tighter"><span className="text-slate-400">Budget Spent</span><span className={isOver ? 'text-rose-500' : 'text-indigo-500'}>₹{Math.round(consumed).toLocaleString()} / ₹{Math.round(limit).toLocaleString()}</span></div>
                    <div className="h-1 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden"><div className={`h-full transition-all duration-1000 ${isOver ? 'bg-rose-500' : progress > 80 ? 'bg-amber-500' : 'bg-indigo-500'}`} style={{ width: `${progress}%` }}></div></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Settlements Section */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-7 shadow-xl shadow-slate-200/60 dark:shadow-none border border-slate-100 dark:border-white/5 mb-24 overflow-hidden">
           <div className="flex items-center justify-between mb-6"><div><h3 className="font-black text-xs uppercase tracking-[0.2em] text-slate-400">Settlements</h3><p className="text-[9px] font-bold text-slate-400 mt-0.5 tracking-tight lowercase first-letter:uppercase">Log travel debt payments.</p></div><div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${currentSettlements.length > 0 ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' : 'bg-slate-100 dark:bg-white/5 text-slate-400'}`}>{currentSettlements.length} Pending</div></div>
           <div className="flex p-1 bg-slate-100 dark:bg-slate-950 rounded-2xl mb-6 shadow-inner">
              <button onClick={() => setSettlementTab('pending')} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${settlementTab === 'pending' ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-sm' : 'text-slate-400'}`}><Clock size={12} /> Pending</button>
              <button onClick={() => setSettlementTab('history')} className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${settlementTab === 'history' ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-sm' : 'text-slate-400'}`}><History size={12} /> History</button>
           </div>
           <div className="space-y-4 min-h-[200px]">
              {settlementTab === 'pending' ? (
                currentSettlements.length === 0 ? (<div className="text-center py-12 flex flex-col items-center opacity-30"><CheckCircle2 size={48} className="mb-3 text-emerald-500" /><p className="text-[10px] font-black uppercase tracking-widest">Everything Clear</p></div>) : currentSettlements.map((s, idx) => {
                    const from = trip.members.find(m => m.id === s.from);
                    const to = trip.members.find(m => m.id === s.to);
                    const isClearing = clearingIds.has(`${s.from}-${s.to}-${idx}`);
                    const isMarkedPaid = markedAsPaidIds.has(`${s.from}-${s.to}-${idx}`);
                    return (
                      <div key={idx} className={`flex flex-col p-5 bg-slate-50/50 dark:bg-white/5 rounded-[2rem] border border-slate-100 dark:border-white/5 transition-all duration-500 shadow-lg shadow-slate-200/50 dark:shadow-none ${isClearing ? 'opacity-0 translate-x-12' : ''} ${isMarkedPaid ? 'bg-emerald-500/5 border-emerald-500/20 shadow-emerald-500/10' : ''}`}>
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className="relative flex">
                              <img src={from?.avatar} className="w-10 h-10 rounded-2xl border-2 border-white dark:border-slate-800 relative z-10 shadow-sm" alt="" />
                              <img src={to?.avatar} className="w-10 h-10 rounded-2xl border-2 border-white dark:border-slate-800 -ml-4 shadow-sm" alt="" />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 text-[11px] font-black truncate text-slate-900 dark:text-slate-100">
                                <span>{from?.name.split(' ')[0]}</span>
                                <span className="text-slate-400 font-medium lowercase">pays</span>
                                <span>{to?.name.split(' ')[0]}</span>
                              </div>
                              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Suggested Log</span>
                            </div>
                          </div>
                          <p className="text-sm font-black text-slate-900 dark:text-slate-100">₹{Math.round(s.amount).toLocaleString()}</p>
                        </div>
                        <div className="flex gap-2">
                           <button onClick={() => toggleMarkAsPaid(s, idx)} className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all shadow-sm ${isMarkedPaid ? 'bg-emerald-500 text-white shadow-emerald-900/20' : 'bg-white dark:bg-slate-800 text-slate-500'}`}>{isMarkedPaid ? <CheckCircle size={12} className="inline mr-1" /> : ''} Paid</button>
                           <button onClick={() => handleMarkPaid(s, idx)} className="flex-1 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg shadow-slate-900/20 active:scale-95 transition-all">Confirm Settle</button>
                        </div>
                      </div>
                    )
                  })
              ) : settlementHistory.length === 0 ? (<div className="text-center py-12 opacity-30"><History size={40} className="mx-auto mb-2" /><p className="text-[10px] font-black uppercase tracking-widest">No history yet</p></div>) : settlementHistory.map((exp) => {
                    const payer = trip.members.find(m => m.id === exp.paidBy);
                    const recipient = trip.members.find(m => m.id === exp.splitAmong[0]);
                    return (
                      <div key={exp.id} className="flex items-center justify-between p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-[1.8rem] shadow-sm"><div className="flex items-center gap-3"><div className="w-9 h-9 bg-emerald-500 rounded-xl flex items-center justify-center text-white shrink-0"><Check size={18} strokeWidth={3} /></div><div><p className="text-[10px] font-black text-slate-900 dark:text-slate-100">{payer?.name.split(' ')[0]} settled with {recipient?.name.split(' ')[0]}</p><p className="text-[8px] font-bold text-slate-400 uppercase">{new Date(exp.date).toLocaleDateString('en-IN', {day:'numeric', month:'short'})}</p></div></div><div className="text-right"><p className="text-xs font-black text-emerald-600">₹{Math.round(exp.amount).toLocaleString()}</p></div></div>
                    );
                  })
              }
           </div>
        </div>
      </div>

      {/* Finish Trip Confirm */}
      {showFinishConfirm && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[3rem] p-8 shadow-2xl border border-slate-200 dark:border-white/10 animate-in zoom-in-95 duration-300 text-center">
            <div className="w-16 h-16 bg-amber-500/10 text-amber-500 rounded-[1.5rem] flex items-center justify-center mx-auto mb-6"><AlertTriangle size={32} /></div>
            <h3 className="text-xl font-black mb-2 text-slate-900 dark:text-white">Finish Journey?</h3>
            <p className="text-xs text-slate-500 mb-8 px-4 leading-relaxed">All finances will be finalized and the trip will move to your permanent <span className="font-black text-indigo-500">Travel Vault</span>.</p>
            <div className="flex flex-col gap-3">
               <button onClick={handleFinishTrip} className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl">Archive Trip</button>
               <button onClick={() => setShowFinishConfirm(false)} className="w-full py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-2xl font-black text-xs uppercase tracking-widest">Keep Exploring</button>
            </div>
          </div>
        </div>
      )}
    </SharedLayout>
  );
};

export default DashboardView;