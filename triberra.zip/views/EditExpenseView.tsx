
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import SharedLayout from '../components/SharedLayout';
import { Trip, Member, ExpenseCategory, Expense } from '../types';
import { Check, X, User, Hash, FileText, IndianRupee, Trash2, AlertCircle, Scale, Coins, CheckCircle2, Zap } from 'lucide-react';

interface EditExpenseViewProps {
  trip: Trip;
  onEdit: (expense: Expense) => void;
}

const EditExpenseView: React.FC<EditExpenseViewProps> = ({ trip, onEdit }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const existingExpense = trip.expenses.find(e => e.id === id);

  const [description, setDescription] = useState(existingExpense?.description || '');
  const [amount, setAmount] = useState(existingExpense?.amount.toString() || '');
  const [category, setCategory] = useState<ExpenseCategory>(existingExpense?.category || 'others');
  const [paidBy, setPaidBy] = useState(existingExpense?.paidBy || trip.members[0].id);
  const [selectedSplit, setSelectedSplit] = useState<string[]>(existingExpense?.splitAmong || trip.members.map(m => m.id));
  
  // Custom Split States
  const [splitType, setSplitType] = useState<'equal' | 'exact'>(existingExpense?.customSplit ? 'exact' : 'equal');
  const [customAmounts, setCustomAmounts] = useState<Record<string, string>>(
    existingExpense?.customSplit 
      ? Object.fromEntries(Object.entries(existingExpense.customSplit).map(([k, v]) => [k, v.toString()]))
      : {}
  );

  const [showConfirm, setShowConfirm] = useState(false);

  const totalBill = parseFloat(amount) || 0;
  const currentSplitTotal = useMemo(() => {
    if (splitType === 'equal') return totalBill;
    return (Object.values(customAmounts) as string[]).reduce((sum, val) => sum + (parseFloat(val) || 0), 0);
  }, [splitType, customAmounts, totalBill]);

  const difference = totalBill - currentSplitTotal;
  const isBalanced = Math.abs(difference) < 0.1;
  const isOver = difference < -0.1;
  const percentFilled = totalBill > 0 ? Math.min(100, (currentSplitTotal / totalBill) * 100) : 0;

  useEffect(() => {
    if (!existingExpense) {
      navigate('/expenses');
    }
  }, [existingExpense, navigate]);

  const handleSmartFill = (memberId: string) => {
    const remaining = totalBill - (currentSplitTotal - (parseFloat(customAmounts[memberId]) || 0));
    setCustomAmounts(prev => ({
      ...prev,
      [memberId]: Math.max(0, remaining).toFixed(0)
    }));
  };

  const hasChanges = useMemo(() => {
    if (!existingExpense) return false;
    
    const baseChanged = (
      description !== existingExpense.description ||
      parseFloat(amount) !== existingExpense.amount ||
      category !== existingExpense.category ||
      paidBy !== existingExpense.paidBy ||
      JSON.stringify(selectedSplit.sort()) !== JSON.stringify([...existingExpense.splitAmong].sort())
    );

    const splitTypeChanged = (splitType === 'exact') !== !!existingExpense.customSplit;
    
    let customAmountsChanged = false;
    if (splitType === 'exact' && existingExpense.customSplit) {
      customAmountsChanged = Object.keys(customAmounts).length !== Object.keys(existingExpense.customSplit).length ||
        (Object.entries(customAmounts) as [string, string][]).some(([k, v]) => parseFloat(v) !== existingExpense.customSplit?.[k]);
    }

    return baseChanged || splitTypeChanged || customAmountsChanged;
  }, [description, amount, category, paidBy, selectedSplit, splitType, customAmounts, existingExpense]);

  if (!existingExpense) return null;

  const handleUpdateClick = () => {
    if (!amount || !description) return;
    if (splitType === 'exact' && !isBalanced) {
      alert(`The split amounts (₹${currentSplitTotal}) don't match the total bill (₹${totalBill}). You have ₹${Math.abs(difference)} remaining.`);
      return;
    }

    if (hasChanges) {
      setShowConfirm(true);
    } else {
      navigate('/expenses');
    }
  };

  const confirmUpdate = () => {
    const finalCustomSplit: Record<string, number> | undefined = splitType === 'exact' 
      ? Object.fromEntries(
          (Object.entries(customAmounts) as [string, string][])
            .filter(([mId]) => selectedSplit.includes(mId))
            .map(([mId, amt]) => [mId, parseFloat(amt) || 0])
        )
      : undefined;

    onEdit({
      id: existingExpense.id,
      amount: totalBill,
      description,
      category,
      date: existingExpense.date,
      paidBy,
      splitAmong: selectedSplit,
      customSplit: finalCustomSplit
    });
    navigate('/expenses');
  };

  const toggleMemberSelection = (memberId: string) => {
    if (selectedSplit.includes(memberId)) {
      if (selectedSplit.length > 1) {
        setSelectedSplit(selectedSplit.filter(sid => sid !== memberId));
      }
    } else {
      setSelectedSplit([...selectedSplit, memberId]);
    }
  };

  return (
    <SharedLayout showTabs={false} title="Edit Transaction">
      <div className="space-y-6 pb-10 text-slate-100 relative">
        {/* Confirmation Modal */}
        {showConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-xs shadow-2xl animate-in zoom-in-95 duration-200">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-12 h-12 bg-indigo-500/20 text-indigo-400 rounded-full flex items-center justify-center">
                  <AlertCircle size={28} />
                </div>
                <div className="space-y-1">
                  <h3 className="font-bold text-lg">Update Expense?</h3>
                  <p className="text-sm text-slate-400">Are you sure you want to save these changes?</p>
                </div>
                <div className="flex gap-3 w-full pt-2">
                  <button 
                    onClick={() => setShowConfirm(false)}
                    className="flex-1 px-4 py-2.5 rounded-xl border border-slate-700 text-sm font-bold text-slate-300 hover:bg-slate-800 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={confirmUpdate}
                    className="flex-1 px-4 py-2.5 rounded-xl bg-indigo-600 text-sm font-bold text-white shadow-lg shadow-indigo-900/40 active:scale-95 transition-all"
                  >
                    Confirm
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Header Section */}
        <div className="flex justify-between items-center px-2">
           <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-800 rounded-full transition-colors">
             <X size={24} className="text-slate-500" />
           </button>
           <h2 className="text-lg font-bold">Edit Details</h2>
           <button 
             onClick={handleUpdateClick} 
             disabled={!amount || !description || (splitType === 'exact' && !isBalanced)}
             className="bg-indigo-600 text-white px-5 py-2 rounded-full text-sm font-bold shadow-lg shadow-indigo-900/30 disabled:opacity-30 transition-all active:scale-95"
           >
             Update
           </button>
        </div>

        {/* Amount Input Large */}
        <div className="text-center py-6">
           <div className="inline-flex items-center gap-1">
             <span className="text-3xl font-bold text-slate-600">₹</span>
             <input 
               type="number" 
               placeholder="0.00" 
               className="bg-transparent text-5xl font-black text-slate-100 focus:outline-none w-48 text-center placeholder:text-slate-800"
               value={amount}
               onChange={(e) => setAmount(e.target.value)}
             />
           </div>
        </div>

        {/* Manual Fields */}
        <div className="bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-800 space-y-6">
           <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-xl bg-slate-950 flex items-center justify-center text-slate-600">
                <FileText size={20} />
             </div>
             <div className="flex-1">
               <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Description</label>
               <input 
                 type="text" 
                 placeholder="What did you buy?" 
                 className="w-full text-sm font-semibold bg-transparent focus:outline-none text-slate-100 placeholder:text-slate-700"
                 value={description}
                 onChange={(e) => setDescription(e.target.value)}
               />
             </div>
           </div>

           <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-xl bg-slate-950 flex items-center justify-center text-slate-600">
                <Hash size={20} />
             </div>
             <div className="flex-1 overflow-hidden">
               <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Category</label>
               <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
                 {(['food', 'travel', 'hotel', 'shopping', 'others'] as ExpenseCategory[]).map(cat => (
                   <button 
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`px-3 py-1.5 rounded-full text-xs font-semibold capitalize whitespace-nowrap transition-all ${category === cat ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/40' : 'bg-slate-950 text-slate-500 border border-slate-800'}`}
                   >
                     {cat}
                   </button>
                 ))}
               </div>
             </div>
           </div>

           <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-xl bg-slate-950 flex items-center justify-center text-slate-600">
                <User size={20} />
             </div>
             <div className="flex-1">
               <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Paid By</label>
               <select 
                 className="w-full text-sm font-semibold focus:outline-none bg-transparent text-slate-100 border-none cursor-pointer"
                 value={paidBy}
                 onChange={(e) => setPaidBy(e.target.value)}
               >
                 {trip.members.map(m => (
                   <option key={m.id} value={m.id} className="bg-slate-900 text-slate-100">{m.name}</option>
                 ))}
               </select>
             </div>
           </div>
        </div>

        {/* Split Mode Selector */}
        <div className="bg-slate-900 rounded-3xl p-1 shadow-sm border border-slate-800 flex overflow-hidden">
          <button 
            onClick={() => setSplitType('equal')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-[10px] font-black tracking-widest uppercase transition-all ${splitType === 'equal' ? 'bg-slate-800 text-white shadow-inner' : 'text-slate-500'}`}
          >
            <Scale size={14} /> Split Equally
          </button>
          <button 
            onClick={() => setSplitType('exact')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-[10px] font-black tracking-widest uppercase transition-all ${splitType === 'exact' ? 'bg-slate-800 text-white shadow-inner' : 'text-slate-500'}`}
          >
            <Coins size={14} /> Exact Amounts
          </button>
        </div>

        {/* Split Section */}
        <div className="bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-800">
           <div className="mb-6 space-y-4">
             <div className="flex items-center justify-between">
                <h3 className="text-slate-100 font-bold">Split Breakdown</h3>
                {splitType === 'exact' && (
                  <div className={`px-3 py-1 rounded-full text-[9px] font-black flex items-center gap-1.5 transition-all ${isBalanced ? 'bg-emerald-500 text-white' : isOver ? 'bg-rose-500 text-white' : 'bg-amber-500 text-white'}`}>
                    {isBalanced ? <CheckCircle2 size={10} /> : <AlertCircle size={10} />}
                    {isBalanced ? 'BALANCED' : isOver ? `OVER BY ₹${Math.abs(difference).toLocaleString()}` : `₹${Math.abs(difference).toLocaleString()} REMAINING`}
                  </div>
                )}
             </div>

             {splitType === 'exact' && totalBill > 0 && (
                <div className="space-y-2">
                   <div className="flex justify-between items-center text-[8px] font-black uppercase text-slate-500 tracking-tighter">
                      <span>Allocated: ₹{Math.round(currentSplitTotal).toLocaleString()}</span>
                      <span>Goal: ₹{Math.round(totalBill).toLocaleString()}</span>
                   </div>
                   <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div 
                        className={`h-full transition-all duration-500 ${isBalanced ? 'bg-emerald-500' : isOver ? 'bg-rose-500' : 'bg-amber-500'}`}
                        style={{ width: `${percentFilled}%` }}
                      ></div>
                   </div>
                </div>
             )}
           </div>
           
           <div className="space-y-3">
             {trip.members.map(m => (
               <div 
                 key={m.id}
                 className={`flex flex-col p-3 rounded-2xl transition-all border ${selectedSplit.includes(m.id) ? 'bg-indigo-900/10 border-indigo-800/20' : 'bg-slate-950 border-slate-900 opacity-40'}`}
                 onClick={() => !selectedSplit.includes(m.id) && toggleMemberSelection(m.id)}
               >
                 <div className="flex items-center justify-between">
                    <button 
                        onClick={(e) => { e.stopPropagation(); toggleMemberSelection(m.id); }}
                        className="flex items-center gap-3 flex-1 text-left"
                    >
                        <img src={m.avatar} className="w-10 h-10 rounded-full border-2 border-slate-800 shadow-sm" alt="" />
                        <div className="flex-1">
                          <span className="text-xs font-bold text-slate-300 block">{m.name}</span>
                          {selectedSplit.includes(m.id) && splitType === 'equal' && (
                            <span className="text-[10px] text-slate-500">₹{(totalBill / selectedSplit.length).toFixed(0)} share</span>
                          )}
                        </div>
                    </button>

                    {selectedSplit.includes(m.id) && splitType === 'exact' && (
                      <div className="flex items-center gap-2">
                        {!isBalanced && !isOver && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); handleSmartFill(m.id); }}
                            className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl hover:bg-indigo-500 hover:text-white transition-all"
                            title="Fill Remaining"
                          >
                             <Zap size={14} />
                          </button>
                        )}
                        <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800 focus-within:border-indigo-500 transition-all">
                            <span className="text-[10px] font-bold text-slate-600">₹</span>
                            <input 
                              type="number"
                              placeholder="0"
                              className="bg-transparent text-slate-100 text-xs font-black focus:outline-none w-16 text-right"
                              value={customAmounts[m.id] || ''}
                              onClick={(e) => e.stopPropagation()}
                              onChange={(e) => setCustomAmounts(prev => ({ ...prev, [m.id]: e.target.value }))}
                            />
                        </div>
                      </div>
                    )}
                 </div>
               </div>
             ))}
           </div>
        </div>
      </div>
    </SharedLayout>
  );
};

export default EditExpenseView;
