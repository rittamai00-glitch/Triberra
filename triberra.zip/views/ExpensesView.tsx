
import React, { useState, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import SharedLayout from '../components/SharedLayout';
import { Trip, Expense, ExpenseCategory, AuthUser, Member } from '../types';
import { 
  Search, ShoppingBag, Utensils, Plane, Hotel, Layers, Edit2, 
  Trash2, Undo2, X, Calendar, ArrowRight, List, LayoutGrid, 
  Tag, Sparkles, Filter, Banknote, ArrowLeftRight, CheckCircle2,
  ChevronDown, ChevronUp, Users, Info, Calculator, Equal, Divide
} from 'lucide-react';

interface ExpensesViewProps {
  user: AuthUser;
  trip: Trip;
  onDeleteExpense: (id: string) => void;
  onRestoreExpense: (expense: Expense) => void;
}

const CATEGORY_ICONS: Record<ExpenseCategory, React.ReactNode> = {
  food: <Utensils size={18} />,
  travel: <Plane size={18} />,
  hotel: <Hotel size={18} />,
  shopping: <ShoppingBag size={18} />,
  others: <Layers size={18} />,
};

const ExpensesView: React.FC<ExpensesViewProps> = ({ user, trip, onDeleteExpense, onRestoreExpense }) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'spending' | 'settlements'>('all');
  const [selectedDate, setSelectedDate] = useState('All');
  const [viewMode, setViewMode] = useState<'list' | 'ledger'>('list');
  const [expandedExpenseId, setExpandedExpenseId] = useState<string | null>(null);
  
  const [showUndo, setShowUndo] = useState(false);
  const [lastDeleted, setLastDeleted] = useState<Expense | null>(null);
  const undoTimerRef = useRef<number | null>(null);
  const [undoProgress, setUndoProgress] = useState(100);

  const tripDates = useMemo(() => {
    const dates = ['All'];
    const start = new Date(trip.startDate);
    const end = new Date(trip.endDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime())) return dates;
    const current = new Date(start);
    while (current <= end) {
      dates.push(current.toISOString().split('T')[0]);
      current.setDate(current.getDate() + 1);
    }
    return dates;
  }, [trip.startDate, trip.endDate]);

  const filteredExpenses = useMemo(() => {
    return trip.expenses.filter(e => {
      const isSettlement = e.description.startsWith('Settlement:');
      const matchesTab = 
        activeTab === 'all' || 
        (activeTab === 'spending' && !isSettlement) || 
        (activeTab === 'settlements' && isSettlement);
      
      const matchesSearch = e.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDate = selectedDate === 'All' || e.date === selectedDate;
      
      return matchesTab && matchesSearch && matchesDate;
    });
  }, [trip.expenses, searchTerm, activeTab, selectedDate]);

  const ledgerData = useMemo(() => {
    const data: Record<string, Record<string, Record<string, Expense[]>>> = {};
    filteredExpenses.forEach(exp => {
      const date = exp.date;
      const payerId = exp.paidBy;
      const cat = exp.category;
      if (!data[date]) data[date] = {};
      if (!data[date][payerId]) data[date][payerId] = {};
      if (!data[date][payerId][cat]) data[date][payerId][cat] = [];
      data[date][payerId][cat].push(exp);
    });
    return data;
  }, [filteredExpenses]);

  const handleDelete = (e: React.MouseEvent, expense: Expense) => {
    e.stopPropagation(); 
    setLastDeleted(expense);
    setShowUndo(true);
    setUndoProgress(100);
    onDeleteExpense(expense.id);
    
    if (undoTimerRef.current) window.clearInterval(undoTimerRef.current);
    const duration = 5000;
    const startTime = Date.now();
    
    undoTimerRef.current = window.setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, 100 - (elapsed / duration) * 100);
      setUndoProgress(remaining);
      if (elapsed >= duration) {
        if (undoTimerRef.current) window.clearInterval(undoTimerRef.current);
        setShowUndo(false);
        setLastDeleted(null);
      }
    }, 16);
  };

  const handleUndo = () => {
    if (lastDeleted) {
      onRestoreExpense(lastDeleted);
      setShowUndo(false);
      setLastDeleted(null);
      if (undoTimerRef.current) window.clearInterval(undoTimerRef.current);
    }
  };

  const formatDateLabel = (dateStr: string) => {
    if (dateStr === 'All') return 'Entire Trip';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  };

  const toggleExpand = (id: string) => {
    setExpandedExpenseId(expandedExpenseId === id ? null : id);
  };

  return (
    <SharedLayout activeTab="expenses" user={user} title="Expense History">
      <div className="space-y-5">
        
        {/* Undo Toast */}
        {showUndo && (
          <div className="fixed bottom-28 left-0 right-0 px-6 z-[60] animate-in slide-in-from-bottom-8 duration-300">
            <div className="max-w-[360px] mx-auto bg-slate-900 dark:bg-slate-100 rounded-3xl overflow-hidden shadow-2xl border border-white/10 dark:border-slate-800">
               <div className="p-4 flex items-center justify-between">
                 <div className="flex items-center gap-3">
                   <div className="w-9 h-9 bg-rose-500 rounded-xl flex items-center justify-center text-white">
                      <Trash2 size={16} />
                   </div>
                   <div>
                     <p className="text-[11px] font-black text-white dark:text-slate-900 uppercase tracking-widest">Transaction Removed</p>
                     <p className="text-[8px] font-bold text-slate-400 dark:text-slate-500 uppercase">Entry deleted from vault</p>
                   </div>
                 </div>
                 <button 
                  onClick={handleUndo} 
                  className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-90 transition-all shadow-lg shadow-indigo-500/20"
                 >
                    Restore
                 </button>
               </div>
               <div className="h-1 bg-slate-800/50 dark:bg-slate-200/50">
                 <div 
                   className="h-full bg-gradient-to-r from-indigo-400 to-cyan-400 transition-all ease-linear" 
                   style={{ width: `${undoProgress}%` }}
                 ></div>
               </div>
            </div>
          </div>
        )}

        {/* View Selection Toggle */}
        <div className="flex bg-slate-200/50 dark:bg-slate-900/50 rounded-2xl p-1 shadow-inner border border-slate-200/50 dark:border-white/5">
           <button 
             onClick={() => setViewMode('list')} 
             className={`flex-1 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-cyan-400 shadow-sm' : 'text-slate-500'}`}
           >
              <List size={14} className="inline mr-2" /> Quick List
           </button>
           <button 
             onClick={() => setViewMode('ledger')} 
             className={`flex-1 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${viewMode === 'ledger' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-cyan-400 shadow-sm' : 'text-slate-500'}`}
           >
              <LayoutGrid size={14} className="inline mr-2" /> Insight Ledger
           </button>
        </div>

        {/* Filters Group */}
        <div className="flex flex-col gap-4">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Search history..."
              className="w-full bg-white dark:bg-slate-900/50 text-slate-900 dark:text-slate-100 rounded-2xl py-4 pl-12 pr-4 text-xs font-bold border border-slate-200 dark:border-white/5 focus:outline-none focus:ring-2 focus:ring-indigo-500/10 transition-all shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex bg-slate-100 dark:bg-slate-950/40 rounded-2xl p-1">
            <button 
              onClick={() => setActiveTab('all')} 
              className={`flex-1 py-2 rounded-xl text-[8px] font-black uppercase tracking-[0.2em] transition-all ${activeTab === 'all' ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-sm' : 'text-slate-400'}`}
            >
               All
            </button>
            <button 
              onClick={() => setActiveTab('spending')} 
              className={`flex-1 py-2 rounded-xl text-[8px] font-black uppercase tracking-[0.2em] transition-all ${activeTab === 'spending' ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-sm' : 'text-slate-400'}`}
            >
               Spending
            </button>
            <button 
              onClick={() => setActiveTab('settlements')} 
              className={`flex-1 py-2 rounded-xl text-[8px] font-black uppercase tracking-[0.2em] transition-all ${activeTab === 'settlements' ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-sm' : 'text-slate-400'}`}
            >
               Settled
            </button>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
            {tripDates.map(date => (
              <button 
                key={date} 
                onClick={() => setSelectedDate(date)}
                className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-tight whitespace-nowrap transition-all border ${selectedDate === date ? 'bg-slate-900 dark:bg-white border-transparent text-white dark:text-slate-900 shadow-md' : 'bg-white dark:bg-slate-900 text-slate-400 border-slate-200 dark:border-white/5'}`}
              >
                {formatDateLabel(date)}
              </button>
            ))}
          </div>
        </div>

        {/* View Render */}
        <div className="space-y-4 pb-28">
          {filteredExpenses.length === 0 ? (
            <div className="text-center py-20 opacity-30 flex flex-col items-center">
               <Layers size={64} strokeWidth={1} className="mb-4 text-slate-300" />
               <p className="text-[10px] font-black uppercase tracking-[0.2em]">No matches found</p>
            </div>
          ) : viewMode === 'list' ? (
            filteredExpenses.map((expense) => {
              const isSettlement = expense.description.startsWith('Settlement:');
              const payer = trip.members.find(m => m.id === expense.paidBy);
              const isExpanded = expandedExpenseId === expense.id;
              
              return (
                <div 
                  key={expense.id} 
                  className={`group relative overflow-hidden bg-white dark:bg-slate-900 rounded-[2.2rem] shadow-sm border transition-all ${isExpanded ? 'ring-2 ring-indigo-500/20' : 'border-slate-200/50 dark:border-white/5'}`}
                >
                  <div 
                    className="p-5 flex items-center gap-4 cursor-pointer"
                    onClick={() => toggleExpand(expense.id)}
                  >
                    <div className={`w-12 h-12 rounded-[1.2rem] flex items-center justify-center text-white shadow-sm shrink-0 ${isSettlement ? 'bg-emerald-500' : expense.category === 'food' ? 'bg-rose-500/80' : expense.category === 'travel' ? 'bg-sky-500/80' : 'bg-indigo-500/80'}`}>
                      {isSettlement ? <ArrowLeftRight size={20} /> : CATEGORY_ICONS[expense.category]}
                    </div>

                    <div className="flex-1 min-w-0">
                      <h4 className={`text-xs font-black truncate mb-0.5 ${isSettlement ? 'text-indigo-600 dark:text-cyan-400' : 'text-slate-900 dark:text-slate-100'}`}>
                        {isSettlement ? "Settlement" : expense.description}
                      </h4>
                      <p className="text-[9px] text-slate-400 uppercase font-black tracking-widest flex items-center gap-2">
                         <span>{payer?.name}</span>
                         <span className="opacity-30">•</span>
                         <span>{formatDateLabel(expense.date)}</span>
                      </p>
                    </div>

                    <div className="flex flex-col items-end shrink-0">
                      <p className="text-sm font-black text-slate-900 dark:text-slate-100">₹{Math.round(expense.amount).toLocaleString()}</p>
                      {isExpanded ? <ChevronUp size={14} className="text-indigo-500" /> : <ChevronDown size={14} className="text-slate-300" />}
                    </div>
                  </div>

                  {/* Expanded Split Breakdown & Calculation Box */}
                  {isExpanded && (
                    <div className="px-5 pb-5 pt-2 border-t border-slate-50 dark:border-white/5 animate-in slide-in-from-top-2 duration-300">
                       
                       {!isSettlement && (
                         <div className="mb-6 bg-slate-50 dark:bg-slate-950 p-4 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800">
                            <div className="flex items-center gap-2 mb-3">
                               <Calculator size={14} className="text-indigo-500" />
                               <h5 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Calculation Logic</h5>
                            </div>
                            <div className="flex items-center justify-between px-2">
                               <div className="flex flex-col items-center">
                                  <span className="text-[11px] font-black">₹{Math.round(expense.amount).toLocaleString()}</span>
                                  <span className="text-[7px] font-bold text-slate-400 uppercase">Total Bill</span>
                               </div>
                               <Divide size={12} className="text-slate-300" />
                               <div className="flex flex-col items-center">
                                  <span className="text-[11px] font-black">{expense.splitAmong.length}</span>
                                  <span className="text-[7px] font-bold text-slate-400 uppercase">Buddies</span>
                               </div>
                               <Equal size={12} className="text-slate-300" />
                               <div className="flex flex-col items-center">
                                  <span className="text-[11px] font-black text-indigo-500">₹{Math.round(expense.amount / expense.splitAmong.length).toLocaleString()}</span>
                                  <span className="text-[7px] font-black text-indigo-500/60 uppercase">Per Share</span>
                               </div>
                            </div>
                            <p className="mt-3 text-[8px] font-bold text-slate-400 uppercase tracking-tighter text-center italic">
                               {expense.customSplit ? "Calculation adjusted based on custom entry provided." : "Calculated as a flat equal split across all selected members."}
                            </p>
                         </div>
                       )}

                       <div className="flex items-center gap-2 mb-4">
                          <Users size={12} className="text-indigo-500" />
                          <h5 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Distribution</h5>
                       </div>
                       
                       <div className="space-y-2 mb-6">
                         {expense.splitAmong.map(mId => {
                           const member = trip.members.find(m => m.id === mId);
                           const isPayer = mId === expense.paidBy;
                           const shareAmount = expense.customSplit?.[mId] !== undefined 
                             ? expense.customSplit[mId] 
                             : (expense.amount / expense.splitAmong.length);

                           return (
                             <div key={mId} className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-white/5 rounded-2xl border border-transparent hover:border-slate-100 dark:hover:border-white/5 transition-all">
                                <div className="flex items-center gap-3">
                                   <img src={member?.avatar} className="w-7 h-7 rounded-xl border border-white dark:border-slate-800 shadow-sm" alt="" />
                                   <div>
                                      <p className="text-[10px] font-bold">{member?.name}</p>
                                      {isPayer && <span className="text-[8px] font-black text-indigo-500 uppercase tracking-widest">Paid Total</span>}
                                   </div>
                                </div>
                                <div className="text-right">
                                   <p className="text-[11px] font-black">₹{Math.round(shareAmount).toLocaleString()}</p>
                                   <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                                     {expense.customSplit ? 'Custom' : 'Equal Share'}
                                   </p>
                                </div>
                             </div>
                           );
                         })}
                       </div>

                       <div className="flex items-center gap-2 pt-2">
                          <button 
                            onClick={(e) => { e.stopPropagation(); navigate(`/edit-expense/${expense.id}`); }}
                            className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-200 rounded-2xl text-[9px] font-black uppercase tracking-widest transition-all active:scale-95"
                          >
                             <Edit2 size={12} className="inline mr-1" /> Edit Log
                          </button>
                          <button 
                            onClick={(e) => handleDelete(e, expense)} 
                            className="flex-1 py-3 bg-rose-50 dark:bg-rose-500/10 text-rose-500 rounded-2xl text-[9px] font-black uppercase tracking-widest transition-all active:scale-95"
                          >
                             <Trash2 size={12} className="inline mr-1" /> Remove
                          </button>
                       </div>
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            /* INSIGHT LEDGER VIEW (Date-wise, Person-wise, Category-wise) */
            <div className="space-y-8 animate-in fade-in duration-500">
               {(Object.entries(ledgerData) as [string, Record<string, Record<string, Expense[]>>][]).sort((a,b) => b[0].localeCompare(a[0])).map(([date, memberGroup]) => (
                <div key={date} className="space-y-5">
                  <div className="flex items-center gap-3 px-2">
                    <Calendar size={16} className="text-indigo-500" />
                    <h3 className="text-sm font-black tracking-tight">{formatDateLabel(date)}</h3>
                    <div className="flex-1 h-[1px] bg-slate-200 dark:bg-white/5"></div>
                  </div>
                  
                  {(Object.entries(memberGroup) as [string, Record<string, Expense[]>][]).map(([memberId, catGroup]) => {
                    const member = trip.members.find(m => m.id === memberId);
                    const memberTotal = (Object.values(catGroup) as Expense[][]).flat().reduce((sum, e) => sum + e.amount, 0);

                    return (
                      <div key={memberId} className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-sm border border-slate-200/50 dark:border-white/5 space-y-6">
                        <div className="flex items-center justify-between border-b border-slate-100 dark:border-white/5 pb-5">
                           <div className="flex items-center gap-4">
                              <img src={member?.avatar} className="w-12 h-12 rounded-2xl border-2 border-white dark:border-slate-800 shadow-sm" alt="" />
                              <div>
                                 <p className="text-sm font-black">{member?.name}</p>
                                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Primary Payer</p>
                              </div>
                           </div>
                           <div className="text-right">
                              <p className="text-xs font-black text-indigo-600 dark:text-cyan-400">₹{Math.round(memberTotal).toLocaleString()}</p>
                              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Contribution</p>
                           </div>
                        </div>
                        
                        <div className="space-y-6">
                          {(Object.entries(catGroup) as [string, Expense[]][]).map(([cat, expenses]) => (
                            <div key={cat} className="space-y-3">
                               <div className="flex items-center gap-2">
                                  <div className={`p-1.5 rounded-lg text-white shadow-sm ${cat === 'food' ? 'bg-rose-500/80' : cat === 'travel' ? 'bg-sky-500/80' : 'bg-indigo-500/80'}`}>
                                    {CATEGORY_ICONS[cat as ExpenseCategory]}
                                  </div>
                                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{cat}</span>
                               </div>
                               <div className="space-y-3 pl-4 border-l-2 border-slate-100 dark:border-white/5">
                                  {expenses.map(exp => (
                                    <div key={exp.id} className="flex justify-between items-center group/item py-1">
                                       <div className="flex-1 min-w-0 pr-4">
                                          <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{exp.description}</p>
                                          <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                                            Split with {exp.splitAmong.length} buddies
                                          </p>
                                       </div>
                                       <div className="flex items-center gap-4">
                                          <p className="text-xs font-black text-slate-900 dark:text-slate-100">₹{Math.round(exp.amount).toLocaleString()}</p>
                                          <button 
                                            onClick={(e) => handleDelete(e, exp)} 
                                            className="opacity-0 group-hover/item:opacity-100 transition-opacity text-rose-400 hover:text-rose-600"
                                          >
                                            <Trash2 size={14}/>
                                          </button>
                                       </div>
                                    </div>
                                  ))}
                               </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </SharedLayout>
  );
};

export default ExpensesView;
