
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SharedLayout from '../components/SharedLayout';
import { Trip } from '../types';
import { 
  History, Calendar, MapPin, IndianRupee, Users, 
  ChevronRight, ArrowLeft, Archive, Sparkles, Image as ImageIcon,
  Trophy, TrendingUp, Info, X, Zap
} from 'lucide-react';

interface HistoryViewProps {
  history: Trip[];
}

const HistoryView: React.FC<HistoryViewProps> = ({ history }) => {
  const navigate = useNavigate();
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);

  return (
    <SharedLayout activeTab="settings" title="My Journeys">
      <div className="space-y-6 pb-24 relative">
        
        {/* Trip Summary Modal */}
        {selectedTrip && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-300">
             <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[3rem] overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-300 relative">
                
                <div className="h-48 relative">
                   {selectedTrip.coverImage ? (
                     <img src={selectedTrip.coverImage} className="w-full h-full object-cover" alt="" />
                   ) : (
                     <div className="w-full h-full bg-slate-200 dark:bg-slate-800"></div>
                   )}
                   <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent"></div>
                   <button 
                     onClick={() => setSelectedTrip(null)}
                     className="absolute top-6 right-6 p-2 bg-black/20 backdrop-blur-md text-white rounded-full hover:bg-black/40 transition-all"
                   >
                     <X size={20} />
                   </button>
                   <div className="absolute bottom-6 left-8">
                      <h3 className="text-white text-2xl font-black">{selectedTrip.destination.split(',')[0]}</h3>
                      <p className="text-white/60 text-[10px] font-black uppercase tracking-widest">{selectedTrip.startDate} - {selectedTrip.endDate}</p>
                   </div>
                </div>

                <div className="p-8 space-y-8">
                   <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-slate-50 dark:bg-white/5 rounded-3xl border border-slate-100 dark:border-white/5">
                         <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Burn</p>
                         <p className="text-lg font-black text-indigo-500">₹{selectedTrip.expenses.reduce((s,e) => s+e.amount, 0).toLocaleString()}</p>
                      </div>
                      <div className="p-4 bg-slate-50 dark:bg-white/5 rounded-3xl border border-slate-100 dark:border-white/5">
                         <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Squad Size</p>
                         <p className="text-lg font-black text-cyan-500">{selectedTrip.members.length} Buddies</p>
                      </div>
                   </div>

                   <div className="space-y-4">
                      <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Quick Stats</h4>
                      <div className="space-y-2">
                         <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-white/5">
                            <span className="text-xs font-bold text-slate-500">Transaction Logs</span>
                            <span className="text-xs font-black">{selectedTrip.expenses.length}</span>
                         </div>
                         <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-white/5">
                            <span className="text-xs font-bold text-slate-500">Avg. Per Day</span>
                            <span className="text-xs font-black">₹{Math.round(selectedTrip.expenses.reduce((s,e) => s+e.amount, 0) / 7).toLocaleString()}</span>
                         </div>
                      </div>
                   </div>

                   <button 
                     onClick={() => setSelectedTrip(null)}
                     className="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all"
                   >
                     Close Memories
                   </button>
                </div>
             </div>
          </div>
        )}

        <div className="flex items-center gap-4 mb-2">
           <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors">
             <ArrowLeft size={20} className="text-slate-500" />
           </button>
           <h2 className="text-xl font-black tracking-tight">Travel Vault</h2>
        </div>

        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center px-8">
            <div className="w-24 h-24 bg-slate-100 dark:bg-slate-900 rounded-[2.5rem] flex items-center justify-center mb-8 text-slate-300 dark:text-slate-700 relative">
               <Archive size={48} />
               <Zap className="absolute -top-2 -right-2 text-indigo-500/20" size={32} />
            </div>
            <h3 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight">The Vault is Empty</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-3 leading-relaxed max-w-[240px]">Finish your active journey to archive it here as a permanent memory log.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5">
            {history.map((trip) => {
              const totalSpent = trip.expenses.reduce((sum, e) => sum + e.amount, 0);
              return (
                <div 
                  key={trip.id}
                  onClick={() => setSelectedTrip(trip)}
                  className="bg-white dark:bg-slate-900 rounded-[3rem] overflow-hidden border border-slate-200 dark:border-white/10 shadow-sm group active:scale-[0.97] transition-all cursor-pointer"
                >
                  <div className="relative h-44 w-full overflow-hidden">
                    {trip.coverImage ? (
                      <img src={trip.coverImage} className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-1000" alt="" />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-800 dark:to-slate-900 flex items-center justify-center">
                        <ImageIcon className="text-slate-400" size={32} />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
                    
                    {/* Victory Ribbon */}
                    <div className="absolute top-6 left-6 flex items-center gap-2 bg-indigo-600 text-white px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest shadow-xl">
                       <Trophy size={10} /> Completed
                    </div>

                    <div className="absolute bottom-6 left-8">
                       <h3 className="text-white font-black text-2xl tracking-tight mb-0.5">{trip.destination.split(',')[0]}</h3>
                       <div className="flex items-center gap-2 text-white/60 text-[9px] font-bold uppercase tracking-widest">
                          <Calendar size={10} />
                          <span>{new Date(trip.startDate).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}</span>
                       </div>
                    </div>
                  </div>
                  
                  <div className="p-8">
                    <div className="grid grid-cols-3 gap-6">
                       <div className="space-y-1">
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Investment</p>
                          <div className="flex items-center gap-1.5 text-slate-900 dark:text-slate-100">
                             <TrendingUp size={12} className="text-indigo-500" />
                             <span className="text-sm font-black tracking-tight">₹{Math.round(totalSpent).toLocaleString()}</span>
                          </div>
                       </div>
                       <div className="space-y-1">
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Buddies</p>
                          <div className="flex items-center gap-1.5 text-slate-900 dark:text-slate-100">
                             <Users size={12} className="text-indigo-500" />
                             <span className="text-sm font-black tracking-tight">{trip.members.length}</span>
                          </div>
                       </div>
                       <div className="flex flex-col justify-center items-end">
                          <div className="w-10 h-10 bg-slate-50 dark:bg-white/5 rounded-2xl flex items-center justify-center text-slate-400 group-hover:text-indigo-500 transition-all">
                             <ChevronRight size={20} />
                          </div>
                       </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="bg-slate-200/50 dark:bg-slate-900/50 border border-dashed border-slate-300 dark:border-white/10 rounded-[2.5rem] p-8 text-center mt-4">
           <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white dark:bg-slate-800 rounded-full mb-4 shadow-sm">
              <Sparkles size={12} className="text-amber-500" />
              <p className="text-[9px] font-black text-slate-500 dark:text-slate-300 uppercase tracking-widest">Travel Legacy Locked</p>
           </div>
           <p className="text-[10px] text-slate-500 leading-relaxed italic max-w-[280px] mx-auto">
             "A journey is best measured in friends, rather than miles."
           </p>
        </div>
      </div>
    </SharedLayout>
  );
};

export default HistoryView;
