
import React, { useMemo } from 'react';
import SharedLayout from '../components/SharedLayout';
import { Trip, AuthUser, ExpenseCategory } from '../types';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, 
  XAxis, YAxis, Tooltip, AreaChart, Area, CartesianGrid 
} from 'recharts';
import { 
  TrendingUp, Wallet, Users, LayoutDashboard, Utensils, 
  Plane, Hotel, ShoppingBag, Layers, Activity, Calendar, ArrowRight,
  Sparkles, Zap
} from 'lucide-react';

interface InsightsViewProps {
  user: AuthUser;
  trip: Trip;
}

const CATEGORY_COLORS: Record<string, string> = {
  food: '#fb7185', // rose-400
  travel: '#38bdf8', // sky-400
  hotel: '#fbbf24', // amber-400
  shopping: '#34d399', // emerald-400
  others: '#a78bfa', // violet-400
};

const InsightsView: React.FC<InsightsViewProps> = ({ user, trip }) => {
  
  // 1. Spending by Category
  const categoryData = useMemo(() => {
    const totals: Record<string, number> = {
      food: 0, travel: 0, hotel: 0, shopping: 0, others: 0
    };
    
    trip.expenses.forEach(exp => {
      if (!exp.description.startsWith('Settlement:')) {
        totals[exp.category] += exp.amount;
      }
    });

    return Object.entries(totals)
      .filter(([_, val]) => val > 0)
      .map(([name, value]) => ({ 
        name: name.charAt(0).toUpperCase() + name.slice(1), 
        value,
        id: name 
      }));
  }, [trip.expenses]);

  // 2. Spending by Date (Timeline)
  const timelineData = useMemo(() => {
    const dailyTotals: Record<string, number> = {};
    
    // Initialize all dates in range
    const start = new Date(trip.startDate);
    const end = new Date(trip.endDate);
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dateStr = d.toISOString().split('T')[0];
      dailyTotals[dateStr] = 0;
    }

    trip.expenses.forEach(exp => {
      if (!exp.description.startsWith('Settlement:')) {
        if (dailyTotals[exp.date] !== undefined) {
          dailyTotals[exp.date] += exp.amount;
        }
      }
    });

    return Object.entries(dailyTotals).map(([date, total]) => ({
      date: new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
      amount: total
    }));
  }, [trip.expenses, trip.startDate, trip.endDate]);

  // 3. Spending by Person (Consumption)
  const personData = useMemo(() => {
    const memberConsumption: Record<string, number> = {};
    trip.members.forEach(m => memberConsumption[m.id] = 0);

    trip.expenses.forEach(exp => {
      if (!exp.description.startsWith('Settlement:')) {
        if (exp.customSplit) {
          Object.entries(exp.customSplit).forEach(([mId, amt]) => {
            // Fix: Cast amt to number to resolve operator += on unknown type
            if (memberConsumption[mId] !== undefined) memberConsumption[mId] += (amt as number);
          });
        } else {
          const share = exp.amount / exp.splitAmong.length;
          exp.splitAmong.forEach(mId => {
            if (memberConsumption[mId] !== undefined) memberConsumption[mId] += share;
          });
        }
      }
    });

    return trip.members.map(m => ({
      name: m.name.split(' ')[0],
      consumption: Math.round(memberConsumption[m.id])
    })).sort((a, b) => b.consumption - a.consumption);
  }, [trip.expenses, trip.members]);

  const totalSpent = useMemo(() => 
    trip.expenses.filter(e => !e.description.startsWith('Settlement:')).reduce((s, e) => s + e.amount, 0),
  [trip.expenses]);

  const maxDaily = useMemo(() => Math.max(...timelineData.map(d => d.amount), 0), [timelineData]);
  const avgDaily = Math.round(totalSpent / timelineData.length);

  return (
    <SharedLayout activeTab="insights" user={user} title="Insights">
      <div className="space-y-6 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
        
        {/* Summary Hero Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden group">
            <div className="absolute -right-2 -top-2 opacity-5 text-indigo-500">
              <TrendingUp size={80} />
            </div>
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">Total Burn</p>
            <div className="flex items-end gap-1">
              <span className="text-2xl font-black text-slate-900 dark:text-slate-100">₹{totalSpent.toLocaleString()}</span>
              <span className="text-[10px] font-bold text-slate-400 mb-1">/ {trip.budget.toLocaleString()}</span>
            </div>
            <div className="mt-3 w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
               <div 
                 className="h-full bg-gradient-to-r from-indigo-500 to-cyan-500 transition-all duration-1000"
                 style={{ width: `${Math.min(100, (totalSpent / trip.budget) * 100)}%` }}
               ></div>
            </div>
          </div>
          <div className="bg-white dark:bg-slate-900 p-5 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">Daily Avg</p>
            <div className="flex items-center gap-2">
              <Zap size={14} className="text-amber-500" />
              <span className="text-2xl font-black text-slate-900 dark:text-slate-100">₹{avgDaily.toLocaleString()}</span>
            </div>
            <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-tight">Per day of trip</p>
          </div>
        </div>

        {/* Category Donut Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-sm border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between mb-6">
             <h3 className="font-bold flex items-center gap-2">
                <LayoutDashboard size={18} className="text-indigo-500" />
                Category Split
             </h3>
             <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{categoryData.length} active</span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="h-48 w-48 shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    animationDuration={1500}
                    stroke="none"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[entry.id as ExpenseCategory] || '#6366f1'} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#0f172a', 
                      border: 'none', 
                      borderRadius: '16px',
                      fontSize: '10px',
                      fontWeight: 'bold',
                      color: '#fff'
                    }}
                    itemStyle={{ color: '#fff' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            
            <div className="flex-1 space-y-2">
              {categoryData.map(cat => (
                <div key={cat.id} className="flex items-center justify-between gap-2">
                   <div className="flex items-center gap-2 min-w-0">
                      <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: CATEGORY_COLORS[cat.id as ExpenseCategory] }}></div>
                      <span className="text-[10px] font-bold truncate text-slate-600 dark:text-slate-400">{cat.name}</span>
                   </div>
                   <span className="text-[10px] font-black">₹{Math.round(cat.value).toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Timeline Area Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-sm border border-slate-200 dark:border-slate-800">
           <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold flex items-center gap-2">
                 <Activity size={18} className="text-cyan-500" />
                 Spend Timeline
              </h3>
              <div className="flex items-center gap-1.5 px-2 py-1 bg-cyan-50 dark:bg-cyan-950/30 rounded-full">
                 <div className="w-1 h-1 bg-cyan-500 rounded-full animate-pulse"></div>
                 <span className="text-[9px] font-black uppercase text-cyan-600 dark:text-cyan-400 tracking-widest">₹{maxDaily.toLocaleString()} Peak</span>
              </div>
           </div>

           <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={timelineData}>
                  <defs>
                    <linearGradient id="colorAmt" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.1} />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 9, fontWeight: 700, fill: '#94a3b8' }} 
                    dy={10}
                  />
                  <Tooltip 
                    cursor={{ stroke: '#38bdf8', strokeWidth: 1 }}
                    contentStyle={{ 
                      backgroundColor: '#0f172a', 
                      border: 'none', 
                      borderRadius: '16px',
                      fontSize: '11px',
                      fontWeight: '800'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="amount" 
                    stroke="#38bdf8" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorAmt)" 
                    animationDuration={2000}
                  />
                </AreaChart>
              </ResponsiveContainer>
           </div>
        </div>

        {/* Participant Bar Chart */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-sm border border-slate-200 dark:border-slate-800">
           <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold flex items-center gap-2">
                 <Users size={18} className="text-indigo-500" />
                 Who's Enjoying?
              </h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Share per Person</p>
           </div>

           <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={personData} layout="vertical" margin={{ left: -10, right: 20 }}>
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 800, fill: '#64748b' }} 
                  />
                  <Tooltip 
                    cursor={{ fill: 'rgba(99, 102, 241, 0.05)' }}
                    contentStyle={{ 
                      backgroundColor: '#0f172a', 
                      border: 'none', 
                      borderRadius: '16px',
                      fontSize: '10px'
                    }}
                  />
                  <Bar 
                    dataKey="consumption" 
                    fill="#6366f1" 
                    radius={[0, 10, 10, 0]} 
                    barSize={16}
                    animationDuration={1500}
                  />
                </BarChart>
              </ResponsiveContainer>
           </div>
           
           <div className="mt-4 p-4 bg-slate-50 dark:bg-slate-950 rounded-3xl border border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg">
                 <Sparkles size={18} />
              </div>
              <div>
                 <p className="text-[10px] font-black uppercase text-indigo-600 dark:text-cyan-400 tracking-widest">Leader Insight</p>
                 <p className="text-[11px] font-bold text-slate-600 dark:text-slate-400 italic">
                   {personData[0]?.name} is the top spender so far with ₹{personData[0]?.consumption.toLocaleString()}.
                 </p>
              </div>
           </div>
        </div>

        <div className="pb-8"></div>
      </div>
    </SharedLayout>
  );
};

export default InsightsView;
