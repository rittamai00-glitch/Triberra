
import React, { useState, useEffect, useMemo } from 'react';
import SharedLayout from '../components/SharedLayout';
import { Trip, ItineraryItem, AISuggestion, AuthUser } from '../types';
import { suggestItinerary, generateTripImage, suggestLocationIdeas } from '../services/geminiService';
import { 
  Calendar, MapPin, Clock, Plus, CheckCircle2, Circle, X, Check, Edit2, 
  Trash2, Sparkles, Loader2, ArrowUpRight, RefreshCw, Layers, CalendarDays,
  Search, Wand2
} from 'lucide-react';

interface ItineraryViewProps {
  user: AuthUser;
  trip: Trip;
  onUpdateTrip: (updates: Partial<Trip>) => void;
  onAdd: (item: Omit<ItineraryItem, 'id'>) => void;
  onToggle: (id: string) => void;
  onUpdate: (item: ItineraryItem) => void;
  onDelete: (id: string) => void;
}

const ItineraryView: React.FC<ItineraryViewProps> = ({ user, trip, onUpdateTrip, onAdd, onToggle, onUpdate, onDelete }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [editingItem, setEditingItem] = useState<ItineraryItem | null>(null);
  
  const [newTitle, setNewTitle] = useState('');
  const [newTime, setNewTime] = useState('');
  const [newDate, setNewDate] = useState(trip.startDate);
  const [newLocation, setNewLocation] = useState('');

  const [aiSuggestions, setAiSuggestions] = useState<AISuggestion[]>([]);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [imgLoading, setImgLoading] = useState(false);

  // Contextual Location Suggestions state
  const [locationIdeas, setLocationIdeas] = useState<string[]>([]);
  const [isFetchingLocations, setIsFetchingLocations] = useState(false);

  useEffect(() => {
    if (!trip.coverImage) {
      handleGenerateCover();
    }
  }, [trip.destination]);

  const handleGenerateCover = async () => {
    setImgLoading(true);
    const url = await generateTripImage(trip.destination);
    if (url) onUpdateTrip({ coverImage: url });
    setImgLoading(false);
  };

  const resetForm = () => {
    setNewTitle('');
    setNewTime('');
    setNewDate(trip.startDate);
    setNewLocation('');
    setShowAdd(false);
    setEditingItem(null);
    setLocationIdeas([]);
  };

  const handleSave = () => {
    if (!newTitle) { alert("First fill the activity title and then click the Save button."); return; }
    if (!newDate) { alert("First fill the date and then click the Save button."); return; }
    if (!newLocation) { alert("First fill the location and then click the Save button."); return; }
    
    if (editingItem) {
      onUpdate({
        ...editingItem,
        title: newTitle,
        time: newTime,
        date: newDate,
        location: newLocation
      });
    } else {
      onAdd({
        title: newTitle,
        time: newTime,
        location: newLocation,
        date: newDate,
        isCompleted: false
      });
    }
    resetForm();
  };

  const startEdit = (item: ItineraryItem) => {
    setEditingItem(item);
    setNewTitle(item.title);
    setNewTime(item.time);
    setNewDate(item.date);
    setNewLocation(item.location);
    setShowAdd(true);
    setLocationIdeas([]);
  };

  const handleFetchSuggestions = async () => {
    setIsSuggesting(true);
    setShowSuggestions(true);
    const results = await suggestItinerary(trip.destination);
    setAiSuggestions(results);
    setIsSuggesting(false);
  };

  const fetchLocationIdeas = async () => {
    if (isFetchingLocations) return;
    setIsFetchingLocations(true);
    const ideas = await suggestLocationIdeas(trip.destination, newDate);
    setLocationIdeas(ideas);
    setIsFetchingLocations(false);
  };

  const addAISuggestion = (s: AISuggestion) => {
    onAdd({
      title: s.title,
      time: s.time,
      location: s.location,
      notes: s.notes,
      date: trip.startDate, // Default AI suggestions to day 1
      isCompleted: false
    });
    setAiSuggestions(prev => prev.filter(item => item.title !== s.title));
  };

  // Group itinerary by date
  const groupedItinerary = useMemo<Record<string, ItineraryItem[]>>(() => {
    const sorted = [...trip.itinerary].sort((a, b) => {
      const dateDiff = new Date(a.date).getTime() - new Date(b.date).getTime();
      if (dateDiff !== 0) return dateDiff;
      return a.time.localeCompare(b.time);
    });

    const groups: Record<string, ItineraryItem[]> = {};
    sorted.forEach(item => {
      if (!groups[item.date]) groups[item.date] = [];
      groups[item.date].push(item);
    });
    return groups;
  }, [trip.itinerary]);

  const getDayNumber = (dateStr: string) => {
    const start = new Date(trip.startDate);
    const current = new Date(dateStr);
    const diffTime = Math.abs(current.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays + 1;
  };

  const formatDateLabel = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  };

  return (
    <SharedLayout activeTab="itinerary" user={user} title="Itinerary">
      <div className="space-y-6 text-slate-100 dark:text-slate-100 pb-10 relative">
        
        {/* Hero Section */}
        <div className="relative h-64 w-full rounded-[2.5rem] overflow-hidden shadow-2xl group transition-all duration-700">
          {trip.coverImage ? (
            <div className="absolute inset-0">
               <img 
                 src={trip.coverImage} 
                 className="w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-[10s]" 
                 alt={trip.destination} 
               />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent"></div>
            </div>
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 to-cyan-700 animate-pulse flex items-center justify-center">
               <div className="text-center">
                  <RefreshCw className="animate-spin text-white/50 mx-auto mb-2" size={32} />
                  <p className="text-[10px] font-black uppercase tracking-widest text-white/70">Generating Landscape...</p>
               </div>
            </div>
          )}

          <div className="absolute inset-0 flex flex-col justify-end p-6 z-10">
             <div className="flex justify-between items-end">
                <div>
                  <p className="text-white/60 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Exploring</p>
                  <h2 className="text-3xl font-black tracking-tight leading-none drop-shadow-xl text-white">
                    {trip.destination.split(',')[0]}
                  </h2>
                  <div className="flex items-center gap-2 mt-2 text-white/70 text-[11px] font-bold">
                    <Calendar size={12} className="opacity-50" />
                    <span>{trip.itinerary.length} Scheduled Stops</span>
                  </div>
                </div>
                <button 
                  onClick={handleFetchSuggestions}
                  className="bg-white/20 backdrop-blur-md hover:bg-white/30 p-3 rounded-2xl text-white transition-all active:scale-90 border border-white/10"
                >
                  {isSuggesting ? <Loader2 size={20} className="animate-spin" /> : <Sparkles size={20} />}
                </button>
             </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center px-1 pt-2">
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">Journey Flow</h2>
          <button 
            onClick={() => {
              if (showAdd) resetForm();
              else setShowAdd(true);
            }}
            className="w-10 h-10 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-all"
          >
            {showAdd ? <X size={20} /> : <Plus size={20} />}
          </button>
        </div>

        {showSuggestions && (
          <div className="bg-indigo-50/50 dark:bg-indigo-900/10 rounded-[2.5rem] p-6 border border-indigo-100 dark:border-indigo-900/30 animate-in slide-in-from-top-4 duration-500 overflow-hidden relative">
             <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                <Sparkles size={80} className="text-indigo-600" />
             </div>
             <div className="flex items-center justify-between mb-4 relative z-10">
                <div className="flex items-center gap-2">
                   <Sparkles size={16} className="text-indigo-600 dark:text-cyan-400" />
                   <h3 className="font-black text-xs uppercase tracking-widest text-indigo-600 dark:text-cyan-400">AI Local Gems</h3>
                </div>
                <button onClick={() => setShowSuggestions(false)} className="text-slate-400 p-1"><X size={14} /></button>
             </div>
             
             <div className="space-y-3 relative z-10">
                {isSuggesting ? (
                  <div className="py-8 flex flex-col items-center gap-2">
                     <Loader2 className="animate-spin text-indigo-600" />
                     <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Scanning {trip.destination} for secrets...</p>
                  </div>
                ) : aiSuggestions.map((s, i) => (
                  <div key={i} className="bg-white dark:bg-slate-900/80 backdrop-blur-sm p-4 rounded-3xl flex items-center justify-between shadow-sm border border-slate-100 dark:border-slate-800 transition-all hover:scale-[1.02] active:scale-95">
                     <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-bold truncate pr-4">{s.title}</h4>
                        <p className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">{s.location} • {s.time}</p>
                     </div>
                     <button 
                       onClick={() => addAISuggestion(s)}
                       className="bg-indigo-600 text-white p-2.5 rounded-xl active:scale-90 transition-all shadow-md"
                     >
                       <Plus size={18} />
                     </button>
                  </div>
                ))}
             </div>
          </div>
        )}

        {showAdd && (
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5 animate-in slide-in-from-top duration-300">
            <h3 className="font-black text-lg text-slate-900 dark:text-slate-100">{editingItem ? 'Refine Stop' : 'Add New Adventure'}</h3>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-400 ml-2">What are we doing?</label>
                <input 
                  placeholder="Activity title..." 
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-2xl px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-bold transition-all"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-1">
                   <label className="text-[10px] font-black uppercase text-slate-400 ml-2">Date</label>
                   <input 
                     type="date" 
                     className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-2xl px-5 py-4 text-sm focus:outline-none transition-all font-bold"
                     value={newDate}
                     min={trip.startDate}
                     max={trip.endDate}
                     onChange={e => {
                        setNewDate(e.target.value);
                        if (locationIdeas.length > 0) fetchLocationIdeas();
                     }}
                   />
                 </div>
                 <div className="space-y-1">
                   <label className="text-[10px] font-black uppercase text-slate-400 ml-2">Time</label>
                   <input 
                     type="time" 
                     className="bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-2xl px-5 py-4 text-sm focus:outline-none transition-all font-bold"
                     value={newTime}
                     onChange={e => setNewTime(e.target.value)}
                   />
                 </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center ml-2">
                  <label className="text-[10px] font-black uppercase text-slate-400">Where?</label>
                  <button 
                    onClick={fetchLocationIdeas}
                    disabled={isFetchingLocations}
                    className="flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest text-indigo-500 hover:text-indigo-600 transition-colors"
                  >
                    {isFetchingLocations ? <Loader2 size={10} className="animate-spin" /> : <Wand2 size={10} />}
                    AI Ideas
                  </button>
                </div>
                <div className="relative">
                  <MapPin size={16} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" />
                  <input 
                    placeholder="Location" 
                    className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-2xl py-4 pl-12 pr-5 text-sm focus:outline-none transition-all font-bold"
                    value={newLocation}
                    onChange={e => setNewLocation(e.target.value)}
                  />
                </div>

                {/* Location Suggestions Chip List */}
                {locationIdeas.length > 0 && (
                   <div className="flex gap-2 overflow-x-auto pb-2 pt-1 custom-scrollbar">
                      {locationIdeas.map((idea, idx) => (
                         <button 
                           key={idx}
                           onClick={() => setNewLocation(idea)}
                           className={`shrink-0 px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-tight transition-all border ${newLocation === idea ? 'bg-indigo-600 text-white border-transparent shadow-md' : 'bg-white dark:bg-slate-800 text-slate-500 border-slate-100 dark:border-slate-700 hover:border-indigo-200'}`}
                         >
                            {idea}
                         </button>
                      ))}
                   </div>
                )}
              </div>

              <div className="flex gap-3 pt-2">
                <button 
                  onClick={handleSave}
                  className="flex-1 bg-slate-900 dark:bg-white text-white dark:text-slate-900 py-4 rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all"
                >
                  {editingItem ? 'Update Stop' : 'Confirm Stop'}
                </button>
                {editingItem && (
                  <button 
                    onClick={() => {
                      if (window.confirm("Remove this stop from the journey?")) {
                        onDelete(editingItem.id);
                        resetForm();
                      }
                    }}
                    className="p-4 bg-rose-500 text-white rounded-2xl shadow-lg shadow-rose-900/20 active:scale-95 transition-all"
                  >
                    <Trash2 size={20} />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="relative pl-8 space-y-10 before:content-[''] before:absolute before:left-[11px] before:top-2 before:bottom-0 before:w-[2px] before:bg-slate-200 dark:before:bg-slate-800/50">
           {Object.keys(groupedItinerary).length === 0 ? (
             <div className="text-center py-20 opacity-40 pr-8">
                <Layers size={64} strokeWidth={1} className="mx-auto mb-4 text-slate-300" />
                <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">Your route is empty</p>
                <p className="text-[10px] mt-2 text-slate-400 font-bold">Start planning by clicking the plus or use AI magic suggestions.</p>
             </div>
           ) : (
             Object.entries(groupedItinerary).map(([date, items], groupIdx) => (
               <div key={date} className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-500" style={{ animationDelay: `${groupIdx * 100}ms` }}>
                  {/* Day Header */}
                  <div className="relative -ml-8 flex items-center gap-3">
                    <div className="w-6 h-6 bg-slate-900 dark:bg-white rounded-full flex items-center justify-center z-10 border-4 border-slate-50 dark:border-slate-950">
                      <CalendarDays size={10} className="text-white dark:text-slate-900" />
                    </div>
                    <div className="bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 px-4 py-1.5 rounded-full shadow-lg flex items-center gap-3">
                       <span className="text-[10px] font-black uppercase tracking-widest">Day {getDayNumber(date)}</span>
                       <div className="w-[1px] h-3 bg-white/20 dark:bg-slate-300"></div>
                       <span className="text-[10px] font-black uppercase tracking-widest opacity-70">{formatDateLabel(date)}</span>
                    </div>
                  </div>

                  {/* Items for this day */}
                  <div className="space-y-4 pr-1">
                    {(items as ItineraryItem[]).map((item, idx) => (
                      <div key={item.id} className="relative group">
                        <button 
                          onClick={() => onToggle(item.id)}
                          className={`absolute -left-[29px] top-1 w-6 h-6 rounded-full border-4 border-slate-50 dark:border-slate-950 flex items-center justify-center z-10 transition-all active:scale-[0.8] ${item.isCompleted ? 'bg-emerald-500 text-white border-emerald-50' : 'bg-white dark:bg-slate-800 text-slate-300 dark:text-slate-600'}`}
                        >
                          {item.isCompleted ? <Check size={10} strokeWidth={4} /> : <Circle size={10} />}
                        </button>
                        
                        <div className={`bg-white dark:bg-slate-900 rounded-[2rem] p-6 shadow-sm border border-slate-100 dark:border-slate-800/50 transition-all ${item.isCompleted ? 'opacity-50 grayscale-[0.5]' : 'hover:shadow-md hover:border-indigo-100 dark:hover:border-indigo-900/30'}`}>
                           <div className="flex justify-between items-start mb-3">
                             <h4 className={`font-black text-base transition-all ${item.isCompleted ? 'text-slate-500 line-through' : 'text-slate-900 dark:text-slate-100'}`}>{item.title}</h4>
                             <div className="flex gap-2">
                                <button 
                                  onClick={() => startEdit(item)}
                                  className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-cyan-400 transition-colors"
                                  title="Edit stop"
                                >
                                  <Edit2 size={16} />
                                </button>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (window.confirm(`Permanently remove "${item.title}" from your itinerary?`)) {
                                      onDelete(item.id);
                                    }
                                  }}
                                  className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors"
                                  title="Delete stop"
                                >
                                  <Trash2 size={16} />
                                </button>
                             </div>
                           </div>
                           <div className="flex flex-wrap gap-4">
                              <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                                <Clock size={14} className="opacity-50" />
                                <span className="text-xs font-black">{item.time || 'TBD'}</span>
                              </div>
                              <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                                <MapPin size={14} className="opacity-50" />
                                <span className="text-xs font-black truncate max-w-[120px]">{item.location}</span>
                              </div>
                           </div>
                           {item.notes && (
                             <div className="mt-4 flex gap-3 items-start bg-slate-50 dark:bg-slate-950/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-800/50">
                                <Sparkles size={14} className="text-indigo-500 flex-shrink-0 mt-0.5" />
                                <p className="text-[11px] font-bold text-slate-600 dark:text-slate-400 leading-relaxed italic pr-2">"{item.notes}"</p>
                             </div>
                           )}
                           <div className="mt-5 flex justify-end">
                              <button 
                                onClick={() => onToggle(item.id)}
                                className={`flex items-center gap-2 px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 ${item.isCompleted 
                                  ? 'bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/50' 
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 hover:bg-slate-900 hover:text-white dark:hover:bg-white dark:hover:text-slate-900'}`}
                              >
                                {item.isCompleted ? (
                                  <><CheckCircle2 size={14} /> Completed</>
                                ) : (
                                  'Mark as Visited'
                                )}
                              </button>
                           </div>
                        </div>
                      </div>
                    ))}
                  </div>
               </div>
             ))
           )}
        </div>
      </div>
    </SharedLayout>
  );
};

export default ItineraryView;
