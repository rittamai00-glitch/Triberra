
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import SharedLayout from '../components/SharedLayout';
import { Trip, Member, AuthUser } from '../types';
import { ChevronLeft, Camera, User, Check, Sparkles, X, Upload, Plus } from 'lucide-react';

interface ProfileViewProps {
  user: AuthUser;
  trip: Trip;
  onUpdate: (memberId: string, updates: Partial<Member>) => void;
  onUpdateUser: (updates: Partial<AuthUser>) => void;
}

const AVATAR_SEEDS = [
  'adventurer', 'traveler', 'pilot', 'hiker', 'cyclist',
  'photographer', 'scuba', 'mountain', 'beach', 'sunset',
  'forest', 'river', 'desert', 'snow', 'glacier',
  'island', 'palm', 'compass', 'map', 'passport',
  'backpack', 'tent', 'bonfire', 'globetrotter'
];

const ProfileView: React.FC<ProfileViewProps> = ({ user, trip, onUpdate, onUpdateUser }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const member = trip.members.find(m => m.id === id);

  const [name, setName] = useState(member?.name || '');
  const [avatar, setAvatar] = useState(member?.avatar || '');
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    if (!member) navigate('/settings');
  }, [member, navigate]);

  if (!member) return null;

  const handleSave = () => {
    if (!name.trim()) {
      alert("First fill your name and then click the Done button.");
      return;
    }
    setIsSaving(true);
    setTimeout(() => {
      // 1. Update member within the trip
      onUpdate(member.id, { name, avatar });
      
      // 2. If editing own profile, update global auth user state (updates header)
      if (member.id === user.id) {
        onUpdateUser({ name, avatar });
      }
      
      setIsSaving(false);
      navigate('/settings');
    }, 800);
  };

  const selectAvatarSeed = (seed: string) => {
    setAvatar(`https://picsum.photos/seed/${seed}/200`);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image size too large. Please select an image under 2MB.");
        return;
      }

      setIsUploading(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatar(reader.result as string);
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFilePicker = () => {
    fileInputRef.current?.click();
  };

  return (
    <SharedLayout showTabs={false} title="Edit Profile">
      <div className="max-w-md mx-auto space-y-8 pb-10">
        <div className="flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors">
            <X className="text-slate-500" size={24} />
          </button>
          <h2 className="text-xl font-black">Edit Profile</h2>
          <button 
            onClick={handleSave}
            disabled={isSaving || isUploading}
            className="bg-indigo-600 text-white px-5 py-2 rounded-full text-sm font-bold shadow-lg shadow-indigo-900/20 active:scale-95 transition-all flex items-center gap-2 disabled:opacity-50"
          >
            {isSaving ? 'Saving...' : <><Check size={18} /> Done</>}
          </button>
        </div>

        {/* Avatar Section */}
        <div className="flex flex-col items-center">
          <div className="relative group cursor-pointer" onClick={triggerFilePicker}>
            <div className={`w-32 h-32 rounded-[2.5rem] overflow-hidden border-4 border-white dark:border-slate-800 shadow-2xl relative transition-transform hover:scale-105 duration-300 ${isUploading ? 'animate-pulse' : ''}`}>
              <img src={avatar} alt={name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                 <Camera className="text-white mb-1" size={28} />
                 <span className="text-[8px] text-white font-black uppercase tracking-widest">Change</span>
              </div>
              {isUploading && (
                <div className="absolute inset-0 bg-indigo-600/20 backdrop-blur-sm flex items-center justify-center">
                   <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>
            <div className="absolute -bottom-2 -right-2 bg-indigo-600 text-white p-2.5 rounded-2xl shadow-lg">
               <Upload size={14} strokeWidth={3} />
            </div>
          </div>
          <p className="mt-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Traveler Avatar</p>
          
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/*" 
            className="hidden" 
          />
        </div>

        {/* Form */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 shadow-sm border border-slate-200 dark:border-slate-800 space-y-6">
          <div className="space-y-2">
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest ml-1">Display Name</label>
            <div className="relative">
              <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-2xl py-4 pl-12 pr-4 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-bold transition-all"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="How should we call you?"
              />
            </div>
          </div>

          <div className="space-y-4">
             <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest ml-1">Choose your look</label>
             <div className="grid grid-cols-5 gap-3 max-h-80 overflow-y-auto custom-scrollbar p-1">
               {/* Custom Upload Tile */}
               <button 
                 onClick={triggerFilePicker}
                 className="w-full aspect-square rounded-xl flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 border-2 border-dashed border-slate-200 dark:border-slate-800 text-slate-400 hover:text-indigo-500 hover:border-indigo-500 transition-all active:scale-95"
               >
                 <Plus size={16} />
                 <span className="text-[7px] font-black uppercase mt-1">Upload</span>
               </button>

               {AVATAR_SEEDS.map(seed => {
                 const url = `https://picsum.photos/seed/${seed}/100`;
                 const isSelected = avatar.includes(seed);
                 return (
                   <button 
                     key={seed}
                     onClick={() => selectAvatarSeed(seed)}
                     className={`w-full aspect-square rounded-xl overflow-hidden border-2 transition-all active:scale-90 relative ${isSelected ? 'border-indigo-600 scale-110 shadow-lg shadow-indigo-900/20 z-10' : 'border-transparent grayscale opacity-60 hover:grayscale-0 hover:opacity-100'}`}
                   >
                     <img src={url} alt={seed} className="w-full h-full object-cover" />
                     {isSelected && (
                       <div className="absolute inset-0 bg-indigo-600/20 flex items-center justify-center">
                          <Check size={16} className="text-white drop-shadow-md" strokeWidth={4} />
                       </div>
                     )}
                   </button>
                 );
               })}
             </div>
             <p className="text-center text-[8px] font-bold text-slate-400 uppercase tracking-tighter">
                Browse our curated travel styles or upload your own photo
             </p>
          </div>
        </div>
      </div>
    </SharedLayout>
  );
};

export default ProfileView;
