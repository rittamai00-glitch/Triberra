import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SharedLayout from '../components/SharedLayout';
import { Trip, Member, AuthUser, UserPreferences } from '../types';
import { 
  ChevronLeft, MapPin, IndianRupee, Save, Trash2, Users, Sun, Moon, 
  Palette, Plus, UserPlus, X, Share2, Copy, Check, Link as LinkIcon, 
  Wallet, Edit2, Sparkles, User, LogOut, QrCode, Download, AlertTriangle,
  BellRing, BellOff, CreditCard, Map, Tag, Calendar, Layout
} from 'lucide-react';

interface SettingsViewProps {
  user: AuthUser;
  trip: Trip;
  onUpdate: (fields: Partial<Trip>) => void;
  onAddMember: (name: string) => void;
  onDeleteTrip: () => void;
  onJoinByCode: (code: string) => void;
  onUpdateUser: (updates: Partial<AuthUser>) => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onLogout: () => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({ user, trip, onUpdate, onAddMember, onDeleteTrip, onJoinByCode, onUpdateUser, theme, onToggleTheme, onLogout }) => {
  const navigate = useNavigate();
  const [name, setName] = useState(trip.name);
  const [dest, setDest] = useState(trip.destination);
  const [start, setStart] = useState(trip.startDate);
  const [end, setEnd] = useState(trip.endDate);
  const [groupBudget, setGroupBudget] = useState(trip.budget.toString());
  const [personalBudget, setPersonalBudget] = useState((trip.personalBudget || trip.budget / trip.members.length).toString());
  
  const [showAddMember, setShowAddMember] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  
  const [isCopied, setIsCopied] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Preference states
  const [prefs, setPrefs] = useState<UserPreferences>(user.preferences || {
    budgetAlerts: true,
    expenseUpdates: true,
    itineraryReminders: true,
  });

  const handleSave = () => {
    if (!name.trim()) { alert("First fill the trip name and then click the Save button."); return; }
    if (!dest.trim()) { alert("First fill the destination and then click the Save button."); return; }
    
    setIsSaving(true);
    
    setTimeout(() => {
      onUpdate({
        name: name.trim(),
        destination: dest.trim(),
        startDate: start,
        endDate: end,
        budget: parseFloat(groupBudget) || 0,
        personalBudget: parseFloat(personalBudget) || 0,
      });
      // Persist preferences
      onUpdateUser({ preferences: prefs });
      setIsSaving(false);
      
      // Visual confirmation before navigating
      const button = document.getElementById('save-details-btn');
      if (button) {
        button.classList.add('bg-emerald-500', 'text-white');
        setTimeout(() => navigate('/'), 800);
      } else {
        navigate('/');
      }
    }, 600);
  };

  const togglePreference = (key: keyof UserPreferences) => {
    const newPrefs = { ...prefs, [key]: !prefs[key] };
    setPrefs(newPrefs);
    onUpdateUser({ preferences: newPrefs });
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(trip.inviteCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleAddMember = () => {
    if (newMemberName.trim()) {
      onAddMember(newMemberName.trim());
      setNewMemberName('');
      setShowAddMember(false);
    } else {
      alert("First fill the member name and then click the Add button.");
    }
  };

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to log out? Your session and trip data will be cleared from this device.")) {
      onLogout();
      navigate('/auth');
    }
  };

  const handleDeleteTrip = () => {
    if (window.confirm("Danger Zone: Permanently delete this trip and all its data? This cannot be undone.")) {
      onDeleteTrip();
      navigate('/');
    }
  };

  const currentUser = trip.members[0];
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${trip.inviteCode}&bgcolor=ffffff&color=0f172a&margin=10`;

  return (
    <SharedLayout activeTab="settings" title="Manage Trip">
      <div className="space-y-6 pb-20 text-slate-900 dark:text-slate-100 transition-colors">
        
        {/* QR Code Modal Overlay */}
        {showQR && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-300">
             <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[3rem] p-8 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-300 text-center relative overflow-hidden">
                <div className="absolute top-[-20%] left-[-20%] w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
                
                <button 
                  onClick={() => setShowQR(false)} 
                  className="absolute top-6 right-6 p-2 bg-slate-100 dark:bg-slate-800 rounded-full text-slate-500 transition-transform active:scale-90"
                >
                  <X size={20} />
                </button>

                <div className="mb-6">
                   <h3 className="text-xl font-black mb-1">Scan to Join</h3>
                   <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-relaxed">
                     Quick connect for {trip.name}
                   </p>
                </div>

                <div className="bg-white p-4 rounded-[2rem] shadow-inner mb-6 mx-auto w-fit border border-slate-100">
                   <img 
                     src={qrCodeUrl} 
                     alt="Trip Invite QR Code" 
                     className="w-48 h-48 rounded-2xl"
                   />
                </div>

                <div className="flex flex-col gap-3">
                   <div className="bg-slate-50 dark:bg-slate-800/50 py-3 rounded-2xl font-mono font-black tracking-[0.3em] text-lg border border-slate-100 dark:border-slate-800">
                      {trip.inviteCode}
                   </div>
                   <p className="text-[9px] font-bold text-slate-400 uppercase leading-relaxed px-4">
                     Point your camera at the screen or share the code above manually.
                   </p>
                </div>
                
                <button 
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = qrCodeUrl;
                    link.download = `triberra-invite-${trip.inviteCode}.png`;
                    link.click();
                  }}
                  className="mt-6 w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl shadow-indigo-900/20 active:scale-95 transition-all"
                >
                  <Download size={16} /> Save QR Image
                </button>
             </div>
          </div>
        )}

        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-sm border border-slate-200 dark:border-slate-800 flex items-center gap-4 group transition-all">
           <div className="relative">
              <img src={currentUser.avatar} className="w-16 h-16 rounded-[1.2rem] shadow-xl border-2 border-white dark:border-slate-800" alt="" />
              <div className="absolute -bottom-1 -right-1 bg-emerald-500 w-4 h-4 rounded-full border-2 border-white dark:border-slate-900"></div>
           </div>
           <div className="flex-1">
              <h3 className="text-lg font-black">{currentUser.name}</h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Active Account</p>
           </div>
           <button 
             onClick={() => navigate(`/profile/${currentUser.id}`)}
             className="p-3 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-2xl hover:bg-indigo-600 transition-all active:scale-90"
           >
              <Edit2 size={20} />
           </button>
        </div>

        {/* Trip Configuration Section */}
        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-7 shadow-sm border border-slate-200 dark:border-slate-800 space-y-6">
          <div className="flex items-center justify-between">
             <div>
                <h3 className="font-black flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-slate-400">
                   <Layout size={18} className="text-indigo-500" /> Trip Details
                </h3>
                <p className="text-[9px] font-bold text-slate-400 mt-0.5 tracking-tight lowercase first-letter:uppercase">Edit destination, dates and budget.</p>
             </div>
             <button 
               id="save-details-btn"
               onClick={handleSave} 
               disabled={isSaving}
               className="text-[9px] font-black text-indigo-600 dark:text-cyan-400 uppercase tracking-[0.2em] px-4 py-2 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
             >
                {isSaving ? 'Saving...' : 'Save Changes'}
             </button>
          </div>

          <div className="space-y-5">
            <div className="relative group">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Journey Identity (Trip Name)</label>
              <div className="relative">
                <Tag size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                <input 
                  type="text" 
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-2xl py-4 pl-12 pr-4 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-black text-sm transition-all" 
                  value={name} 
                  onChange={e => setName(e.target.value)} 
                  placeholder="e.g. Summer Retreat"
                />
              </div>
            </div>

            <div className="relative group">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Destination</label>
              <div className="relative">
                <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                <input 
                  type="text" 
                  className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-2xl py-4 pl-12 pr-4 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-black text-sm transition-all" 
                  value={dest} 
                  onChange={e => setDest(e.target.value)} 
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-1">
                 <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Start Date</label>
                 <input 
                   type="date" 
                   className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-2xl py-3 px-4 border border-slate-200 dark:border-slate-800 focus:outline-none text-xs font-bold" 
                   value={start} 
                   onChange={e => setStart(e.target.value)} 
                 />
               </div>
               <div className="space-y-1">
                 <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">End Date</label>
                 <input 
                   type="date" 
                   className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-2xl py-3 px-4 border border-slate-200 dark:border-slate-800 focus:outline-none text-xs font-bold" 
                   value={end} 
                   onChange={e => setEnd(e.target.value)} 
                 />
               </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-1">
                 <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Group Budget</label>
                 <div className="relative">
                   <IndianRupee size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                   <input 
                     type="number" 
                     className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-2xl py-3 pl-10 pr-4 border border-slate-200 dark:border-slate-800 focus:outline-none text-xs font-bold" 
                     value={groupBudget} 
                     onChange={e => setGroupBudget(e.target.value)} 
                   />
                 </div>
               </div>
               <div className="space-y-1">
                 <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Personal Cap</label>
                 <div className="relative">
                   <IndianRupee size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                   <input 
                     type="number" 
                     className="w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-2xl py-3 pl-10 pr-4 border border-slate-200 dark:border-slate-800 focus:outline-none text-xs font-bold" 
                     value={personalBudget} 
                     onChange={e => setPersonalBudget(e.target.value)} 
                   />
                 </div>
               </div>
            </div>
          </div>
        </div>

        {/* Notification Intelligence Section */}
        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
           <div className="mb-2">
              <div className="flex items-center gap-2">
                 <BellRing size={18} className="text-indigo-500" />
                 <h3 className="font-bold text-sm">Notification Intelligence</h3>
              </div>
              <p className="text-[9px] font-bold text-slate-400 mt-0.5 tracking-tight lowercase first-letter:uppercase ml-7">Configure your real-time travel alerts.</p>
           </div>
           
           <div className="space-y-3">
              <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800">
                 <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl ${prefs.budgetAlerts ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-400'}`}>
                       <IndianRupee size={16} />
                    </div>
                    <div>
                       <p className="text-xs font-black">Budget Alerts</p>
                       <p className="text-[9px] font-bold text-slate-400 uppercase">Notify on threshold breach</p>
                    </div>
                 </div>
                 <button 
                   onClick={() => togglePreference('budgetAlerts')}
                   className={`w-10 h-5 rounded-full relative transition-all duration-300 ${prefs.budgetAlerts ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'}`}
                 >
                    <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300 ${prefs.budgetAlerts ? 'left-6' : 'left-1'}`}></div>
                 </button>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800">
                 <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl ${prefs.expenseUpdates ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                       <CreditCard size={16} />
                    </div>
                    <div>
                       <p className="text-xs font-black">Expense Logs</p>
                       <p className="text-[9px] font-bold text-slate-400 uppercase">Confirmations of new entries</p>
                    </div>
                 </div>
                 <button 
                   onClick={() => togglePreference('expenseUpdates')}
                   className={`w-10 h-5 rounded-full relative transition-all duration-300 ${prefs.expenseUpdates ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'}`}
                 >
                    <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300 ${prefs.expenseUpdates ? 'left-6' : 'left-1'}`}></div>
                 </button>
              </div>

              <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800">
                 <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl ${prefs.itineraryReminders ? 'bg-cyan-100 text-cyan-600' : 'bg-slate-100 text-slate-400'}`}>
                       <Map size={16} />
                    </div>
                    <div>
                       <p className="text-xs font-black">Route Reminders</p>
                       <p className="text-[9px] font-bold text-slate-400 uppercase">Upcoming itinerary stops</p>
                    </div>
                 </div>
                 <button 
                   onClick={() => togglePreference('itineraryReminders')}
                   className={`w-10 h-5 rounded-full relative transition-all duration-300 ${prefs.itineraryReminders ? 'bg-cyan-500' : 'bg-slate-300 dark:bg-slate-700'}`}
                 >
                    <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300 ${prefs.itineraryReminders ? 'left-6' : 'left-1'}`}></div>
                 </button>
              </div>
           </div>
        </div>

        <div className="bg-indigo-600 text-white rounded-[2.5rem] p-6 shadow-xl shadow-indigo-900/20 relative overflow-hidden">
           <div className="absolute -right-4 -top-4 opacity-10">
              <Share2 size={120} />
           </div>
           <div className="relative z-10">
              <div className="flex justify-between items-center mb-1">
                 <h3 className="font-bold flex items-center gap-2 text-sm">
                    <LinkIcon size={16} /> Invite Code
                 </h3>
                 <button 
                   onClick={() => setShowQR(true)}
                   className="text-[9px] font-black uppercase tracking-widest bg-white/20 hover:bg-white/30 px-3 py-1 rounded-full transition-all"
                 >
                   View QR
                 </button>
              </div>
              <p className="text-indigo-100 text-[10px] mb-4 font-medium">Connect your buddies in real-time.</p>
              
              <div className="flex items-center gap-2">
                 <div className="flex-1 bg-white/10 backdrop-blur-md rounded-2xl py-3 px-4 font-mono font-black tracking-widest text-base border border-white/20">
                    {trip.inviteCode}
                 </div>
                 <div className="flex gap-2">
                   <button 
                     onClick={handleCopyCode}
                     className={`p-3.5 rounded-2xl transition-all ${isCopied ? 'bg-emerald-500' : 'bg-white text-indigo-600'}`}
                     title="Copy Code"
                   >
                      {isCopied ? <Check size={18} /> : <Copy size={18} />}
                   </button>
                   <button 
                     onClick={() => setShowQR(true)}
                     className="p-3.5 bg-white/20 backdrop-blur-md text-white rounded-2xl border border-white/20 hover:bg-white/30 transition-all"
                     title="Show QR Code"
                   >
                      <QrCode size={18} />
                   </button>
                 </div>
              </div>
           </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-sm border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between mb-4">
             <div>
                <h3 className="font-bold flex items-center gap-2 text-sm">
                  <Users size={16} className="text-indigo-500" /> Trip Members
                </h3>
                <p className="text-[9px] font-bold text-slate-400 mt-0.5 tracking-tight lowercase first-letter:uppercase ml-7">Add or remove trip participants.</p>
             </div>
             <button 
                onClick={() => setShowAddMember(!showAddMember)}
                className="p-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl hover:bg-indigo-100 transition-colors"
             >
                {showAddMember ? <X size={16} /> : <UserPlus size={16} />}
             </button>
          </div>

          {showAddMember && (
            <div className="mb-4 flex gap-2 animate-in slide-in-from-top-2 duration-200">
              <input 
                type="text" 
                placeholder="Name" 
                className="flex-1 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-xl px-4 py-2 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-sm font-semibold"
                value={newMemberName}
                onChange={(e) => setNewMemberName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddMember()}
              />
              <button onClick={handleAddMember} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md">Add</button>
            </div>
          )}

          <div className="space-y-3">
            {trip.members.map((member) => (
              <div key={member.id} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 group/item">
                <img className="h-10 w-10 rounded-[0.8rem] border border-white dark:border-slate-700 shadow-sm" src={member.avatar} alt={member.name} />
                <div className="flex flex-col min-w-0 flex-1">
                  <span className="text-xs font-black truncate">{member.name}</span>
                  {member.isOrganizer && <span className="text-[8px] font-black text-indigo-500 uppercase">Trip Owner</span>}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 shadow-sm border border-slate-200 dark:border-slate-800">
           <div className="mb-4">
              <h3 className="text-slate-900 dark:text-slate-100 font-bold flex items-center gap-2 text-sm">
                 <Palette size={16} className="text-indigo-500" /> Appearance
              </h3>
              <p className="text-[9px] font-bold text-slate-400 mt-0.5 tracking-tight lowercase first-letter:uppercase ml-7">Switch between light and dark.</p>
           </div>
           <div className="flex p-1 bg-slate-100 dark:bg-slate-950 rounded-2xl">
              <button onClick={() => theme === 'dark' && onToggleTheme()} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black transition-all ${theme === 'light' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}><><Sun size={14} /> LIGHT</></button>
              <button onClick={() => theme === 'light' && onToggleTheme()} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black transition-all ${theme === 'dark' ? 'bg-slate-900 text-cyan-400 shadow-sm' : 'text-slate-500'}`}><><Moon size={14} /> DARK</></button>
           </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2 px-2">
             <AlertTriangle size={14} className="text-rose-500" />
             <h4 className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Danger Zone</h4>
          </div>
          
          <button 
            onClick={handleLogout}
            className="w-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 py-5 rounded-[2rem] font-black text-sm border border-slate-300 dark:border-slate-700 hover:bg-slate-900 hover:text-white transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <LogOut size={18} /> LOG OUT
          </button>

          <button 
            onClick={handleDeleteTrip}
            className="w-full bg-rose-50 dark:bg-rose-900/10 text-rose-600 dark:text-rose-400 py-5 rounded-[2rem] font-black text-sm border border-rose-100 dark:border-rose-900/30 hover:bg-rose-600 hover:text-white transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <Trash2 size={18} /> DELETE TRIP
          </button>
        </div>
      </div>
    </SharedLayout>
  );
};

export default SettingsView;