import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import SharedLayout from '../components/SharedLayout';
import { Trip } from '../types';
import { askTravelAssistant, TravelAdvice } from '../services/geminiService';
import { Send, Sparkles, Loader2, ArrowLeft, ExternalLink, Globe, User } from 'lucide-react';

interface TravelGuideViewProps {
  trip: Trip;
}

interface Message {
  role: 'user' | 'ai';
  content: string;
  sources?: { title: string; uri: string }[];
}

const TravelGuideView: React.FC<TravelGuideViewProps> = ({ trip }) => {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'ai', 
      content: `Hi! I'm Triberra AI. I see you're planning a trip to ${trip.destination}. How can I help you today? Ask me about local food, hidden spots, or travel tips!` 
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!query.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: query };
    setMessages(prev => [...prev, userMessage]);
    setQuery('');
    setIsLoading(true);

    const context = `${trip.destination}. Trip dates: ${trip.startDate} to ${trip.endDate}.`;
    const response: TravelAdvice = await askTravelAssistant(query, context);

    const aiMessage: Message = { 
      role: 'ai', 
      content: response.text,
      sources: response.sources
    };
    
    setMessages(prev => [...prev, aiMessage]);
    setIsLoading(false);
  };

  return (
    <SharedLayout showTabs={false} title="Travel Concierge">
      <div className="flex flex-col h-[calc(100vh-140px)]">
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
            <ArrowLeft size={24} className="text-slate-500" />
          </button>
          <div className="flex flex-col items-center">
             <div className="flex items-center gap-2">
                <Sparkles size={16} className="text-indigo-600" />
                <h2 className="text-sm font-black uppercase tracking-widest">Ask Triberra</h2>
             </div>
             <p className="text-[10px] font-bold text-emerald-500 uppercase tracking-tight">AI Connected & Grounded</p>
          </div>
          <div className="w-10"></div>
        </div>

        {/* Chat Area */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto space-y-4 px-1 pb-4 custom-scrollbar"
        >
          {messages.map((msg, idx) => (
            <div 
              key={idx} 
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}
            >
              <div className={`max-w-[85%] rounded-[2rem] p-5 ${
                msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-br-none shadow-lg shadow-indigo-900/20' 
                  : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-bl-none border border-slate-100 dark:border-slate-800 shadow-sm'
              }`}>
                <div className="flex items-center gap-2 mb-2 opacity-50">
                   {msg.role === 'user' ? <User size={12} /> : <Sparkles size={12} />}
                   <span className="text-[10px] font-black uppercase tracking-widest">{msg.role === 'user' ? 'You' : 'Triberra AI'}</span>
                </div>
                <p className="text-sm font-medium leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
                     <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest">Sources & Links</p>
                     <div className="flex flex-wrap gap-2">
                        {msg.sources.map((source, i) => (
                          <a 
                            key={i} 
                            href={source.uri} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[9px] font-bold bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 px-2 py-1 rounded-full transition-colors"
                          >
                             <Globe size={8} /> {source.title.length > 20 ? source.title.substring(0, 20) + '...' : source.title}
                          </a>
                        ))}
                     </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
               <div className="bg-white dark:bg-slate-900 rounded-[2rem] rounded-bl-none p-5 border border-slate-100 dark:border-slate-800 flex items-center gap-3">
                  <div className="flex space-x-1">
                     <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                     <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                     <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Analyzing Web...</span>
               </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="mt-4 relative">
          <input 
            type="text" 
            placeholder="Ask anything about Bali..."
            className="w-full bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-[2rem] py-4 pl-6 pr-16 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-bold text-sm shadow-xl"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <button 
            onClick={handleSend}
            disabled={!query.trim() || isLoading}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-12 h-12 bg-indigo-600 text-white rounded-full flex items-center justify-center shadow-lg active:scale-90 transition-all disabled:opacity-50"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </SharedLayout>
  );
};

export default TravelGuideView;