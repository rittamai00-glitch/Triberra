
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, Plane, Globe, Map, Sparkles, ShieldCheck, Users, Wallet, 
  Zap, Star, Link as LinkIcon, Loader2, Archive, QrCode, X, Camera
} from 'lucide-react';
import { AuthUser } from '../types';
import { Html5Qrcode } from 'html5-qrcode';

interface WelcomeViewProps {
  user: AuthUser;
  onJoin?: (code: string) => void;
}

const WelcomeView: React.FC<WelcomeViewProps> = ({ user, onJoin }) => {
  const navigate = useNavigate();
  const [showContent, setShowContent] = useState(false);
  const [isJoinMode, setIsJoinMode] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);
  
  // Scanner state
  const [showScanner, setShowScanner] = useState(false);
  const [scannerError, setScannerError] = useState<string | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerId = "qr-reader";

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowContent(true);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const handleConnect = (codeToJoin?: string) => {
    const finalCode = codeToJoin || joinCode;
    if (!finalCode.trim()) {
      alert("First fill the invite code and then click the connect button.");
      return;
    }
    
    setIsConnecting(true);
    // Simulate lookup/network delay
    setTimeout(() => {
      if (onJoin) onJoin(finalCode.trim().toUpperCase());
      setIsConnecting(false);
    }, 1200);
  };

  const startScanner = async () => {
    setScannerError(null);
    setShowScanner(true);
    
    // Slight delay to ensure DOM element is rendered
    setTimeout(async () => {
      try {
        const html5QrCode = new Html5Qrcode(scannerContainerId);
        scannerRef.current = html5QrCode;
        
        const config = { fps: 10, qrbox: { width: 250, height: 250 } };
        
        await html5QrCode.start(
          { facingMode: "environment" },
          config,
          (decodedText) => {
            // Success!
            stopScanner();
            handleConnect(decodedText);
          },
          (errorMessage) => {
            // Ongoing scanning noise, usually safe to ignore
          }
        );
      } catch (err: any) {
        console.error("Camera access error:", err);
        setScannerError("Camera access denied or not found.");
      }
    }, 300);
  };

  const stopScanner = async () => {
    if (scannerRef.current && scannerRef.current.isScanning) {
      try {
        await scannerRef.current.stop();
      } catch (err) {
        console.error("Failed to stop scanner", err);
      }
    }
    setShowScanner(false);
  };

  const badges = [
    { text: "Safe & Reliable", icon: <ShieldCheck size={10} /> },
    { text: "Smart Group Travel", icon: <Users size={10} /> },
    { text: "Easy Expense Split", icon: <Wallet size={10} /> },
  ];

  return (
    <div className="min-h-screen max-w-md mx-auto bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center px-8 relative overflow-hidden transition-colors duration-500">
      
      {/* Scanner Overlay Modal */}
      {showScanner && (
        <div className="fixed inset-0 z-[100] bg-slate-950 flex flex-col animate-in fade-in duration-300">
           <div className="p-8 flex justify-between items-center relative z-20">
              <div className="flex items-center gap-3">
                 <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg">
                    <QrCode size={20} />
                 </div>
                 <div>
                    <h2 className="text-white font-black text-lg">Scan Invite</h2>
                    <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Point at a friend's QR</p>
                 </div>
              </div>
              <button 
                onClick={stopScanner}
                className="p-3 bg-white/10 hover:bg-white/20 rounded-2xl text-white transition-all active:scale-90"
              >
                <X size={24} />
              </button>
           </div>

           <div className="flex-1 relative flex items-center justify-center px-6">
              <div id={scannerContainerId} className="w-full max-w-sm aspect-square bg-slate-900 rounded-[3rem] overflow-hidden border-2 border-slate-800 shadow-2xl relative">
                 {/* Visual Viewfinder Overlay */}
                 <div className="absolute inset-0 z-10 pointer-events-none border-[40px] border-slate-950/60"></div>
                 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[250px] h-[250px] z-10 pointer-events-none">
                    <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-indigo-500 rounded-tl-lg"></div>
                    <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-indigo-500 rounded-tr-lg"></div>
                    <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-indigo-500 rounded-bl-lg"></div>
                    <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-indigo-500 rounded-br-lg"></div>
                    
                    {/* Scanning Animation Line */}
                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent absolute top-0 animate-[scan_2s_infinite_ease-in-out]"></div>
                 </div>
                 
                 {scannerError && (
                   <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center bg-slate-900/90 z-20">
                      <Camera size={48} className="text-rose-500 mb-4" />
                      <p className="text-white font-bold text-sm mb-4">{scannerError}</p>
                      <button 
                        onClick={stopScanner}
                        className="bg-white text-slate-900 px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest"
                      >
                        Go Back
                      </button>
                   </div>
                 )}
              </div>
           </div>

           <div className="p-12 text-center relative z-20">
              <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] animate-pulse">
                Align QR Code within the frame
              </p>
           </div>
           
           <style>{`
             @keyframes scan {
               0%, 100% { top: 0%; opacity: 0; }
               20%, 80% { opacity: 1; }
               100% { top: 100%; }
             }
           `}</style>
        </div>
      )}

      <div className="absolute top-[-10%] left-[-10%] w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-[-5%] right-[-5%] w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl animate-pulse delay-700"></div>
      
      <div className="relative z-10 flex flex-col items-center text-center w-full">
        <div className="w-24 h-24 relative mb-8">
           <img src={user.avatar} className="w-full h-full rounded-[2.5rem] object-cover shadow-2xl border-4 border-white dark:border-slate-800" alt="" />
           <div className="absolute -bottom-2 -right-2 bg-indigo-600 text-white p-2 rounded-2xl shadow-lg">
              <Sparkles size={16} />
           </div>
        </div>

        <div className="space-y-1 animate-in slide-in-from-bottom-8 duration-1000 delay-300 fill-mode-both">
          <h1 className="text-3xl font-black py-2 text-slate-900 dark:text-white">
            Hi, {user.name.split(' ')[0]}!
          </h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium text-xs tracking-[0.2em] uppercase">
            Your smart journey starts here
          </p>
        </div>

        <div className={`mt-10 transition-all duration-700 transform w-full flex flex-col items-center ${showContent ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          
          {isJoinMode ? (
            <div className="w-full space-y-4 animate-in zoom-in-95 duration-300">
              <div className="relative">
                <LinkIcon size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text"
                  placeholder="Paste Invite Code"
                  className="w-full bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-2xl py-3.5 pl-12 pr-4 text-sm font-black tracking-widest focus:outline-none focus:ring-2 focus:ring-indigo-500/20 uppercase shadow-sm"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value)}
                />
              </div>
              <div className="flex gap-2 w-full">
                <button 
                  onClick={() => setIsJoinMode(false)}
                  className="flex-1 bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 py-3.5 rounded-2xl font-bold text-sm hover:bg-slate-300 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleConnect()}
                  disabled={isConnecting}
                  className="flex-[2] bg-indigo-600 text-white py-3.5 rounded-2xl font-black text-sm shadow-xl shadow-indigo-900/20 hover:shadow-indigo-600/40 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isConnecting ? <Loader2 size={18} className="animate-spin" /> : <><Sparkles size={18} /> Connect</>}
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4 w-full">
              <button 
                onClick={() => navigate('/create-trip')}
                className="group relative w-full flex items-center justify-center gap-3 bg-gradient-to-r from-indigo-600 to-cyan-500 text-white py-4 px-8 rounded-full font-black text-sm shadow-xl shadow-indigo-900/20 hover:shadow-indigo-500/40 active:scale-95 transition-all"
              >
                Plan New Trip
                <ArrowRight className="transition-transform group-hover:translate-x-1" size={16} />
              </button>

              <div className="grid grid-cols-2 gap-4 w-full">
                <button 
                  onClick={() => setIsJoinMode(true)}
                  className="flex items-center justify-center gap-2 bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-800 py-3 rounded-2xl font-bold text-[10px] uppercase tracking-widest hover:border-indigo-500 transition-all"
                >
                  <LinkIcon size={14} /> Join Code
                </button>
                <button 
                  onClick={startScanner}
                  className="flex items-center justify-center gap-2 bg-slate-900 text-white border border-slate-800 py-3 rounded-2xl font-bold text-[10px] uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg"
                >
                  <QrCode size={14} /> Scan QR
                </button>
              </div>

              <button 
                onClick={() => navigate('/history')}
                className="w-full flex items-center justify-center gap-2 bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-800 py-3 rounded-2xl font-bold text-[10px] uppercase tracking-widest hover:border-indigo-500 transition-all mt-2"
              >
                <Archive size={14} /> Travel History
              </button>
            </div>
          )}

          <div className="flex flex-wrap justify-center gap-2 px-4 mt-12 opacity-80">
            {badges.map((badge, idx) => (
              <div 
                key={idx} 
                className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-200/40 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-full animate-in fade-in zoom-in duration-500"
                style={{ animationDelay: `${500 + (idx * 150)}ms`, animationFillMode: 'both' }}
              >
                <span className="text-indigo-500 dark:text-cyan-400">{badge.icon}</span>
                <span className="text-[9px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-tight whitespace-nowrap">
                  {badge.text}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeView;
